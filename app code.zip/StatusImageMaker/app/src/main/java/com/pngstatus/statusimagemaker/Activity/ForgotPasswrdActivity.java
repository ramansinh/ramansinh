package com.pngstatus.statusimagemaker.Activity;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.pngstatus.statusimagemaker.Utils.Constance;
import com.pngstatus.statusimagemaker.Utils.LocaleHelper;
import com.pngstatus.statusimagemaker.Utils.Prefs;
import com.pngstatus.statusimagemaker.model.Response_common;
import com.pngstatus.statusimagemaker.R;
import com.pngstatus.statusimagemaker.Retrofit.RetrofitClient;
import com.pngstatus.statusimagemaker.Retrofit.RetrofitInterface;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ForgotPasswrdActivity extends AppCompatActivity {
    Context context;
    @BindView(R.id.et_email)
    EditText et_email;
    @BindView(R.id.btn_submit)
    Button btn_submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_passwrd);
        context = ForgotPasswrdActivity.this;
        ButterKnife.bind(this);
        if (Build.VERSION.SDK_INT < 16) {
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                    WindowManager.LayoutParams.FLAG_FULLSCREEN);
        } else {
            View decorView = getWindow().getDecorView();
            // Hide Status Bar.
            int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
            decorView.setSystemUiVisibility(uiOptions);
        }
        String applang = Prefs.getPrefString(context, Constance.select_app_lang, "en");
        LocaleHelper.setLocale(context,applang);
        btn_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!et_email.getText().toString().isEmpty()) {
                    forgotpasswrd(et_email.getText().toString());
                } else {
                    et_email.requestFocus();
                    et_email.setError(getResources().getString(R.string.err_enter_email));
                }
            }
        });
    }

    private void forgotpasswrd(String email) {
        final ProgressDialog dialog = new ProgressDialog(context);
        dialog.setCancelable(false);
        dialog.setMessage(getResources().getString(R.string.wait_dot_dot));
        dialog.show();

        RetrofitInterface retrofitInterface = RetrofitClient.getClient().create(RetrofitInterface.class);
        Call<Response_common> call = retrofitInterface.forgot_password(email);
        call.enqueue(new Callback<Response_common>() {
            @Override
            public void onResponse(Call<Response_common> call, Response<Response_common> response) {
                if (response != null && response.body() != null) {
                    if (response.body().getResult() != null && response.body().getResult().equals("1")) {
                        new AlertDialog.Builder(context)
                                .setMessage(response.body().getMessage())
                                .setPositiveButton(getResources().getString(R.string.ok), new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        dialogInterface.dismiss();
                                        onBackPressed();
                                    }
                                }).setNegativeButton(getResources().getString(R.string.cancel), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                            }
                        }).show();

                        dialog.dismiss();
                    } else {
                        dialog.dismiss();
                        Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    dialog.dismiss();
                    Toast.makeText(context, response.message(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Response_common> call, Throwable t) {
                dialog.dismiss();
                Toast.makeText(context, t.getMessage(), Toast.LENGTH_SHORT).show();
                Log.e("response", "reset passwrd :" + t.getMessage());
            }
        });
    }
}
