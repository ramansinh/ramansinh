package com.pngstatus.statusimagemaker;

import android.app.Application;
import android.content.Context;

import com.facebook.ads.AdSettings;
import com.facebook.ads.AudienceNetworkAds;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

import static com.pngstatus.statusimagemaker.Utils.BuildConfig.DEBUG;

public class MyApplication extends Application
        implements AudienceNetworkAds.InitListener {
    @Override
    public void onCreate() {
        super.onCreate();
        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });

        initialize(getApplicationContext());
//        OneSignal.disablePush(boolean)
        /* OneSignal.setLogLevel(OneSignal.LOG_LEVEL.VERBOSE, OneSignal.LOG_LEVEL.NONE);
        OneSignal.setAppId(getResources().getString(R.string.onesignal_app_id));
        OneSignal.initWithContext(this);
        OneSignal.unsubscribeWhenNotificationsAreDisabled(true);

        if (isNotificationDisable()){
            OneSignal.disablePush(false);
            Toast.makeText(this, "false", Toast.LENGTH_SHORT).show();
        } else {
            OneSignal.disablePush(true);
            Toast.makeText(this, "true", Toast.LENGTH_SHORT).show();
        }

        SharedPreferences mPrefs = PreferenceManager.getDefaultSharedPreferences(this);
        this.isNotificationDisable = mPrefs.getBoolean(ONESIGNAL_NOTIFICATION, false);

        public boolean isNotificationDisable() {
            return isNotificationDisable;
        }

        public void setIsNotificationDisable(boolean isNotificationDisable) {
            this.isNotificationDisable = isNotificationDisable;
            SharedPreferences mPrefs = PreferenceManager.getDefaultSharedPreferences(this);
            SharedPreferences.Editor editor = mPrefs.edit();
            editor.putBoolean(ONESIGNAL_NOTIFICATION, isNotificationDisable);
            editor.apply();
        }*/
    }
    static void initialize(Context context) {
        if (!AudienceNetworkAds.isInitialized(context)) {
            if (DEBUG) {
                AdSettings.turnOnSDKDebugger(context);
            }

            AudienceNetworkAds
                    .buildInitSettings(context)
                    .withInitListener(new MyApplication())
                    .initialize();
        }

    }
    @Override
    public void onInitialized(AudienceNetworkAds.InitResult initResult) {

    }
}
