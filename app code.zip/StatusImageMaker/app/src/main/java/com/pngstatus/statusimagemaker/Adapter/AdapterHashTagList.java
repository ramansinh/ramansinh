package com.pngstatus.statusimagemaker.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.pngstatus.statusimagemaker.R;

import java.util.ArrayList;


public class AdapterHashTagList extends RecyclerView.Adapter<AdapterHashTagList.ItemViewHolder> {
    Context context;
    int resource;
    ArrayList<String> arrayList = new ArrayList<>();

    public AdapterHashTagList(Context context, ArrayList<String> data) {
        this.context = context;
        this.arrayList = data;
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.row_status_list, parent, false);
        ItemViewHolder vh = new ItemViewHolder(view, arrayList);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull final ItemViewHolder holder, final int position) {
        holder.set_data(position);
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class ItemViewHolder extends RecyclerView.ViewHolder {
        View itemView;
        ArrayList<String> data;
//        TextView tv_name,tv_postcode,tv_cpmlited;


        public ItemViewHolder(View itemView, ArrayList<String> data) {
            super(itemView);
            this.itemView = itemView;
            this.data = data;
//            tv_name = itemView.findViewById(R.id.tv_name);


        }

        public void set_data(final int position) {

        }
    }


}
