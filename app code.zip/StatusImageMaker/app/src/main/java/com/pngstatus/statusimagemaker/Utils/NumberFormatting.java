package com.pngstatus.statusimagemaker.Utils;

import java.text.DecimalFormat;
import java.text.NumberFormat;

public class NumberFormatting {
    NumberFormat numberFormat;
    long str, newstring;
    String returnstring;

    public String formateNumbers(String string) {
        numberFormat = new DecimalFormat("##,##,##,##,###");

//        str = Long.parseLong(string);

        returnstring = numberFormat.format(Double.parseDouble(string));

        return returnstring;
    }

    public String DecimalformateNumbers(String string) {
        DecimalFormat numberFormat = new DecimalFormat("#0.00");

        returnstring = numberFormat.format(Double.parseDouble(string));

        return returnstring;
    }
    public String DoubleToInt(String string){
        double d = Double.parseDouble(string);
        int i = (int) d;
        String returnstring=i+"";
        return returnstring;
    }
    public String prettyCount( Number number) {

        char[] suffix = {' ', 'k', 'M', 'B', 'T', 'P', 'E'};
        long numValue = number.longValue();
        int value = (int) Math.floor(Math.log10(numValue));
        int base = value / 3;
        if (value >= 3 && base < suffix.length) {
            return new DecimalFormat("#0.0").format(numValue / Math.pow(10, base * 3)) + suffix[base];
        } else {
            return new DecimalFormat("#,##0").format(numValue);
        }
    }
    public static String CountFormat(String count) {
        Double number=Double.parseDouble(count);
        DecimalFormat df = new DecimalFormat("#.#");
        String numberString = "";

        if (Math.abs(number / 1000000) >= 1) {
            numberString = df.format(number / 1000000.0) + "m";

        } else if (Math.abs(number / 1000.0) >= 1) {
            numberString = df.format(number / 1000.0) + "k";

        } else {
//            numberString = number.toString();
            numberString = count;

        }
        return numberString;
    }

}
