package com.pngstatus.statusimagemaker.model;

import com.google.gson.annotations.SerializedName;

public class model_user_action_list_data {
    @SerializedName("id")
    private String id;
    @SerializedName("user_id")
    private String user_id;

}
