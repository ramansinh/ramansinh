package com.pngstatus.statusimagemaker;

import android.app.Activity;
import android.content.Context;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;


import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.facebook.ads.Ad;
import com.facebook.ads.InterstitialAdListener;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.pngstatus.statusimagemaker.Activity.CustomEditorActivity;
import com.pngstatus.statusimagemaker.Activity.LoginActivity;
import com.pngstatus.statusimagemaker.Fragment.CategoryFragment;
import com.pngstatus.statusimagemaker.Fragment.FavouriteFragment;
import com.pngstatus.statusimagemaker.Fragment.HomeFragment;
import com.pngstatus.statusimagemaker.Fragment.ProfileFragment;
import com.pngstatus.statusimagemaker.Utils.LocaleHelper;
import com.pngstatus.statusimagemaker.Utils.Popup_LogIn;
import com.pngstatus.statusimagemaker.model.Response_active_ad;
import com.pngstatus.statusimagemaker.model.Model_active_ad;
import com.pngstatus.statusimagemaker.Retrofit.RetrofitClient;
import com.pngstatus.statusimagemaker.Retrofit.RetrofitInterface;
import com.pngstatus.statusimagemaker.Utils.Constance;
import com.pngstatus.statusimagemaker.Utils.Prefs;

import java.io.File;
import java.util.Timer;
import java.util.TimerTask;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    public Context context;
    public Activity activity;
    boolean doubleBackToExitPressedOnce = false;

    @BindView(R.id.logo)
    public ImageView logo;
    @BindView(R.id.ivBack)
    public ImageView ivBack;
    @BindView(R.id.tvTitle)
    public TextView tvTitle;
    @BindView(R.id.ivShare)
    public Button ivShare;
    @BindView(R.id.ivSave)
    public Button ivSave;
    @BindView(R.id.btnLogout)
    public Button btnLogout;
    @BindView(R.id.fab)
    public Button fab;

    @BindView(R.id.ivPhotos)
    public ImageView ivPhotos;
    @BindView(R.id.ivCatgry)
    public ImageView ivCatgry;
    @BindView(R.id.ivProfile)
    public ImageView ivProfile;
    @BindView(R.id.ivLogin)
    public ImageView ivLogin;
    @BindView(R.id.tvPhotos)
    public TextView tvPhotos;
    @BindView(R.id.tvCatgry)
    public TextView tvCatgry;
    @BindView(R.id.tvFvrt)
    public TextView tvFvrt;
    @BindView(R.id.ivFvrt)
    public ImageView ivFvrt;
    @BindView(R.id.tvProfile)
    public TextView tvProfile;
    @BindView(R.id.tvLogin)
    public TextView tvLogin;

    @BindView(R.id.ll_adView)
    public LinearLayout ll_adView;
    public com.facebook.ads.AdView fadView;
    public Timer timer;
    public TimerTask hourlyTask;
    public InterstitialAd googleFullscreen;
    private CountDownTimer countDownTimer;
    private long timerMilliseconds;
    public com.facebook.ads.InterstitialAd fbFullscreen;
    Model_active_ad model;
    Runnable runnable;
    public String backStateName = "";
    int count = 0;

    public static MainActivity instance = null;
    //    LinearLayout banner_container;
    //    ActivityMainBinding binding;

    public MainActivity() {
        instance = MainActivity.this;
    }

    public static MainActivity getInstance() {
        if (instance == null) {
            instance = new MainActivity();
        }
        return instance;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
     /*   getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE,
                WindowManager.LayoutParams.FLAG_SECURE);*/
        setContentView(R.layout.activity_main);
        if (Build.VERSION.SDK_INT < 16) {
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                    WindowManager.LayoutParams.FLAG_FULLSCREEN);
        } else {
            View decorView = getWindow().getDecorView();
            // Hide Status Bar.
            int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
            decorView.setSystemUiVisibility(uiOptions);
        }

        context = MainActivity.this;
        activity = MainActivity.this;
        ButterKnife.bind(this);
        handlerStart();
        String applang = Prefs.getPrefString(context, Constance.select_app_lang, "en");
        LocaleHelper.setLocale(context, applang);
//        binding = DataBindingUtil.setContentView(this, R.layout.activity_main);
//        googlead.setAdUnitId("ca-app-pub-3940256099942544/6300978111");
        /*IMG_16_9_APP_INSTALL#2029572424039676_2029575434039375*/

       /* fadView = new com.facebook.ads.AdView(context, getResources().getString(R.string.fb_id), AdSize.BANNER_HEIGHT_50);
        LinearLayout adContainer = findViewById(R.id.banner_container);
//        adContainer.removeAllViews();
//        adContainer.addView(adContainer);
        fadView.loadAd();*/


//        moveFragment(new HomeFragment());
        if (getIntent().hasExtra("catgry")) {
            setHomeFragment(getIntent().getStringExtra("catgry"));
        } else {
            setHomeFragment("");
        }

        boolean islogin = Prefs.getPrefBoolean(context, Constance.islogin, false);
        if (islogin) {
            ivLogin.setVisibility(View.GONE);
            tvLogin.setVisibility(View.GONE);
            ivProfile.setVisibility(View.VISIBLE);
            tvProfile.setVisibility(View.VISIBLE);
        } else {
            ivLogin.setVisibility(View.VISIBLE);
            tvLogin.setVisibility(View.VISIBLE);
            ivProfile.setVisibility(View.GONE);
            tvProfile.setVisibility(View.GONE);
        }

        active_ad();

        Log.e("login", "token : " + Prefs.getPrefString(context, Constance.api_token, ""));
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        ivLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Constance.frmCat=false;
            /*    Intent intent=new Intent(context, LoginActivity.class);
                intent.putExtra("from","activity");
                startActivity(intent);*/
              /*  Popup_LogIn popupLogIn = new Popup_LogIn();
                popupLogIn.Popup_LogIn(context);*/
                Intent intent = new Intent(context, LoginActivity.class);
                intent.putExtra("from", "activity");
                context.startActivity(intent);
            }
        });

        ivPhotos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Constance.frmCat=false;
//                Constance.AllowToOpenAdvertise=true;
                setHomeFragment("");
//                moveFragment(new HomeFragment());
            }
        });

        ivCatgry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Constance.frmCat){
                    Constance.frmCat=false;
                    onBackPressed();
                }else {
                    moveFragment(new CategoryFragment());
                }
            }
        });

        ivFvrt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Constance.frmCat=false;
                boolean islogin = Prefs.getPrefBoolean(context, Constance.islogin, false);
                if (islogin) {

                    moveFragment(new FavouriteFragment());
                } else {
                    Popup_LogIn popupLogIn = new Popup_LogIn();
                    popupLogIn.Popup_LogIn(context);
                }
            }
        });

        ivProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Constance.frmCat=false;
//                Constance.AllowToOpenAdvertise=true;
                moveFragment(new ProfileFragment());
            }
        });
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Constance.frmCat=false;
                Intent intent = new Intent(context, CustomEditorActivity.class);
                startActivity(intent);
            }
        });

        File storageDir;
        storageDir =new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)+ "/pngStatus/");
            /*if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                // only for gingerbread and newer versions
                storageDir = new File(context.getExternalFilesDir(null), "/pngStatus/");
//                storageDir = new File(context.getExternalFilesDir(null), "/pngStatus/");
            } else {
                storageDir =new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).toString()+ "/pngStatus/");
//                storageDir = new File(Environment.getExternalStorageDirectory() + "/pngStatus/");
            }*/
        if (storageDir.exists()) {
            Log.e("tag", "exitst file path" + storageDir.getAbsolutePath());
        } else {
            storageDir.mkdirs();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        context = MainActivity.this;
        ButterKnife.bind(this);
        boolean islogin = Prefs.getPrefBoolean(context, Constance.islogin, false);
        if (islogin) {
            ivLogin.setVisibility(View.GONE);
            tvLogin.setVisibility(View.GONE);
            ivProfile.setVisibility(View.VISIBLE);
            tvProfile.setVisibility(View.VISIBLE);
        } else {
            ivLogin.setVisibility(View.VISIBLE);
            tvLogin.setVisibility(View.VISIBLE);
            ivProfile.setVisibility(View.GONE);
            tvProfile.setVisibility(View.GONE);
        }
    }

    @Override
    protected void onDestroy() {
        if (fadView != null) {
            fadView.destroy();
        }
        super.onDestroy();
    }

    public void setHomeFragment(String id) {
        Fragment fragment = new HomeFragment();
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        Bundle args = new Bundle();
        args.putString(Constance.CatId, id);
        fragment.setArguments(args);
        fm.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
        ft.replace(R.id.main_frame, fragment, fragment.getClass().getSimpleName());
        ft.commit();
    }

    public void setFragment() {
        Fragment fragment = new CategoryFragment();
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        fm.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
        ft.replace(R.id.main_frame, fragment, fragment.getClass().getSimpleName());
        ft.commit();
    }

    public void moveFragment(Fragment fragment) {
        String backStateName = fragment.getClass().getName();
//        FragmentManager fm = ((Activity) context).getFragmentManager();
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        boolean fragmentPopped = fm.popBackStackImmediate(backStateName, 0);

//        fm.popBackStack(fragment.getClass().getSimpleName(), FragmentManager.POP_BACK_STACK_INCLUSIVE);
     /*   if (!fragmentPopped) { //fragment not in back stack, create it.
            ft.add(R.id.main_frame, fragment, fragment.getClass().getSimpleName());
            ft.addToBackStack(backStateName);
            ft.commit();
        } else {*/
//            ft.replace(R.id.main_frame, fragment, fragment.getClass().getSimpleName());
        ft.replace(R.id.main_frame, fragment, fragment.getClass().getSimpleName()).addToBackStack(null);
        ft.commit();
//        }
    }

    @Override
    public void onBackPressed() {
//        int fragments = fm.getBackStackEntryCount();
        int fragments = getSupportFragmentManager().getBackStackEntryCount();
        if (getSupportFragmentManager().getBackStackEntryCount() > 0) {
            getSupportFragmentManager().popBackStack();
        } /*else if(fragments == 0) {
            getSupportFragmentManager().popBackStack();
        }*/else {
            if (!doubleBackToExitPressedOnce) {
                this.doubleBackToExitPressedOnce = true;
                Toast.makeText(context, getResources().getString(R.string.press_back_msg), Toast.LENGTH_SHORT).show();
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        doubleBackToExitPressedOnce = false;
                    }
                }, 2000);
            } else {
                super.onBackPressed();
                return;
            }
        }
    }

    public void facebookAd(String adId) {
        if (adId.equals("")){
            adId="IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID";
        }
        ll_adView.removeAllViews();
        fadView = new com.facebook.ads.AdView(this, adId, com.facebook.ads.AdSize.BANNER_HEIGHT_50);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        fadView.setLayoutParams(lp);
        ll_adView.addView(fadView);
        fadView.loadAd();
    }

    public void googleBannerAd(String unitId) {
        ll_adView.removeAllViews();
        AdView adView = new AdView(context);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        adView.setLayoutParams(lp);
        adView.setAdSize(AdSize.BANNER);
        adView.setAdUnitId(unitId);
        ll_adView.addView(adView);
        AdRequest adRequest = new AdRequest.Builder().build();
//        List<String> testDeviceIds = Arrays.asList("33BE2250B43518CCDA7DE426D04EE231");
      /*  RequestConfiguration configuration =
                new RequestConfiguration.Builder().setTestDeviceIds(testDeviceIds).build();
        MobileAds.setRequestConfiguration(configuration);*/

        adView.loadAd(adRequest);
        adView.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                super.onAdClosed();
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                super.onAdFailedToLoad(loadAdError);
            }

            @Override
            public void onAdOpened() {
                super.onAdOpened();
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
            }

            @Override
            public void onAdClicked() {
                super.onAdClicked();
            }

            @Override
            public void onAdImpression() {
                super.onAdImpression();
            }
        });

    }

    public void googleInterstitialAd(String adId) {
//        String  adId = Constance.admob_fullscreen;
        if (adId.equals("")) {
            adId = "ca-app-pub-3940256099942544/1033173712";
        }
        AdRequest adRequest = new AdRequest.Builder().build();

        InterstitialAd.load(context, adId, adRequest, new InterstitialAdLoadCallback() {
            @Override
            public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                super.onAdLoaded(interstitialAd);
                // The mInterstitialAd reference will be null until
                // an ad is loaded.
                googleFullscreen = interstitialAd;
//                if (Constance.isFirstTimeOpen) {
                show_fullScreen_Ad();
//                }
                Log.i("TAG", "onAdLoaded");
                googleFullscreen.setFullScreenContentCallback(new FullScreenContentCallback() {
                    @Override
                    public void onAdDismissedFullScreenContent() {
                        // Called when fullscreen content is dismissed.
                        Log.d("TAG", "The ad was dismissed.");
                        Constance.AllowToOpenAdvertise = false;
                        googleFullscreen = null;
                        handlerStart();
                     /*   stopTask();
                        startTimer();*/
                        googleInterstitialAd(Constance.admob_fullscreen);
                    }

                    @Override
                    public void onAdFailedToShowFullScreenContent(AdError adError) {
                        // Called when fullscreen content failed to show.
                        Log.d("TAG", "The ad failed to show.");
                        googleFullscreen = null;
//                        Constance.AllowToOpenAdvertise = false;
//                        stopTask();
//                        startTimer();

//                        googleInterstitialAd();
                    }

                    @Override
                    public void onAdShowedFullScreenContent() {
                        // Called when fullscreen content is shown.
                        // Make sure to set your reference to null so you don't
                        // show it a second time.
//                        mInterstitialAd = null;
                        Log.d("TAG", "The ad was shown.");
//                        Constance.AllowToOpenAdvertise = false;
//                        stopTask();
//                        startTimer();
//                        handlerStart();
//                        googleInterstitialAd();
                    }
                });
               /* if (Constance.isFirstTimeOpen){
                    googleFullscreen.show(activity);
                    Constance.isFirstTimeOpen=false;
                }*/
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                super.onAdFailedToLoad(loadAdError);
                // Handle the error
                Log.i("TAG", loadAdError.getMessage());
//                Constance.AllowToOpenAdvertise = false;
//                googleFullscreen = null;
//                stopTask();
//                startTimer();
//                handlerStart();
//                googleInterstitialAd();
            }
        });
    }

    public void fbInterstitialAd() {
        String adId = Constance.facebook_fullscreen;
        fbFullscreen = new com.facebook.ads.InterstitialAd(this, adId);
        InterstitialAdListener fblistener = new InterstitialAdListener() {
            @Override
            public void onInterstitialDisplayed(Ad ad) {
//                stopTask();
//                startTimer();
            }

            @Override
            public void onInterstitialDismissed(Ad ad) {
//                stopTask();
//                startTimer();
                Constance.AllowToOpenAdvertise = false;
                handlerStart();
                fbInterstitialAd();
            }

            @Override
            public void onError(Ad ad, com.facebook.ads.AdError adError) {
//                stopTask();
//                startTimer();
            }

            @Override
            public void onAdLoaded(Ad ad) {
                fbFullscreen.show();
            }

            @Override
            public void onAdClicked(Ad ad) {
//                stopTask();
//                startTimer();
//                fbInterstitialAd();
            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        };
        fbFullscreen.loadAd(fbFullscreen.buildLoadAdConfig()
                .withAdListener(fblistener)
                .build());
    }

    public void active_ad() {

        String token = Prefs.getPrefString(context, Constance.api_token, "");
        RetrofitInterface retrofitInterface = RetrofitClient.getClient().create(RetrofitInterface.class);
        Call<Response_active_ad> call = retrofitInterface.active_ad(token);
        call.enqueue(new Callback<Response_active_ad>() {
            @Override
            public void onResponse(Call<Response_active_ad> call, Response<Response_active_ad> response) {
                if (response != null && response.body() != null) {
                    if (response.body().getResult() != null && response.body().getResult().equals("1")) {
//                        response.body().getRecords().get(0).setAdmob_banner_id("ca-app-pub-3940256099942544/6300978111");
                        if (response.body().getRecords() != null && response.body().getRecords().size() > 0) {
                            if (response.body().getRecords().get(0) != null) {
                                model = response.body().getRecords().get(0);
//                        model=new Model_active_ad("ca-app-pub-3940256099942544/6300978111");
//                        binding.adView.setAdUnitId("ca-app-pub-3940256099942544/6300978111");
                                if (response.body().getRecords().get(0).getActive_ads() != null) {
                                    Constance.active_ads = response.body().getRecords().get(0).getActive_ads();
                                    /*if ( Constance.active_ads .equals("admob_ad")){
                                        googleBannerAd(model.getAdmob_banner_id());
                                    }else {
                                    }*/
                                }
                                if (response.body().getRecords().get(0).getAdmob_banner_id() != null) {
                                    Constance.admob_banner = response.body().getRecords().get(0).getAdmob_banner_id();
                                    if (Constance.active_ads.equals("admob_ad")) {
                                        googleBannerAd(model.getAdmob_banner_id());
                                    }
                                }
                                if (response.body().getRecords().get(0).getAdmob_fullscreen_id() != null) {
                                    Constance.admob_fullscreen = response.body().getRecords().get(0).getAdmob_fullscreen_id();
//                                    googleInterstitialAd( Constance.admob_fullscreen);
                                    if (Constance.active_ads.equals("admob_ad")) {
                                        googleInterstitialAd(Constance.admob_fullscreen);
                                    }
                                }
                                if (response.body().getRecords().get(0).getAdmob_nativex_id() != null) {
                                    Constance.admob_nativex = response.body().getRecords().get(0).getAdmob_nativex_id();
                                }

                                if (response.body().getRecords().get(0).getFacebook_banner_id() != null) {
                                    Constance.facebook_banner = response.body().getRecords().get(0).getFacebook_banner_id();
                                    if (!Constance.active_ads.equals("admob_ad")) {
                                        facebookAd(Constance.facebook_banner);
                                    }
                                }
                                if (response.body().getRecords().get(0).getFacebook_fullscreen_id() != null) {
                                    Constance.facebook_fullscreen = response.body().getRecords().get(0).getFacebook_fullscreen_id();
                                    fbInterstitialAd();
                                }

                                show_fullScreen_Ad();

                            }
                        }
//                        binding.setModel(model);
//                        binding.adView.setAdSize(AdSize.BANNER);
//                        binding.adView.setAdUnitId("ca-app-pub-3940256099942544/6300978111");
//                        String unitid=binding.adView.getAdUnitId();
//                        AdRequest adRequest = new AdRequest.Builder().build();
//                        binding.adView.loadAd(adRequest);
                    }
                }
            }

            @Override
            public void onFailure(Call<Response_active_ad> call, Throwable t) {
//                Toast.makeText(context, t.getMessage(), Toast.LENGTH_SHORT).show();
                Log.e("response", "reset passwrd :" + t.getMessage());
            }
        });
    }

    public void handlerStart() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
//                displayAdMob();
                Constance.AllowToOpenAdvertise = true;
//                 show_fullScreen_Ad();
                Log.e("tag", "handler : " + Constance.AllowToOpenAdvertise);
            }
        }, 1000 * 40);
    }

    public void show_fullScreen_Ad() {
        if (Constance.AllowToOpenAdvertise) {
            if (Constance.active_ads.equals("admob_ad")) {
                if (googleFullscreen != null) {
                    googleFullscreen.show(activity);
                } else {
//                    Toast.makeText(context, "Ad did not load", Toast.LENGTH_SHORT).show();
//                    googleInterstitialAd();
//            startGame();
                }
            } else {
                if (fbFullscreen != null && fbFullscreen.isAdLoaded()) {
                    fbFullscreen.show();
                }
            }
        } else {

        }
    }

    /*  public void startTimer() {

     *//*  timer = new Timer();
        hourlyTask = new TimerTask() {
            @Override
            public void run() {
                if (!Constance.AllowToOpenAdvertise) {
//                    show_fullScreen_Ad();
                    Constance.AllowToOpenAdvertise = true;
//                    Log.e("tag","true");
//                    Toast.makeText(context, "true", Toast.LENGTH_SHORT).show();
                    stopTask();
                } else {
//                    Constance.AllowToOpenAdvertise = false;
                }
            }
        };
        Constance.AllowToOpenAdvertise = true;
        if (timer != null) {
            timer.schedule(hourlyTask, 0, 1000 * 45);
        }*//*

        timer = new Timer();
        hourlyTask = new TimerTask() {
            @Override
            public void run() {
                if (!Constance.isFirstTimeOpen) {
                    Constance.AllowToOpenAdvertise = true;
                    stopTask();
                } else {
                    Constance.isFirstTimeOpen = false;
                }
            }
        };

        Constance.isFirstTimeOpen = true;
        if (timer != null) {
            timer.schedule(hourlyTask, 0, 1000 * 45);
        }
    }

    public void stopTask() {
        if (hourlyTask != null) {
            Log.d("TIMER", "timer canceled");
            hourlyTask.cancel();
        }
    }*/

    private void createTimer() {
        // Create the game timer, which counts down to the end of the level
        // and shows the "retry" button.
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }

        countDownTimer = new CountDownTimer(1000 * 45, 50) {
            @Override
            public void onTick(long millisUnitFinished) {
                timerMilliseconds = millisUnitFinished;
            }

            @Override
            public void onFinish() {
//                gameIsInProgress = false;
//                retryButton.setVisibility(View.VISIBLE);
            }
        };
    }

    private void restart(Fragment fragment) {
      /*  Intent intent = getIntent();
        finish();
        startActivity(intent);*/
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
//        Bundle args = new Bundle();
//        args.putString(Constance.maincategoryId, getId);
//        fragment.setArguments(args);
//        fm.popBackStack(new HomeFragment().getTag(), FragmentManager.POP_BACK_STACK_INCLUSIVE);
//        ft.replace(R.id.main_frame, fragment, fragment.getClass().getSimpleName());
        ft.add(R.id.main_frame, fragment, new HomeFragment().getTag());
        ft.replace(R.id.main_frame, fragment, fragment.getClass().getSimpleName()).addToBackStack(null);
        ft.commit();

    }

    public void clearBackStackInclusive(String tag) {
        getSupportFragmentManager().popBackStack(tag, FragmentManager.POP_BACK_STACK_INCLUSIVE);
    }

}
