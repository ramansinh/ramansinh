package com.pngstatus.statusimagemaker.Adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.pngstatus.statusimagemaker.Activity.FullScrnImgActivity;
import com.pngstatus.statusimagemaker.MainActivity;
import com.pngstatus.statusimagemaker.R;
import com.pngstatus.statusimagemaker.Utils.Constance;
import com.pngstatus.statusimagemaker.model.mode_file_list;
import com.pngstatus.statusimagemaker.model.model_category_data;

import java.util.ArrayList;

public class AdapterDownloadImg extends RecyclerView.Adapter<AdapterDownloadImg.ItemViewHolder> {
    Context context;
    int resource;
    ArrayList<mode_file_list> arrayList = new ArrayList<>();

    public AdapterDownloadImg(Context context, ArrayList<mode_file_list> data) {
        this.context = context;
        this.arrayList = data;
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.row_image_list, parent, false);
        ItemViewHolder vh = new ItemViewHolder(view, arrayList);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull final ItemViewHolder holder, final int position) {
        holder.set_data(position);
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class ItemViewHolder extends RecyclerView.ViewHolder {
        View itemView;
        ArrayList<mode_file_list> data;
        ImageView iv_img;

        public ItemViewHolder(View itemView, ArrayList<mode_file_list> data) {
            super(itemView);
            this.itemView = itemView;
            this.data = data;

            iv_img = itemView.findViewById(R.id.iv_img);
        }

        public void set_data(final int position) {
            if (data.get(position).getPath() != null) {
                Glide.with(context).load(data.get(position).getPath()).into(iv_img);
            }
//            Constance.catgry=true;
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent=new Intent(context, FullScrnImgActivity.class);
                    intent.putExtra(Constance.img_url,data.get(position).getPath().getAbsolutePath());
                    context.startActivity(intent);

//                    moveFragment2(new HomeFragment(),data.get(position).getId());
/*
                    if (Constance.isFrstym){
                        Constance.isFrstym=false;
                        Constance.isBack=true;
                        Intent intent = new Intent(context, MainActivity.class);
                        intent.putExtra("catgry", data.get(position).getId());
                        context.startActivity(intent);
                    }else {
                        if (Constance.isBack){
                            Constance.isBack=false;
                            ((Activity) context).finish();
                            Intent intent = new Intent(context, MainActivity.class);
                            intent.putExtra("catgry", data.get(position).getId());
                            context.startActivity(intent);
                            ((Activity) context).finish();
                        }
                    }*/
                }
            });
        }
    }

    public void moveFragment(Fragment fragment, String id) {
//        FragmentManager fm = ((Activity) context).getFragmentManager();
        FragmentManager fm = ((FragmentActivity) context).getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        Bundle args = new Bundle();
        args.putString(Constance.CatId, id);
        fragment.setArguments(args);
        fm.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
        ft.replace(R.id.main_frame, fragment, fragment.getClass().getSimpleName());
//        ft.replace(R.id.main_frame, fragment, fragment.getClass().getSimpleName()).addToBackStack(null);
        ft.commit();
    }

    public void moveFragment2(Fragment fragment, String id) {
//        FragmentManager fm = ((Activity) context).getFragmentManager();
        FragmentManager fm = ((FragmentActivity) context).getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        Bundle args = new Bundle();
        args.putString(Constance.CatId, id);
        fragment.setArguments(args);
//        fm.popBackStack(fragment.getClass().getSimpleName(), FragmentManager.POP_BACK_STACK_INCLUSIVE);
//        ft.replace(R.id.main_frame, fragment, fragment.getClass().getSimpleName());
        ft.replace(R.id.main_frame, fragment, fragment.getClass().getSimpleName()).addToBackStack(null);
        ft.commit();
    }
}
