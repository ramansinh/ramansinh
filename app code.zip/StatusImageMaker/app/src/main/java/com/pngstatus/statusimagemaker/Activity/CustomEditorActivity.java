package com.pngstatus.statusimagemaker.Activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.util.Log;
import android.util.TypedValue;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.facebook.ads.Ad;
import com.facebook.ads.InterstitialAdListener;
import com.flask.colorpicker.ColorPickerView;
import com.flask.colorpicker.OnColorSelectedListener;
import com.flask.colorpicker.builder.ColorPickerClickListener;
import com.flask.colorpicker.builder.ColorPickerDialogBuilder;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.pngstatus.statusimagemaker.Adapter.AdapterList;
import com.pngstatus.statusimagemaker.Retrofit.RetrofitClient;
import com.pngstatus.statusimagemaker.Retrofit.RetrofitInterface;
import com.pngstatus.statusimagemaker.Utils.LocaleHelper;
import com.pngstatus.statusimagemaker.Utils.Popup_success;
import com.pngstatus.statusimagemaker.Utils.Prefs;
import com.pngstatus.statusimagemaker.model.Model_active_ad;
import com.pngstatus.statusimagemaker.model.Response_active_ad;
import com.pngstatus.statusimagemaker.model.TextviewModel;
import com.pngstatus.statusimagemaker.model.model_font;
import com.pngstatus.statusimagemaker.R;
import com.pngstatus.statusimagemaker.Utils.BuildConfig;
import com.pngstatus.statusimagemaker.Utils.Constance;
import com.pngstatus.statusimagemaker.Utils.ImageSelection;
import com.pngstatus.statusimagemaker.Utils.NumberFormatting;
import com.yalantis.ucrop.UCrop;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Timer;
import java.util.TimerTask;

import butterknife.BindView;
import butterknife.ButterKnife;
import id.zelory.compressor.Compressor;
import io.github.hyuwah.draggableviewlib.DraggableListener;
import io.github.hyuwah.draggableviewlib.DraggableView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CustomEditorActivity extends AppCompatActivity {
    Context context;

    @BindView(R.id.ivShare)
    Button ivShare;
    @BindView(R.id.ivSave)
    Button ivSave;
    @BindView(R.id.tvTitle)
    TextView tvTitle;

    final int TAKE_PHOTO_FROM_CAMARA = 0, TAKE_PHOTO_FROM_GALLARY = 1;
    String[] permissionsRequired = {Manifest.permission.CAMERA,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_EXTERNAL_STORAGE};
    private final int PERMISSION_CALLBACK_CONSTANT = 200;
    boolean imgselected = false;
    String realPath = "", imgpath1 = "";
    Bitmap bitmap;

    @BindView(R.id.tv_pos)
    TextView tv_pos;
    @BindView(R.id.tv_font_size)
    TextView tv_font_size;
    @BindView(R.id.tv_font_shadow)
    TextView tv_font_shadow;
    @BindView(R.id.tv_img_shadow)
    TextView tv_img_shadow;
    @BindView(R.id.tv_font_spacing)
    TextView tv_font_spacing;
    @BindView(R.id.tv_brightnes)
    TextView tv_brightnes;
    @BindView(R.id.tv_contrast)
    TextView tv_contrast;
    @BindView(R.id.iv_main_img)
    ImageView iv_main_img;
    @BindView(R.id.rootview)
    RelativeLayout rootview;
    @BindView(R.id.iv_imgpick)
    ImageView iv_imgpick;
    @BindView(R.id.iv_shadow_img)
    ImageView iv_shadow_img;
    @BindView(R.id.iv_addTxt)
    ImageView iv_addTxt;
    @BindView(R.id.iv_fonts)
    ImageView iv_fonts;
    @BindView(R.id.iv_color)
    ImageView iv_color;
    @BindView(R.id.iv_lft_align)
    ImageView iv_lft_align;
    @BindView(R.id.iv_cntr_align)
    ImageView iv_cntr_align;
    @BindView(R.id.iv_right_align)
    ImageView iv_right_align;
    @BindView(R.id.iv_delete)
    ImageView iv_delete;
    @BindView(R.id.iv_bold)
    ImageView iv_bold;
    @BindView(R.id.iv_text_img)
    ImageView iv_text_img;
    @BindView(R.id.iv_shadow)
    ImageView iv_shadow;
    @BindView(R.id.rl_final_img)
    RelativeLayout rl_final_img;
    @BindView(R.id.iv_reset)
    ImageView iv_reset;
    @BindView(R.id.sb_fontsize)
    SeekBar sb_fontsize;
    @BindView(R.id.sb_brightnes)
    SeekBar sb_brightnes;
    @BindView(R.id.sb_contrast)
    SeekBar sb_contrast;
    @BindView(R.id.sb_spacing)
    SeekBar sb_spacing;
    @BindView(R.id.sb_fontshadow)
    SeekBar sb_fontshadow;
    @BindView(R.id.sb_imgshadow)
    SeekBar sb_imgshadow;
    @BindView(R.id.btn_reset)
    Button btn_reset;
    Uri sourceUri, destinationUri;

    private static final int REQUEST_SELECT_PICTURE_FOR_FRAGMENT = 0x02;
    private static final String SAMPLE_CROPPED_IMAGE_NAME = "SampleCropImage";

    private int requestMode = BuildConfig.RequestMode;
    PopupWindow popup = new PopupWindow();
    WindowManager.LayoutParams params = null;
    String newtext = "";
    int textviewid = 0;
    int crnt_pos = 0;
    View mview;
    boolean shadow = true, isbold = false;
    ArrayList<TextviewModel> dragbltext = new ArrayList<>();
    TextView newtextview;
    DraggableView<TextView> newdragableview;
    Bitmap bitmapBrightnessMaster, bitmapContrastMaster;
    int colorIndex = 0;
    int filterIndex = 0;
    float Ccontrast = 1, Cbrightness = 0;
    PorterDuff.Mode[] modes = new PorterDuff.Mode[]{
            PorterDuff.Mode.ADD, PorterDuff.Mode.DARKEN, PorterDuff.Mode.MULTIPLY,
            PorterDuff.Mode.OVERLAY, PorterDuff.Mode.LIGHTEN,
            PorterDuff.Mode.SCREEN};
    int[] colors = new int[]{
            R.color.dark_seagreen, R.color.deep_coral, R.color.hot_seagreen, R.color.mango_sorbet};
    Bitmap bmp;
    Typeface ctf;
    @BindView(R.id.ll_adView)
    public LinearLayout ll_adView;
    public  com.facebook.ads.AdView fadView;
    public  Timer timer;
    public  TimerTask hourlyTask;
    public  InterstitialAd googleFullscreen;
    public  com.facebook.ads.InterstitialAd fbFullscreen;
    Model_active_ad model;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom_editor);
        context = CustomEditorActivity.this;
        ButterKnife.bind(this);
        checkPermission();
        if (Build.VERSION.SDK_INT < 16) {
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                    WindowManager.LayoutParams.FLAG_FULLSCREEN);
        } else {
            View decorView = getWindow().getDecorView();
            // Hide Status Bar.
            int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
            decorView.setSystemUiVisibility(uiOptions);
        }

        rootview.removeAllViews();
        dragbltext.clear();
        ivSave.setVisibility(View.VISIBLE);
        ivShare.setVisibility(View.VISIBLE);

      /* if (getIntent().hasExtra("bitmap")){
           File file=new File(getIntent().getStringExtra("bitmap"));
           iv_main_img.setImageBitmap(fileToBitmap(file));
           imgselected=true;
           shadow=false;
           iv_shadow_img.setVisibility(View.GONE);
       }*/
       if (getIntent().hasExtra("imgpath")){
           File file=new File(getIntent().getStringExtra("imgpath"));
           String frameUrl=(getIntent().getStringExtra("frameUrl"));
           iv_main_img.setImageBitmap(fileToBitmap(file));
           Glide.with(context).load(frameUrl).into(iv_text_img);
           imgselected=true;
           shadow=false;
           iv_shadow_img.setVisibility(View.GONE);
       }

        String applang = Prefs.getPrefString(context, Constance.select_app_lang, "en");
        LocaleHelper.setLocale(context,applang);
        iv_imgpick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pickFromGallery();
            }
        });
        iv_addTxt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addTextDialog();
            }
        });
        handlerStart();
        active_ad();

        sb_fontsize.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                if (dragbltext.size() > 0) {
                    if (rootview.getChildCount() > 0) {
                        newtextview = findViewById(dragbltext.get(crnt_pos).getId());
//                        newtextview.setTextSize((float) i);
                        newtextview.setTextSize(TypedValue.COMPLEX_UNIT_PX, (float) i);
                        tv_font_size.setText(getResources().getString(R.string.font_size_dot) + (newtextview.getTextSize()));
                    } else {
                        tv_font_size.setText(getResources().getString(R.string.font_size_dot));
//                        Toast.makeText(context,  getResources().getString(R.string.add_text_dot), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    tv_font_size.setText(getResources().getString(R.string.font_size_dot));
//                    Toast.makeText(context,  getResources().getString(R.string.add_text_dot), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                if (dragbltext.size() > 0) {
                    if (rootview.getChildCount() > 0) {
                    } else {
//                        tv_font_size.setText("Font Size: ");
                        Toast.makeText(context, getResources().getString(R.string.add_text_dot), Toast.LENGTH_SHORT).show();
                    }
                } else {
//                    tv_font_size.setText("Font Size: ");
                    Toast.makeText(context, getResources().getString(R.string.add_text_dot), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        sb_fontshadow.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                if (dragbltext.size() > 0) {
                    if (rootview.getChildCount() > 0) {
                        tv_font_shadow.setText(getResources().getString(R.string.font_shadow_dot) + i);
                        newtextview = findViewById(dragbltext.get(crnt_pos).getId());
                        if (i < 3) {
                            newtextview.setShadowLayer((float) i, 0, 0, newtextview.getShadowColor());
                        } else if (i > 2 && i < 10) {
                            newtextview.setShadowLayer((float) i, 5, 0, newtextview.getShadowColor());
                        } else {
                            newtextview.setShadowLayer((float) i, 10, 0, newtextview.getShadowColor());
                        }
                    } else {
                        tv_font_shadow.setText(getResources().getString(R.string.font_shadow_dot));
//                        Toast.makeText(context,  getResources().getString(R.string.add_text_dot), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    tv_font_shadow.setText(getResources().getString(R.string.font_shadow_dot));
//                    Toast.makeText(context,  getResources().getString(R.string.add_text_dot), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                if (dragbltext.size() > 0) {
                    if (rootview.getChildCount() > 0) {

                    } else {
//                        tv_font_shadow.setText("Font Shadow: ");
                        Toast.makeText(context, getResources().getString(R.string.add_text_dot), Toast.LENGTH_SHORT).show();
                    }
                } else {
//                    tv_font_shadow.setText("Font Shadow: ");
                    Toast.makeText(context, getResources().getString(R.string.add_text_dot), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        sb_spacing.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                NumberFormatting formatting = new NumberFormatting();
                if (dragbltext.size() > 0) {
                    if (rootview.getChildCount() > 0) {
                        tv_font_spacing.setText("Spacing: " + formatting.DecimalformateNumbers(((float) i / 100) + ""));
                        newtextview = findViewById(dragbltext.get(crnt_pos).getId());
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                            newtextview.setLetterSpacing((float) i / 100);
                        }
                    } else {
                        tv_font_spacing.setText("Spacing: ");
//                        Toast.makeText(context,  getResources().getString(R.string.add_text_dot), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    tv_font_spacing.setText("Spacing: ");
//                    Toast.makeText(context,  getResources().getString(R.string.add_text_dot), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                if (dragbltext.size() > 0) {
                    if (rootview.getChildCount() > 0) {
                        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.LOLLIPOP) {
                            Toast.makeText(context, getResources().getString(R.string.yu_mobilevrsn_not_sprtd), Toast.LENGTH_SHORT).show();
                        }
                    } else {
//                        tv_font_spacing.setText("Spacing: ");
                        Toast.makeText(context, getResources().getString(R.string.add_text_dot), Toast.LENGTH_SHORT).show();
                    }
                } else {
//                    tv_font_spacing.setText("Spacing: ");
                    Toast.makeText(context, getResources().getString(R.string.add_text_dot), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        sb_imgshadow.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                NumberFormatting formatting = new NumberFormatting();
                if (imgselected) {
                    //alpha between 0 and 1
                    if (shadow) {
                        tv_img_shadow.setText(getResources().getString(R.string.img_shadow_dot) + formatting.DecimalformateNumbers(((float) i / 255) + ""));
                        iv_shadow_img.setAlpha((float) i / 255);
                    } else {
                        tv_img_shadow.setText(getResources().getString(R.string.img_shadow_dot));
                    }
//                    iv_shadow_img.setAlpha((float) i / 100);
                   /* if (Build.VERSION.SDK_INT < 16) {

                    } else {

                        iv_shadow_img.setAlpha(i / 100);
                    }*/

                } else {
                    tv_img_shadow.setText(getResources().getString(R.string.img_shadow_dot));
//                    Toast.makeText(context, "Image not selected", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                if (imgselected) {

                } else {
                    tv_img_shadow.setText(getResources().getString(R.string.img_shadow_dot));
                    Toast.makeText(context, getResources().getString(R.string.img_not_slcted), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        sb_brightnes.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                if (imgselected) {
                    tv_brightnes.setText(getResources().getString(R.string.brightnes_dot) + i);
                } else {
                    tv_brightnes.setText(getResources().getString(R.string.brightnes_dot));
//                    Toast.makeText(context, "Image not selected", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                if (!imgselected) {
                    Toast.makeText(context, getResources().getString(R.string.img_not_slcted), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (imgselected) {
//                    loadBitmapBrightness();

                    iv_main_img.setImageBitmap(changeContrastBrightness(Ccontrast, (float) seekBar.getProgress()));
                }
            }
        });
        sb_contrast.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                if (imgselected) {
                    tv_contrast.setText(getResources().getString(R.string.contrast_dot) + i);
                } else {
//                    Toast.makeText(context, "Image not selected", Toast.LENGTH_SHORT).show();
                    tv_contrast.setText(getResources().getString(R.string.contrast_dot));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                if (!imgselected) {
                    Toast.makeText(context, getResources().getString(R.string.img_not_slcted), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (imgselected) {
                    iv_main_img.setImageBitmap(changeContrastBrightness((float) seekBar.getProgress(), Cbrightness));
                }
            }
        });
        iv_reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (dragbltext.size() > 0 || imgselected) {
                    new AlertDialog.Builder(context)
                            .setMessage(getResources().getString(R.string.wrng_full_reset_effct))
                            .setPositiveButton(getResources().getString(R.string.ok), new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    if (dragbltext.size() > 0) {
                                        if (rootview.getChildCount() > 0) {
                                            rootview.removeAllViews();
                                            dragbltext.clear();
                                            sb_fontsize.setProgress(40);
                                            tv_font_size.setText(getResources().getString(R.string.font_size_dot));
                                            sb_fontshadow.setProgress(2);
                                            tv_font_shadow.setText(getResources().getString(R.string.font_size_dot));
                                        }
                                    }
                                    if (shadow) {
                                        sb_imgshadow.setProgress(255);
                                        tv_img_shadow.setText(getResources().getString(R.string.img_shadow_dot));
                                    }
                                    tv_brightnes.setText(getResources().getString(R.string.brightnes_dot));
                                    tv_contrast.setText(getResources().getString(R.string.contrast_dot));
                                    sb_brightnes.setProgress(0);
                                    sb_contrast.setProgress(1);
                                    iv_main_img.setImageBitmap(bitmap);
                                }
                            }).setNegativeButton(getResources().getString(R.string.cancel), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.dismiss();
                        }
                    }).show();
                } else {
                    Toast.makeText(context, getResources().getString(R.string.not_any_eftct_ad_yet), Toast.LENGTH_SHORT).show();
                }
            }
        });
        
        iv_shadow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setShadowDialog();
            }
        });
        iv_fonts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (dragbltext.size() > 0) {
                    if (rootview.getChildCount() > 0) {
                        newtextview = findViewById(dragbltext.get(crnt_pos).getId());
                        opn_popup_font(newtextview);
                    } else {
                        Toast.makeText(context, getResources().getString(R.string.add_text_dot), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(context, getResources().getString(R.string.add_text_dot), Toast.LENGTH_SHORT).show();
                }
            }
        });
        iv_bold.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (dragbltext.size() > 0) {
                    if (rootview.getChildCount() > 0) {
                        newtextview = findViewById(dragbltext.get(crnt_pos).getId());
                        Typeface tf = newtextview.getTypeface();
//                        ctf = newtextview.getTypeface();
                        if (ctf == null) {
                            ctf = tf;
                        }
                        if (ctf != null) {

                            if (newtextview.getTypeface().getStyle() == Typeface.BOLD) {
                                //do your stuff
                                newtextview.setTypeface(ctf, Typeface.NORMAL);
                                /*if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                    newtextview.setTextAppearance(R.style.normalText);
                                } else {
                                    newtextview.setTextAppearance(context, R.style.normalText);
//                                    newtextview.setTypeface(tf, Typeface.NORMAL);
                                }*/

                            } else {
                                newtextview.setTypeface(ctf, Typeface.BOLD);
                                /*if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                    newtextview.setTextAppearance(R.style.boldText);
                                } else {
                                    newtextview.setTextAppearance(context, R.style.boldText);
//                                    newtextview.setTypeface(tf, Typeface.BOLD);
                                }*/
                            }
                        }
                    } else {
                        Toast.makeText(context, getResources().getString(R.string.add_text_dot), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(context, getResources().getString(R.string.add_text_dot), Toast.LENGTH_SHORT).show();
                }
            }
        });
        iv_color.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (dragbltext.size() > 0) {
                    if (rootview.getChildCount() > 0) {
                        newtextview = findViewById(dragbltext.get(crnt_pos).getId());
                        setColorDialog(newtextview);
                    } else {
                        Toast.makeText(context, getResources().getString(R.string.add_text_dot), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(context, getResources().getString(R.string.add_text_dot), Toast.LENGTH_SHORT).show();
                }
            }
        });
        iv_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (dragbltext.size() > 0) {
                    if (rootview.getChildCount() > 0) {
                        new AlertDialog.Builder(context)
                                .setMessage(getResources().getString(R.string.are_you_sure_to_delete))
                                .setPositiveButton(getResources().getString(R.string.ok), new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                        deletetext();
                                    }
                                }).setNegativeButton(getResources().getString(R.string.cancel), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        }).show();

                    } else {
                        Toast.makeText(context, getResources().getString(R.string.add_text_dot), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(context, getResources().getString(R.string.add_text_dot), Toast.LENGTH_SHORT).show();
                }
            }
        });

        iv_lft_align.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (dragbltext.size() > 0) {
                    if (rootview.getChildCount() > 0) {
                        newtextview = findViewById(dragbltext.get(crnt_pos).getId());
//                    newtextview.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_START);
                        newtextview.setGravity(Gravity.START);
                    } else {
                        Toast.makeText(context, getResources().getString(R.string.add_text_dot), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(context, getResources().getString(R.string.add_text_dot), Toast.LENGTH_SHORT).show();
                }
            }
        });
        iv_cntr_align.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (dragbltext.size() > 0) {
                    if (rootview.getChildCount() > 0) {
                        newtextview = findViewById(dragbltext.get(crnt_pos).getId());
//                    newtextview.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                        newtextview.setGravity(Gravity.CENTER);
                    } else {
                        Toast.makeText(context, getResources().getString(R.string.add_text_dot), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(context, getResources().getString(R.string.add_text_dot), Toast.LENGTH_SHORT).show();
                }
            }
        });
        iv_right_align.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (dragbltext.size() > 0) {
                    if (rootview.getChildCount() > 0) {
                        newtextview = findViewById(dragbltext.get(crnt_pos).getId());
//                    newtextview.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_END);
                        newtextview.setGravity(Gravity.END);
                    } else {
                        Toast.makeText(context, getResources().getString(R.string.add_text_dot), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(context, getResources().getString(R.string.add_text_dot), Toast.LENGTH_SHORT).show();
                }
            }
        });
        ivShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isPermission()) {
                    String filename = String.valueOf(Calendar.getInstance().getTimeInMillis());
                    download_ShareImg(filename);
                } else {
                    checkPermission();
                }
            }
        });

        ivSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isPermission()) {
                    String filename = String.valueOf(Calendar.getInstance().getTimeInMillis());
                    try {
                        download_Img(filename);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } else {
                    checkPermission();
                }
            }
        });

    }

    private void setColorDialog(TextView tv) {
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        int width = size.x;
        int height = size.y;
        if (!popup.isShowing()) {

            final LayoutInflater inflaterpopup = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
            final View view1 = inflaterpopup.inflate(R.layout.popup_choose_option, null);
            popup = new PopupWindow(view1, params.MATCH_PARENT, params.MATCH_PARENT);

            popup.setFocusable(true);
            ImageView iv_close = view1.findViewById(R.id.iv_close);
            TextView tv_edit = view1.findViewById(R.id.tv_edit);
            TextView tv_add = view1.findViewById(R.id.tv_add);

            tv_edit.setText(getResources().getString(R.string.shadow_color));
            tv_add.setText(getResources().getString(R.string.txt_color));

            tv_edit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    popup.dismiss();
                    opnColorDialog(tv, 0);
//                    ((Activity)context).onBackPressed();
                }
            });

            tv_add.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    popup.dismiss();
                    opnColorDialog(tv, 1);
//                    ((Activity)context).onBackPressed();
                }
            });

            iv_close.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    popup.dismiss();
                }
            });
            popup.setOutsideTouchable(false);
//                          popup.showAtLocation(view1, Gravity.TOP, width, height);
            popup.showAtLocation(view1, Gravity.CENTER, 0, 0);
        } else {
            popup.dismiss();
        }
    }

    private void setShadowDialog() {
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        int width = size.x;
        int height = size.y;
        if (!popup.isShowing()) {
            final LayoutInflater inflaterpopup = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
            final View view1 = inflaterpopup.inflate(R.layout.popup_choose_shadow_option, null);
            popup = new PopupWindow(view1, params.MATCH_PARENT, params.MATCH_PARENT);
            popup.setFocusable(true);
            ImageView iv_close = view1.findViewById(R.id.iv_close);
            TextView tv_hide = view1.findViewById(R.id.tv_hide);
            TextView tv_color = view1.findViewById(R.id.tv_color);
            if (shadow) {
                tv_hide.setText(getResources().getString(R.string.hide_shadow));
            }else {
//                tv_hide.setText(getResources().getString(R.string.hide_shadow));
                tv_hide.setText(getResources().getString(R.string.show_shadow));
            }
            tv_hide.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    popup.dismiss();
                    if (iv_shadow_img.getVisibility() == View.VISIBLE) {
                        iv_shadow_img.setVisibility(View.GONE);
                        shadow = false;
                    } else {
                        iv_shadow_img.setVisibility(View.VISIBLE);
                        shadow = true;
                    }
//                    ((Activity)context).onBackPressed();
                }
            });
            tv_color.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    popup.dismiss();
                    if (shadow) {
                        shadowColorDialog();
                    }
//                    ((Activity)context).onBackPressed();
                }
            });
            iv_close.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    popup.dismiss();
                }
            });
            popup.setOutsideTouchable(false);
//                          popup.showAtLocation(view1, Gravity.TOP, width, height);
            popup.showAtLocation(view1, Gravity.CENTER, 0, 0);
        } else {
            popup.dismiss();
        }
    }

    private void addTextDialog() {
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        int width = size.x;
        int height = size.y;
        if (!popup.isShowing()) {
            final LayoutInflater inflaterpopup = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
            final View view1 = inflaterpopup.inflate(R.layout.popup_choose_option, null);
            popup = new PopupWindow(view1, params.MATCH_PARENT, params.MATCH_PARENT);

            popup.setFocusable(true);
            TextView tv_edit = view1.findViewById(R.id.tv_edit);
            TextView tv_add = view1.findViewById(R.id.tv_add);

            ImageView iv_close = view1.findViewById(R.id.iv_close);
            iv_close.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    popup.dismiss();
                }
            });

            tv_edit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    popup.dismiss();
                    if (dragbltext.size() > 0) {
                        Popup_addtext(0);
                    }
//                    ((Activity)context).onBackPressed();
                }
            });
            tv_add.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    popup.dismiss();
                    Popup_addtext(1);
//                    ((Activity)context).onBackPressed();
                }
            });

            popup.setOutsideTouchable(false);
//                          popup.showAtLocation(view1, Gravity.TOP, width, height);
            popup.showAtLocation(view1, Gravity.CENTER, 0, 0);
        } else {
            popup.dismiss();
        }
    }

    public void Popup_addtext(int itm) {
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        int width = size.x;
        int height = size.y;
        if (!popup.isShowing()) {
            final LayoutInflater inflaterpopup = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
            final View view1 = inflaterpopup.inflate(R.layout.popup_addtext, null);
            popup = new PopupWindow(view1, params.MATCH_PARENT, params.MATCH_PARENT);

            popup.setFocusable(true);

            EditText tv_text = view1.findViewById(R.id.tv_text);
            TextView tv_ok = view1.findViewById(R.id.tv_ok);
            ImageView iv_close = view1.findViewById(R.id.iv_close);

            if (itm == 0) {
                tv_text.setText(dragbltext.get(crnt_pos).getTextview().getText().toString());
            }
            tv_ok.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    newtext = tv_text.getText().toString();
                    if (itm == 0) {
                        dragbltext.get(crnt_pos).getTextview().setText(newtext);
                    } else {
                        addtextfun(newtext);
                    }
                    popup.dismiss();
//                    ((Activity)context).onBackPressed();
                }
            });
            iv_close.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    popup.dismiss();
                }
            });
            popup.setOutsideTouchable(false);
//                          popup.showAtLocation(view1, Gravity.TOP, width, height);
            popup.showAtLocation(view1, Gravity.CENTER, 0, 0);
        } else {
            popup.dismiss();
        }
    }

    private void addtextfun(String newtext) {
//        DraggableView draggableView;
        textviewid = textviewid + 1;
        TextView textView = new TextView(context);
        textView.setId(textviewid);
        newdragableview = new DraggableView.Builder(textView)
                .setStickyMode(DraggableView.Mode.NON_STICKY)
                .build();
//        newdragableview= new DraggableView.Builder(textView).build().setSticky(DraggableView.Mode.NON_STICKY).build();
//        new DraggableView.Builder(textView).build().setSticky(DraggableView.Mode.NON_STICKY);

        RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT);
        textView.setLayoutParams(lp);
        textView.setX(10);
        textView.setY(10);
        textView.setText(newtext);
        textView.setTextSize(TypedValue.COMPLEX_UNIT_PX, (float) 40);
//        textView.setTextSize(20f);
        rootview.addView(textView);
        dragbltext.add(new TextviewModel(newdragableview, textView, newtext, textviewid));
//        crnt_pos=crnt_pos+1;
        generateDraglistener();
    }

    private void opn_popup_font(TextView tv) {

        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        int width = size.x;
        int height = size.y;
        if (!popup.isShowing()) {
            final LayoutInflater inflaterpopup = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
            final View view1 = inflaterpopup.inflate(R.layout.popup_list, null);
            popup = new PopupWindow(view1, params.MATCH_PARENT, params.MATCH_PARENT);
            popup.setFocusable(true);

            ListView lv_list = view1.findViewById(R.id.lv_list);
            TextView tv_ok = view1.findViewById(R.id.tv_ok);
            ImageView iv_close = view1.findViewById(R.id.iv_close);

            iv_close.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    popup.dismiss();
                }
            });

//            ArrayList<String> fontlist = GetSystemFonts.fontList();
            ArrayList<model_font> fontlist = new ArrayList<>();

            for (int i = 0; i < Constance.fontList.length; i++) {
                fontlist.add(new model_font(Constance.fontList[i], Constance.fontName[i]));
            }
            AdapterList adapterChat = new AdapterList(context, R.layout.row_list_itm, fontlist);
            lv_list.setAdapter(adapterChat);

            lv_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                    String s = fontlist.get(i).getFont();
//                    String s = adapterView.getItemAtPosition(i).toString();
//                    String s = lv_list.getItemAtPosition(i).toString();
//                    Typeface tf=Typeface.createFromFile("fonts/" + s );
                    Typeface tf = Typeface.createFromAsset(context.getAssets(), "fonts/" + s);
                    newtextview.setTypeface(tf);
//                    Toast.makeText(context, s, Toast.LENGTH_SHORT).show();

//                    tv.setTypeface(Typeface.createFromFile("/system/fonts/" + s + ".ttf"));
//                    newtextview.setTypeface(Typeface.createFromAsset(getAssets(), "fonts/"  + s ));
//                    newtextview.setTypeface(Typeface.createFromFile("fonts/" + s ));
//                    newtextview.setTypeface(Typeface.createFromFile("/system/fonts/" + s + ".ttf"));
                }
            });
            lv_list.setSelector(R.color.grayA0);

            tv_ok.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ctf = newtextview.getTypeface();
                    popup.dismiss();
                }
            });

            popup.setOutsideTouchable(true);
//                          popup.showAtLocation(view1, Gravity.TOP, width, height);
            popup.showAtLocation(view1, Gravity.BOTTOM, 0, 0);
        } else {
            popup.dismiss();
        }
    }

    private void opnColorDialog(TextView tv, int option) {
        ColorPickerDialogBuilder
                .with(context)
                .setTitle(getResources().getString(R.string.select_color))
                .initialColor(getResources().getColor(R.color.blue_light))
                .wheelType(ColorPickerView.WHEEL_TYPE.FLOWER)
                .density(15)
                .setColorEditTextColor(getResources().getColor(R.color.colorPrimaryDark))
                .setOnColorSelectedListener(new OnColorSelectedListener() {
                    @Override
                    public void onColorSelected(int selectedColor) {
//                        toast("onColorSelected: 0x" + Integer.toHexString(selectedColor));
                    }
                })
                .setPositiveButton(getResources().getString(R.string.ok), new ColorPickerClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int selectedColor, Integer[] allColors) {
//                        changeBackgroundColor(selectedColor);
                        if (option == 0) {
                            tv.setShadowLayer(tv.getShadowRadius(), 0, 0, selectedColor);
                        }
                        if (option == 1) {
                            tv.setTextColor(selectedColor);
                        }
                        dialog.dismiss();
                    }
                })
                .setNegativeButton(getResources().getString(R.string.cancel), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                })
                .build()
                .show();
    }

    private void shadowColorDialog() {
        ColorPickerDialogBuilder
                .with(context)
                .setTitle(getResources().getString(R.string.select_color))
                .initialColor(getResources().getColor(R.color.white))
                .wheelType(ColorPickerView.WHEEL_TYPE.FLOWER)
                .density(12)
                .setColorEditTextColor(getResources().getColor(R.color.black))
                .setOnColorSelectedListener(new OnColorSelectedListener() {
                    @Override
                    public void onColorSelected(int selectedColor) {
//                        toast("onColorSelected: 0x" + Integer.toHexString(selectedColor));
                    }
                })
                .setPositiveButton(getResources().getString(R.string.ok), new ColorPickerClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int selectedColor, Integer[] allColors) {
//                        changeBackgroundColor(selectedColor);
                        GradientDrawable gd = new GradientDrawable(
                                GradientDrawable.Orientation.TOP_BOTTOM,
                                new int[]{0x00FFFFFF, selectedColor});
                        gd.setCornerRadius(0f);
                        iv_shadow_img.setImageDrawable(gd);
                        dialog.dismiss();
                    }
                })
                .setNegativeButton(getResources().getString(R.string.cancel), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                })
                .build()
                .show();
    }

    private void generateDraglistener() {
        for (int i = 0; i < dragbltext.size(); i++) {
            dragbltext.get(i).getDragview().setListener(new DraggableListener() {
                @Override
                public void onPositionChanged(View view) {
                    mview = view;
                    int id = view.getId();
                    for (int i = 0; i < dragbltext.size(); i++) {
                        if (id == dragbltext.get(i).getId()) {
                            crnt_pos = i;
                            newtextview = view.findViewById(dragbltext.get(crnt_pos).getId());
                            /*newtextview.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {

                                    Log.e("crnt_pos :", "text :" + crnt_pos + "");
                                    Log.e("crnt_pos :", "text :" + newtextview.getText().toString() + "");
                                }
                            });*/
                            generateClicklistener(newtextview);
                            break;
                        }
                    }
//                    curntdragView = dragbltext.get(crnt_pos).getTextview();
//                    textView = view.findViewById(id);
//                    Toast.makeText(context, textView.getText().toString(), Toast.LENGTH_SHORT).show();
//                    Log.e("crnt_pos :", "crnt_pos :" + crnt_pos + "");
//                    Log.e("crnt_pos :", "crnt_pos :" + textView.getText().toString() + "");
                }
            });
        }
    }

    private void generateClicklistener(TextView tv) {
        tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int id = view.getId();
                for (int i = 0; i < dragbltext.size(); i++) {
                    if (id == dragbltext.get(i).getId()) {
                        crnt_pos = i;
                        tv_pos.setText(crnt_pos + "");
                    }
                }
                getViewSetting(tv);
                Log.e("crnt_pos :", "text :" + crnt_pos + "");
                Log.e("crnt_pos :", "text :" + tv.getText().toString() + "");
            }
        });
       /* for (int i = 0; i < dragbltext.size(); i++) {
            dragbltext.get(i).getTextview().setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int id = view.getId();
                    for (int i = 0; i < dragbltext.size(); i++) {
                        if (id == dragbltext.get(i).getId()) {
                            crnt_pos = i;
                        }
                    }

//                    curntdragView = dragbltext.get(crnt_pos).getTextview();
                    textView = view.findViewById(id);
                    Log.e("crnt_pos :", "text :" + crnt_pos + "");
                    Log.e("crnt_pos :", "text :" + textView.getText().toString() + "");
                }
            });
        }*/
    }

    private void getViewSetting(TextView tv) {
        if (dragbltext.size() > 0) {
            if (rootview.getChildCount() > 0) {
                ctf = tv.getTypeface();
                sb_fontsize.setProgress((int) tv.getTextSize());
                tv_font_size.setText(getResources().getString(R.string.font_size_dot) + tv.getTextSize());

                sb_fontshadow.setProgress((int) tv.getShadowRadius());
                tv_font_shadow.setText(getResources().getString(R.string.font_shadow_dot) + tv.getShadowRadius());
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    sb_spacing.setProgress(((int) tv.getLetterSpacing() * 100));
                    tv_font_spacing.setText(getResources().getString(R.string.spacing_dot) + ((int) tv.getLetterSpacing() * 100));
                }
            }
        }
        if (imgselected) {
            if (shadow) {
                sb_imgshadow.setProgress((int) (iv_shadow_img.getAlpha() + 255));
                tv_img_shadow.setText(getResources().getString(R.string.img_shadow_dot) + (iv_shadow_img.getAlpha() + 255));
            }
            tv_brightnes.setText(getResources().getString(R.string.brightnes_dot));
            tv_contrast.setText(getResources().getString(R.string.contrast_dot));
        }

    }

    private void deletetext() {
        if (dragbltext.size() > 0) {
            rootview.removeViewAt(crnt_pos);
            dragbltext.remove(crnt_pos);
            generateDraglistener();
        } else {
            sb_fontsize.setProgress(40);
            tv_font_size.setText(getResources().getString(R.string.font_size_dot));
            sb_fontshadow.setProgress(1);
            tv_font_shadow.setText(getResources().getString(R.string.font_shadow_dot));
            sb_imgshadow.setProgress(255);
            tv_img_shadow.setText(getResources().getString(R.string.img_shadow_dot));
//            Toast.makeText(context,  getResources().getString(R.string.add_text_dot), Toast.LENGTH_SHORT).show();
        }
    }

    private void pickFromGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK)
                .setType("image/*");
//                .addCategory(Intent.CATEGORY_OPENABLE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            String[] mimeTypes = {"image/jpeg"};
            intent.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes);
        }
        startActivityForResult(intent, 1);
//        startActivityForResult(Intent.createChooser(intent, getString(R.string.select_photo)), 1);
    }

    private void startCrop(@NonNull Uri uri) {
        String destinationFileName = SAMPLE_CROPPED_IMAGE_NAME;
//        String filename = UUID.randomUUID().toString();
//        String fileName = Integer.toString(new Random().nextInt(1000000000)) + ".jpeg";
        String filename = String.valueOf(Calendar.getInstance().getTimeInMillis());
        File storageDir;
       /* if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            // only for gingerbread and newer versions
            storageDir = new File(context.getExternalFilesDir(null), "/pngStatus/");
        } else {
//            storageDir = new File(Environment.getExternalStorageDirectory() + "/pngStatus/");
            storageDir =new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).toString()+ "/pngStatus/");
        }*/
        storageDir =new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)+ "/pngStatus/");

        UCrop.Options options = new UCrop.Options();
        UCrop uCrop = UCrop.of(uri, Uri.fromFile(new File(getCacheDir(), filename + ".png")));
        options.setHideBottomControls(true);
//        options.setFreeStyleCropEnabled(true);

        uCrop.withAspectRatio(9, 16);
        uCrop.withMaxResultSize(720, 1080);
//        uCrop.withAspectRatio(9, 12);
//        uCrop.withMaxResultSize(800, 1000);
        uCrop.withOptions(options);
        uCrop.start(this);
    }

    public Bitmap viewToBitmap(View view) {
        Bitmap bitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        view.draw(canvas);
        return bitmap;
    }

    private Bitmap fileToBitmap(File uri) {
        if (uri == null) return null;

        Bitmap bitmap = null;
        bitmap = BitmapFactory.decodeFile(uri.getAbsolutePath());
        /*try {
            ContentResolver cr = this.getContentResolver();
//            bitmap = BitmapFactory.decodeStream(cr.openInputStream(uri));

        } catch (FileNotFoundException e) {
            e.printStackTrace();
//            LogUtils.e("Exception", e.getMessage(),e);
        }*/
        return bitmap;
    }

    private Bitmap uriToBitmap(Uri uri) {
        if (uri == null) return null;

        Bitmap bitmap = null;

        try {
            ContentResolver cr = this.getContentResolver();
            bitmap = BitmapFactory.decodeStream(cr.openInputStream(uri));

        } catch (FileNotFoundException e) {
            e.printStackTrace();
//            LogUtils.e("Exception", e.getMessage(),e);
        }
        return bitmap;
    }

    public void shareItem1(Uri uri) {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("image/*");
        File file = new File(uri.getPath());
        Uri photoUri = FileProvider.getUriForFile(
                context,
                getResources().getString(R.string.file_provider_authority),
                file);
//        share.putExtra(Intent.EXTRA_SUBJECT, "Title Of The Post");
        i.putExtra(Intent.EXTRA_TEXT, getResources().getString(R.string.sim_link)+getApplication().getPackageName() );
        i.putExtra(Intent.EXTRA_STREAM, photoUri);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(i, getResources().getString(R.string.share_img)));
    }

    public Uri getLocalBitmapUri(String name) {
//    public Uri getLocalBitmapUri(Bitmap bmp, String name) {
        Uri bmpUri = null;
        try {
            File file;
            file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).toString()+ "/pngStatus/");
            /*if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                // only for gingerbread and newer versions
                file = new File(context.getExternalFilesDir(null), "/pngStatus/");
            } else {
                file = new File(Environment.getExternalStorageDirectory() + "/pngStatus/");
            }*/
            File filePath = new File(file, name);
            FileOutputStream out = new FileOutputStream(filePath);
//            bmp.compress(Bitmap.CompressFormat.PNG, 90, out);
            out.close();
            bmpUri = Uri.fromFile(filePath);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return bmpUri;
    }

    private void download_Img1(String fname) {
        if (imgselected) {
            String filename = fname;
            Bitmap bm = viewToBitmap(rl_final_img);

            File storageDir;
            /*if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                // only for gingerbread and newer versions
                storageDir = new File(context.getExternalFilesDir(null), "/pngStatus/");
//                storageDir = new File(context.getExternalFilesDir(null), "/pngStatus/");
            } else {
                storageDir =new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).toString()+ "/pngStatus/");
//                storageDir = new File(Environment.getExternalStorageDirectory() + "/pngStatus/");
            }*/
            storageDir =new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)+ "/pngStatus/");
            if (storageDir.exists()) {
                Log.e("tag", "exitst file path" + storageDir.getAbsolutePath());
            } else {
                storageDir.mkdirs();
            }
            Constance.createdBitmap = scaleBitmap(bm, bm.getWidth(), bm.getHeight());

            File file = new File(storageDir, filename + ".png");
            if (file.exists())
                file.delete();
            try {
                FileOutputStream out = new FileOutputStream(file);
                Constance.createdBitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
//                Toast.makeText(context, filename + ".png" + getResources().getString(R.string.msg_dwnld_sucssfully), Toast.LENGTH_SHORT).show();
                out.flush();
                out.close();
                Popup_success popup_success=new Popup_success();
                popup_success.Popup_success(context,filename + ".png" + getResources().getString(R.string.msg_dwnld_sucssfully));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }else {
            Toast.makeText(context, getResources().getString(R.string.label_select_picture), Toast.LENGTH_SHORT).show();
        }
    }
    private void download_Img(String fname) throws IOException {
        OutputStream fos = null;
        File imageFile = null;
        Uri imageUri = null;

        if (imgselected) {
            String filename = fname;
            Bitmap bm = viewToBitmap(rl_final_img);
            File storageDir;
            /*if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                // only for gingerbread and newer versions
                storageDir = new File(context.getExternalFilesDir(null), "/pngStatus/");
//                storageDir = new File(context.getExternalFilesDir(null), "/pngStatus/");
            } else {
                storageDir =new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).toString()+ "/pngStatus/");
//                storageDir = new File(Environment.getExternalStorageDirectory() + "/pngStatus/");
            }*/
            storageDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + "/pngStatus/");
            if (storageDir.exists()) {
                Log.e("tag", "exitst file path" + storageDir.getAbsolutePath());
            } else {
                storageDir.mkdirs();
                Log.e("tag", "gnrt exitst file path" + storageDir.getAbsolutePath());
            }

//            bm= scaleBitmap(bm, bm.getWidth(), bm.getHeight());

            File file = new File(storageDir, filename + ".png");
            if (file.exists())
                file.delete();
            /*try {
                FileOutputStream out = new FileOutputStream(file);
                Constance.createdBitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
//                Toast.makeText(context, filename + ".png" + getResources().getString(R.string.msg_dwnld_sucssfully), Toast.LENGTH_SHORT).show();
                out.flush();
                out.close();
                Popup_success popup_success = new Popup_success();
                popup_success.Popup_success(context, filename + ".png" + getResources().getString(R.string.msg_dwnld_sucssfully));
            } catch (Exception e) {
                e.printStackTrace();
            }*/
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    ContentResolver resolver = context.getContentResolver();
                    ContentValues contentValues = new ContentValues();
                    contentValues.put(MediaStore.MediaColumns.DISPLAY_NAME, filename + ".png");
                    contentValues.put(MediaStore.MediaColumns.MIME_TYPE, "image/png");
                    contentValues.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/pngStatus/");
                    imageUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues);
                    if (imageUri == null)
                        throw new IOException("Failed to create new MediaStore record.");
//                fos = resolver.openOutputStream(imageUri);
                    try {
                        fos = resolver.openOutputStream(imageUri);
                        bm.compress(Bitmap.CompressFormat.PNG, 100, fos);
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                } else {

                    file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + "/pngStatus/", filename + ".png");
                    if (file.exists())
                        file.delete();
                    imageFile = new File(storageDir, filename + ".png");
                    try {
                        fos = new FileOutputStream(imageFile);
                        bm.compress(Bitmap.CompressFormat.PNG, 100, fos);
//                    Constance.createdBitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                }

//                throw new IOException("Failed to save bitmap.");
                fos.flush();
            }finally {
                if (fos != null)
                    fos.close();
            }
            if (imageFile != null) {//pre Q
                MediaScannerConnection.scanFile(context, new String[]{imageFile.toString()}, null, null);
                imageUri = Uri.fromFile(imageFile);
            }
            Popup_success popup_success = new Popup_success();
            popup_success.Popup_success(context,  getResources().getString(R.string.msg_dwnld_sucssfully));
        } else {
            Toast.makeText(context, getResources().getString(R.string.label_select_picture), Toast.LENGTH_SHORT).show();
        }
    }
    private void download_ShareImg1(String name) {
        if (imgselected) {
            String filename = name;
            Bitmap bm = viewToBitmap(rl_final_img);

            File storageDir;
           /* if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                // only for gingerbread and newer versions
                storageDir = new File(context.getExternalFilesDir(null), "/pngStatus/");
            } else {
//                storageDir = new File(Environment.getExternalStorageDirectory() + "/pngStatus/");
                storageDir =new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).toString()+ "/pngStatus/");
            }*/
            storageDir =new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)+ "/pngStatus/");
            if (storageDir.exists()) {
                Log.e("tag", "exitst file path" + storageDir.getAbsolutePath());
            } else {
                storageDir.mkdirs();
            }
            Constance.createdBitmap = scaleBitmap(bm, bm.getWidth(), bm.getHeight());
//            Constance.createdBitmap = scaleBitmap(bm, 780, 1080);

            File file = new File(storageDir, filename + ".png");
            if (file.exists())
                file.delete();
            try {
                FileOutputStream out = new FileOutputStream(file);
                Constance.createdBitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
                StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
                StrictMode.setVmPolicy(builder.build());
                shareItem1(getLocalBitmapUri(filename + ".png"));
                out.flush();
                out.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            Toast.makeText(context, getResources().getString(R.string.selct_img), Toast.LENGTH_SHORT).show();
        }
    }
    private void download_ShareImg(String name) {
        OutputStream fos = null;
        File imageFile = null;
        Uri imageUri = null;
        if (imgselected) {
            String filename = name;
            Bitmap bm = viewToBitmap(rl_final_img);

            File storageDir;
           /* if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                // only for gingerbread and newer versions
                storageDir = new File(context.getExternalFilesDir(null), "/pngStatus/");
            } else {
//                storageDir = new File(Environment.getExternalStorageDirectory() + "/pngStatus/");
                storageDir =new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).toString()+ "/pngStatus/");
            }*/
            storageDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + "/pngStatus/");
            if (storageDir.exists()) {
                Log.e("tag", "exitst file path" + storageDir.getAbsolutePath());
            } else {
                storageDir.mkdirs();
            }
//            bm = scaleBitmap(bm, bm.getWidth(), bm.getHeight());
//            Constance.createdBitmap = scaleBitmap(bm, 780, 1080);

            File file = new File(storageDir, filename + ".png");
            if (file.exists())
                file.delete();
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    ContentResolver resolver = context.getContentResolver();
                    ContentValues contentValues = new ContentValues();
                    contentValues.put(MediaStore.MediaColumns.DISPLAY_NAME, filename + ".png");
                    contentValues.put(MediaStore.MediaColumns.MIME_TYPE, "image/png");
                    contentValues.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/pngStatus/");
                    imageUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues);
                    if (imageUri == null)
                        throw new IOException("Failed to create new MediaStore record.");
//                fos = resolver.openOutputStream(imageUri);
                    try {
                        fos = resolver.openOutputStream(imageUri);
                        bm.compress(Bitmap.CompressFormat.PNG, 100, fos);
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                } else {
                    file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + "/pngStatus/", filename + ".png");
                    if (file.exists())
                        file.delete();
                    imageFile = new File(storageDir, filename + ".png");
                    try {
                        fos = new FileOutputStream(imageFile);
                        bm.compress(Bitmap.CompressFormat.PNG, 100, fos);
//                    Constance.createdBitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                }

//                throw new IOException("Failed to save bitmap.");
               
//                shareItem(getLocalBitmapUri(filename + ".png"));
                fos.flush();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (fos != null) {
                    try {
                        fos.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            if (imageFile != null) {//pre Q
                MediaScannerConnection.scanFile(context, new String[]{imageFile.toString()}, null, null);
                imageUri = Uri.fromFile(imageFile);
            }
             shareItem(imageUri);
          /*  try {
                FileOutputStream out = new FileOutputStream(file);
                Constance.createdBitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
                StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
                StrictMode.setVmPolicy(builder.build());
                shareItem(getLocalBitmapUri(filename + ".png"));
                out.flush();
                out.close();

            } catch (Exception e) {
                e.printStackTrace();
            }*/

        } else {
            Toast.makeText(context, getResources().getString(R.string.selct_img), Toast.LENGTH_SHORT).show();
        }
    }

    public void shareItem(Uri uri) {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("image/*");
//        File file = new File(uri.getPath());
        File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)+"/pngStatus/"+ImageSelection.getFilePath(context,uri));
       /* Uri photoUri = FileProvider.getUriForFile(
                context,
                getResources().getString(R.string.file_provider_authority),
                file);*/
//        share.putExtra(Intent.EXTRA_SUBJECT, "Title Of The Post");
        i.putExtra(Intent.EXTRA_TEXT, getResources().getString(R.string.sim_link)+ getApplication().getPackageName());
        i.putExtra(Intent.EXTRA_STREAM, uri);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(i, getResources().getString(R.string.share_img)));
    }
    private File createImageFile() throws IOException {
        String imageFileName = "Temp_";
        File storageDir;
      /*  if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            // only for gingerbread and newer versions
            storageDir = new File(context.getExternalFilesDir(null), "/pngStatus/");
        } else {
//            storageDir = new File(Environment.getExternalStorageDirectory() + "/pngStatus/");
            storageDir =new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).toString()+ "/pngStatus/");
        }*/
        storageDir =new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)+ "/pngStatus/");
        if (storageDir.exists()) {
            Log.e("tag", "exitst file path" + storageDir.getAbsolutePath());
        } else {
            storageDir.mkdirs();
//            Toast.makeText(context, file.getAbsolutePath(), Toast.LENGTH_SHORT).show();
            Log.e("tag", "new file path  " + storageDir.getAbsolutePath());
            sourceUri = Uri.parse(storageDir.getAbsolutePath());
            destinationUri = Uri.parse(storageDir.getAbsolutePath());
        }
        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".png",         /* suffix */
                storageDir      /* directory */
        );
        realPath = image.getAbsolutePath();
        return image;
    }

    private Bitmap scaleBitmap(Bitmap bitmap, int wantedWidth, int wantedHeight) {
        float originalWidth = bitmap.getWidth();
        float originalHeight = bitmap.getHeight();
        Bitmap output = Bitmap.createBitmap(wantedWidth, wantedHeight, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(output);
        Matrix m = new Matrix();
        float scalex = wantedWidth / originalWidth;
        float scaley = wantedHeight / originalHeight;
        float xTranslation = 0.0f;
        float yTranslation = (wantedHeight - originalHeight * scaley) / 2.0f;
        m.postTranslate(xTranslation, yTranslation);
        m.preScale(scalex, scaley);
        // m.setScale((float) wantedWidth / bitmap.getWidth(), (float) wantedHeight / bitmap.getHeight());
        Paint paint = new Paint();
        paint.setFilterBitmap(true);
        canvas.drawBitmap(bitmap, m, paint);
        return output;

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == 1) {
                if (data != null && data.getData() != null) {
                    final Uri selectedUri = data.getData();
                    if (selectedUri != null) {
                        startCrop(selectedUri);
                    } else {
                        Toast.makeText(this, getResources().getString(R.string.toast_cannot_retrieve_selected_image), Toast.LENGTH_SHORT).show();
                    }
                }
            } else if (requestCode == UCrop.REQUEST_CROP) {
//                handleCropResult(data);
                final Uri resultUri = UCrop.getOutput(data);
                Bitmap bm1 = null;
                if (data != null && resultUri != null) {
                   /* try {
                        bm1 = MediaStore.Images.Media.uriToBitmap(context.getApplicationContext().getContentResolver(), data.getData());
                    } catch (IOException e) {
                        e.printStackTrace();
                    }*/
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
//                        realPath = ImageSelection.getPath(context, data.getData());
                        realPath = ImageSelection.getPath(context, resultUri);
//                            imgpath1 = realPath;
                    } else {
                        realPath = ImageSelection.getPath1(context, resultUri);
//                            imgpath1 = realPath;
                    }
                   /* File file=new File(data.getData().toString());
                    String path=file.getAbsolutePath();*/
                    File compressedImageFile = null;
                    String uriString = realPath;
                    File file = new File(uriString);
                    try {
                        compressedImageFile = new Compressor(context).compressToFile(file);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    imgpath1 = compressedImageFile.getAbsolutePath();
//                    iv_main_img.setImageBitmap(bm1);
                    imgselected = true;
                    bitmap = uriToBitmap(resultUri);
//                    Glide.with(context).load(imgpath1).into(iv_main_img);
                    int height = bitmap.getHeight();
                    int width = bitmap.getWidth();
                  /*  iv_shadow_img.requestLayout();
                    iv_main_img.requestLayout();
                    rootview.requestLayout();
                    iv_shadow_img.getLayoutParams().height = height;
                    iv_shadow_img.getLayoutParams().width = width;
                    iv_main_img.getLayoutParams().height = height;
                    iv_main_img.getLayoutParams().width = width;
                    rootview.getLayoutParams().height = height;
                    rootview.getLayoutParams().width = width;
                    iv_shadow_img.setScaleType(ImageView.ScaleType.FIT_XY);
                    iv_main_img.setScaleType(ImageView.ScaleType.FIT_XY);*/
                    iv_main_img.setImageBitmap(bitmap);
//                    iv_shadow_img.setImageDrawable(getResources().getDrawable(R.drawable.bg_gradiant));
                   /* try {
                        Bitmap bitmap=Picasso.get().load(imgpath1).get();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    Picasso.get()
                            .load(imgpath1)
                            .into(new Target() {
                                @Override
                                public void onBitmapLoaded(final Bitmap bitmap, Picasso.LoadedFrom from) {
                                    *//* Save the bitmap or do something with it here *//*
                                    int height = bitmap.getHeight();
                                    int width = bitmap.getWidth();
                                    iv_shadow_img.requestLayout();
                                    iv_shadow_img.getLayoutParams().height = bitmap.getHeight();
                                    iv_shadow_img.getLayoutParams().width = bitmap.getWidth();
                                    iv_shadow_img.setScaleType(ImageView.ScaleType.FIT_XY);
                                    //Set it in the ImageView
                                    iv_main_img.setImageBitmap(bitmap);
                                }

                                @Override
                                public void onBitmapFailed(Exception e, Drawable errorDrawable) {
                                    Log.e("Exception",e.getMessage());
                                    iv_main_img.setImageDrawable(errorDrawable);
                                }

                                @Override
                                public void onPrepareLoad(Drawable placeHolderDrawable) {
                                    iv_main_img.setImageDrawable(placeHolderDrawable);
                                }
                            });*/
                }
            }
        }

        if (resultCode == UCrop.RESULT_ERROR) {
            handleCropError(data);
        }
    }

    /**
     * //     * @param bmp        input bitmap
     * //     * @param contrast   0..10 1 is default
     * //     * @param brightness -255..255 0 is default
     * //     * @return new bitmap
     */

    public Bitmap changeContrastBrightness(float contrast, float brightness) {

        if (bitmapContrastMaster == null) {
            bitmapContrastMaster = (Bitmap) ((BitmapDrawable) iv_main_img.getDrawable()).getBitmap();
            bmp = bitmapContrastMaster;
        }

        ColorMatrix cm = new ColorMatrix(new float[]
                {
                        contrast, 0, 0, 0, brightness,
                        0, contrast, 0, 0, brightness,
                        0, 0, contrast, 0, brightness,
                        0, 0, 0, 1, 0
                });

        Bitmap ret = Bitmap.createBitmap(bmp.getWidth(), bmp.getHeight(), bmp.getConfig());

        Canvas canvas = new Canvas(ret);

        Paint paint = new Paint();
        Ccontrast = contrast;
        Cbrightness = brightness;

        paint.setColorFilter(new ColorMatrixColorFilter(cm));
        canvas.drawBitmap(bmp, 0, 0, paint);

        return ret;
    }

    private void handleCropError(@NonNull Intent result) {
        final Throwable cropError = UCrop.getError(result);
        if (cropError != null) {
            Log.e("ucrop", "handleCropError: ", cropError);
            Toast.makeText(context, cropError.getMessage(), Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(context, R.string.toast_unexpected_error, Toast.LENGTH_SHORT).show();
        }
    }

    private void dispatchTakePictureIntent() {
        int camera = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA);
        int grant = PackageManager.PERMISSION_GRANTED;

        Log.i("tag", "camera : " + camera);
        Log.i("tag", "grant : " + grant);

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        // Ensure that there's a camera activity to handle the intent

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.ECLAIR) {
            if (getApplicationContext().getPackageManager().hasSystemFeature(
                    PackageManager.FEATURE_CAMERA)) {
                //           if (takePictureIntent.resolveActivity(CompanyUploadMultiFileActivity.this.getPackageManager()) != null) {
                // Create the File where the photo should go
                File photoFile = null;
                try {
                    photoFile = createImageFile();
                } catch (IOException ex) {
                    // Error occurred while creating the File
                }
                // Continue only if the File was successfully created
                if (photoFile != null) {
                    Uri photoURI = FileProvider.getUriForFile(context,
                            getResources().getString(R.string.file_provider_authority),
                            photoFile);
                    takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                    takePictureIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivityForResult(takePictureIntent, 2);
                }
                //           }
            } else {
                Toast.makeText(context, getResources().getString(R.string.msg_no_camra), Toast.LENGTH_SHORT).show();
                // no camera on this device
            }
        }
    }

    private boolean isPermission() {
        if (ActivityCompat.checkSelfPermission(context, permissionsRequired[0]) != PackageManager.PERMISSION_GRANTED
                || ActivityCompat.checkSelfPermission(context, permissionsRequired[1]) != PackageManager.PERMISSION_GRANTED
                || ActivityCompat.checkSelfPermission(context, permissionsRequired[2]) != PackageManager.PERMISSION_GRANTED) {
//            checkPermission();
            return false;
        } else {
            return true;
        }
    }

    public void checkPermission() {
        if (ActivityCompat.checkSelfPermission(context, permissionsRequired[0]) != PackageManager.PERMISSION_GRANTED
                || ActivityCompat.checkSelfPermission(context, permissionsRequired[1]) != PackageManager.PERMISSION_GRANTED
                || ActivityCompat.checkSelfPermission(context, permissionsRequired[2]) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale((Activity) context, permissionsRequired[0])
                    || ActivityCompat.shouldShowRequestPermissionRationale((Activity) context, permissionsRequired[1])
                    || ActivityCompat.shouldShowRequestPermissionRationale((Activity) context, permissionsRequired[2])) {
                //Show Information about why you need the permission
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setTitle(getResources().getString(R.string.need_multiple_prmisn));
                builder.setMessage(getResources().getString(R.string.app_need_multiple_prmisn));
                builder.setPositiveButton(getResources().getString(R.string.grant), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                        ActivityCompat.requestPermissions((Activity) context, permissionsRequired, PERMISSION_CALLBACK_CONSTANT);
                    }
                });
                builder.setNegativeButton(getResources().getString(R.string.cancel), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
//                        onBackPressed();
                    }
                });
                builder.show();
            } else {
                //just request the permission
                ActivityCompat.requestPermissions((Activity) context, permissionsRequired, PERMISSION_CALLBACK_CONSTANT);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case 200: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0 &&
                        grantResults[0] == PackageManager.PERMISSION_GRANTED &&
                        grantResults[1] == PackageManager.PERMISSION_GRANTED &&
                        grantResults[2] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.
                } else {
                    checkPermission();
//                    onBackPressed();
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }

  /*

    private void selectImage() {
        final CharSequence[] items = {getResources().getString(R.string.choose_from_glry),
                getResources().getString(R.string.capture_frm_camra),
                getResources().getString(R.string.cancel)};
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(context);
        builder.setTitle(getResources().getString(R.string.select_photo));
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
//                String[] mimeTypes = {"image/jpeg", "image/png"};
                if (items[item].equals(getResources().getString(R.string.choose_from_glry))) {
                               *//* Intent intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                                startActivityForResult(intent, TAKE_PHOTO_FROM_GALLARY);*//*
//                    Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
                    Intent photoPickerIntent = new Intent(Intent.ACTION_GET_CONTENT);
                    photoPickerIntent.setType("image/*");
                    photoPickerIntent.addCategory(Intent.CATEGORY_OPENABLE);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                        String[] mimeTypes = {"image/jpeg", "image/png"};
                        photoPickerIntent.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes);
                    }
                    startActivityForResult(Intent.createChooser(photoPickerIntent, getString(R.string.select_photo)), 1);
//                    startActivityForResult(photoPickerIntent, 1);
                } else if (items[item].equals(getResources().getString(R.string.capture_frm_camra))) {
                               *//* Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                                File f = new File(android.os.Environment.getExternalStorageDirectory(), "temp1.jpg");
                                intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(f));
                                startActivityForResult(intent, TAKE_PHOTO_FROM_CAMARA);*//*
                    dispatchTakePictureIntent();
                } else if (items[item].equals(getResources().getString(R.string.cancel))) {
                    dialog.dismiss();
                }
            }
        });

        builder.show();
    }

    */
  /*
       private Bitmap adjustedContrast() {
//    private Bitmap adjustedContrast(Bitmap src, double value) {
        Bitmap src = null;
        if (bitmapContrastMaster == null) {
            bitmapContrastMaster = (Bitmap) ((BitmapDrawable) iv_main_img.getDrawable()).uriToBitmap();
            src = bitmapContrastMaster;

            int progress = sb_contrast.getProgress();

            // image size
            int width = src.getWidth();
            int height = src.getHeight();
            // create output bitmap

            // create a mutable empty bitmap
            Bitmap bmOut = Bitmap.createBitmap(width, height, src.getConfig());

            // create a canvas so that we can draw the bmOut Bitmap from source bitmap
            Canvas c = new Canvas();
            c.setBitmap(bmOut);

            // draw bitmap to bmOut from src bitmap so we can modify it
            c.drawBitmap(src, 0, 0, new Paint(Color.BLACK));
            // color information
            int A, R, G, B;
            int pixel;
            // get contrast value
            double contrast = Math.pow((100 + progress) / 100, 2);

            // scan through all pixels
            for (int x = 0; x < width; ++x) {
                for (int y = 0; y < height; ++y) {
                    // get pixel color
                    pixel = src.getPixel(x, y);
                    A = Color.alpha(pixel);
                    // apply filter contrast for every channel R, G, B
                    R = Color.red(pixel);
                    R = (int) (((((R / 255.0) - 0.5) * contrast) + 0.5) * 255.0);
                    if (R < 0) {
                        R = 0;
                    } else if (R > 255) {
                        R = 255;
                    }

                    G = Color.green(pixel);
                    G = (int) (((((G / 255.0) - 0.5) * contrast) + 0.5) * 255.0);
                    if (G < 0) {
                        G = 0;
                    } else if (G > 255) {
                        G = 255;
                    }

                    B = Color.blue(pixel);
                    B = (int) (((((B / 255.0) - 0.5) * contrast) + 0.5) * 255.0);
                    if (B < 0) {
                        B = 0;
                    } else if (B > 255) {
                        B = 255;
                    }

                    // set new pixel color to output bitmap
                    bmOut.setPixel(x, y, Color.argb(A, R, G, B));
                }
            }
            return bmOut;
        }
        return src;
    }

      public static Bitmap changeBitmapContrastBrightness(Bitmap bmp, float contrast, float brightness) {
        ColorMatrix cm = new ColorMatrix(new float[]
                {
                        contrast, 0, 0, 0, brightness,
                        0, contrast, 0, 0, brightness,
                        0, 0, contrast, 0, brightness,
                        0, 0, 0, 1, 0
                });

        Bitmap ret = Bitmap.createBitmap(bmp.getWidth(), bmp.getHeight(), bmp.getConfig());

        Canvas canvas = new Canvas(ret);

        Paint paint = new Paint();

        paint.setColorFilter(new ColorMatrixColorFilter(cm));
        canvas.drawBitmap(bmp, 0, 0, paint);

        return ret;
    }


    public void updateImage() {

        // Reset Bitmap for saturation bar and contrast
//        bitmapSaturationMaster = null;
        bitmapContrastMaster = null;
        bitmapBrightnessMaster = null;

        int color = getResources().getColor(colors[colorIndex]);
        System.out.println("Mode : " + modes[filterIndex].name());
        iv_main_img.setColorFilter(
                new PorterDuffColorFilter(color, modes[filterIndex]));
    }

    private void loadBitmapContrast() {

        if (bitmapContrastMaster == null) {
            bitmapContrastMaster = (Bitmap) ((BitmapDrawable) iv_main_img.getDrawable()).uriToBitmap();
        }
        int progress = sb_contrast.getProgress();
        float contrast = (float) progress;
        System.out.println("Contrast: " + String.valueOf(contrast));
        iv_main_img.setImageBitmap(changeBitmapContrastBrightness(bitmapContrastMaster, contrast, 0));
    }

    private void loadBitmapBrightness() {

        if (bitmapBrightnessMaster == null) {
            bitmapBrightnessMaster = (Bitmap) ((BitmapDrawable) iv_main_img.getDrawable()).uriToBitmap();
        }
        int progress = sb_brightnes.getProgress();
        float brightness = (float) progress - 255;
        System.out.println("Brightness: " + String.valueOf(brightness));
        iv_main_img.setImageBitmap(changeBitmapContrastBrightness(bitmapBrightnessMaster, 1, brightness));
    }

    private void handleCropResult(@NonNull Intent result) {
        final Uri resultUri = UCrop.getOutput(result);
        if (resultUri != null) {
            ResultActivity.startWithUri(context, resultUri);
        } else {
            Toast.makeText(context, R.string.toast_cannot_retrieve_cropped_image, Toast.LENGTH_SHORT).show();
        }
    }
    */

    public void facebookAd(String adId) {
        if (adId.equals("")){
            adId="IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID";
        }
        ll_adView.removeAllViews();
        fadView = new com.facebook.ads.AdView(this, adId, com.facebook.ads.AdSize.BANNER_HEIGHT_50);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        fadView.setLayoutParams(lp);
        ll_adView.addView(fadView);
        fadView.loadAd();
    }

    public void googleBannerAd(String unitId) {
        ll_adView.removeAllViews();
        AdView adView = new AdView(context);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        adView.setLayoutParams(lp);
        adView.setAdSize(AdSize.BANNER);
        adView.setAdUnitId(unitId);
        ll_adView.addView(adView);
        AdRequest adRequest = new AdRequest.Builder().build();
//        List<String> testDeviceIds = Arrays.asList("33BE2250B43518CCDA7DE426D04EE231");
      /*  RequestConfiguration configuration =
                new RequestConfiguration.Builder().setTestDeviceIds(testDeviceIds).build();
        MobileAds.setRequestConfiguration(configuration);*/

        adView.loadAd(adRequest);
        adView.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                super.onAdClosed();
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                super.onAdFailedToLoad(loadAdError);
            }

            @Override
            public void onAdOpened() {
                super.onAdOpened();
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
            }

            @Override
            public void onAdClicked() {
                super.onAdClicked();
            }

            @Override
            public void onAdImpression() {
                super.onAdImpression();
            }
        });

    }

    public void googleInterstitialAd(String adId) {
//        String  adId = Constance.admob_fullscreen;
        if (adId.equals("")) {
            adId = "ca-app-pub-3940256099942544/1033173712";
        }
        AdRequest adRequest = new AdRequest.Builder().build();

        InterstitialAd.load(context, adId, adRequest, new InterstitialAdLoadCallback() {
            @Override
            public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                super.onAdLoaded(interstitialAd);
                // The mInterstitialAd reference will be null until
                // an ad is loaded.
                googleFullscreen = interstitialAd;
//                if (Constance.isFirstTimeOpen) {
                show_fullScreen_Ad();
//                }
                Log.i("TAG", "onAdLoaded");
                googleFullscreen.setFullScreenContentCallback(new FullScreenContentCallback() {
                    @Override
                    public void onAdDismissedFullScreenContent() {
                        // Called when fullscreen content is dismissed.
                        Log.d("TAG", "The ad was dismissed.");
                        Constance.AllowToOpenAdvertise = false;
                        googleFullscreen = null;
                        handlerStart();
                     /*   stopTask();
                        startTimer();*/
                        googleInterstitialAd(Constance.admob_fullscreen);
                    }

                    @Override
                    public void onAdFailedToShowFullScreenContent(AdError adError) {
                        // Called when fullscreen content failed to show.
                        Log.d("TAG", "The ad failed to show.");
                        googleFullscreen = null;
//                        Constance.AllowToOpenAdvertise = false;
//                        stopTask();
//                        startTimer();

//                        googleInterstitialAd();
                    }

                    @Override
                    public void onAdShowedFullScreenContent() {
                        // Called when fullscreen content is shown.
                        // Make sure to set your reference to null so you don't
                        // show it a second time.
//                        mInterstitialAd = null;
                        Log.d("TAG", "The ad was shown.");
//                        Constance.AllowToOpenAdvertise = false;
//                        stopTask();
//                        startTimer();
//                        handlerStart();
//                        googleInterstitialAd();
                    }
                });
               /* if (Constance.isFirstTimeOpen){
                    googleFullscreen.show(activity);
                    Constance.isFirstTimeOpen=false;
                }*/
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                super.onAdFailedToLoad(loadAdError);
                // Handle the error
                Log.i("TAG", loadAdError.getMessage());
//                Constance.AllowToOpenAdvertise = false;
//                googleFullscreen = null;
//                stopTask();
//                startTimer();
//                handlerStart();
//                googleInterstitialAd();
            }
        });
    }

    public void fbInterstitialAd() {
        String adId = Constance.facebook_fullscreen;
        fbFullscreen = new com.facebook.ads.InterstitialAd(this, adId);
        InterstitialAdListener fblistener = new InterstitialAdListener() {
            @Override
            public void onInterstitialDisplayed(Ad ad) {
//                stopTask();
//                startTimer();
            }

            @Override
            public void onInterstitialDismissed(Ad ad) {
//                stopTask();
//                startTimer();
                Constance.AllowToOpenAdvertise = false;
                handlerStart();
                fbInterstitialAd();
            }

            @Override
            public void onError(Ad ad, com.facebook.ads.AdError adError) {
//                stopTask();
//                startTimer();
            }

            @Override
            public void onAdLoaded(Ad ad) {
                fbFullscreen.show();
            }

            @Override
            public void onAdClicked(Ad ad) {
//                stopTask();
//                startTimer();
//                fbInterstitialAd();
            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        };
        fbFullscreen.loadAd(fbFullscreen.buildLoadAdConfig()
                .withAdListener(fblistener)
                .build());
    }

    public void active_ad() {

        String token = Prefs.getPrefString(context, Constance.api_token, "");
        RetrofitInterface retrofitInterface = RetrofitClient.getClient().create(RetrofitInterface.class);
        Call<Response_active_ad> call = retrofitInterface.active_ad(token);
        call.enqueue(new Callback<Response_active_ad>() {
            @Override
            public void onResponse(Call<Response_active_ad> call, Response<Response_active_ad> response) {
                if (response != null && response.body() != null) {
                    if (response.body().getResult() != null && response.body().getResult().equals("1")) {
//                        response.body().getRecords().get(0).setAdmob_banner_id("ca-app-pub-3940256099942544/6300978111");
                        if (response.body().getRecords() != null && response.body().getRecords().size() > 0) {
                            if (response.body().getRecords().get(0) != null) {
                                model = response.body().getRecords().get(0);
//                        model=new Model_active_ad("ca-app-pub-3940256099942544/6300978111");
//                        binding.adView.setAdUnitId("ca-app-pub-3940256099942544/6300978111");
                                if (response.body().getRecords().get(0).getActive_ads() != null) {
                                    Constance.active_ads = response.body().getRecords().get(0).getActive_ads();
                                    /*if ( Constance.active_ads .equals("admob_ad")){
                                        googleBannerAd(model.getAdmob_banner_id());
                                    }else {
                                    }*/
                                }
                                if (response.body().getRecords().get(0).getAdmob_banner_id() != null) {
                                    Constance.admob_banner = response.body().getRecords().get(0).getAdmob_banner_id();
                                    if (Constance.active_ads.equals("admob_ad")) {
                                        googleBannerAd(model.getAdmob_banner_id());
                                    }
                                }
                                if (response.body().getRecords().get(0).getAdmob_fullscreen_id() != null) {
                                    Constance.admob_fullscreen = response.body().getRecords().get(0).getAdmob_fullscreen_id();
                                    googleInterstitialAd( Constance.admob_fullscreen);
                                    if (Constance.active_ads.equals("admob_ad")) {
                                        googleInterstitialAd(Constance.admob_fullscreen);
                                    }
                                }
                                if (response.body().getRecords().get(0).getAdmob_nativex_id() != null) {
                                    Constance.admob_nativex = response.body().getRecords().get(0).getAdmob_nativex_id();
                                }

                                if (response.body().getRecords().get(0).getFacebook_banner_id() != null) {
                                    Constance.facebook_banner = response.body().getRecords().get(0).getFacebook_banner_id();
                                    if (!Constance.active_ads.equals("admob_ad")) {
                                        facebookAd(Constance.facebook_banner);
                                    }
                                }
                                if (response.body().getRecords().get(0).getFacebook_fullscreen_id() != null) {
                                    Constance.facebook_fullscreen = response.body().getRecords().get(0).getFacebook_fullscreen_id();
                                    fbInterstitialAd();
                                }

                                show_fullScreen_Ad();
                            }
                        }
//                        binding.setModel(model);
//                        binding.adView.setAdSize(AdSize.BANNER);
//                        binding.adView.setAdUnitId("ca-app-pub-3940256099942544/6300978111");
//                        String unitid=binding.adView.getAdUnitId();
//                        AdRequest adRequest = new AdRequest.Builder().build();
//                        binding.adView.loadAd(adRequest);
                    }
                }
            }

            @Override
            public void onFailure(Call<Response_active_ad> call, Throwable t) {
//                Toast.makeText(context, t.getMessage(), Toast.LENGTH_SHORT).show();
                Log.e("response", "reset passwrd :" + t.getMessage());
            }
        });
    }

    public void handlerStart() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
//                displayAdMob();
                Constance.AllowToOpenAdvertise = true;
                Log.d("kkksxsdsdshds", "handler" + Constance.AllowToOpenAdvertise);
            }
        }, 1000 * 40);
    }

    public void show_fullScreen_Ad() {
        if (Constance.AllowToOpenAdvertise) {
            if (Constance.active_ads.equals("admob_ad")) {
                if (googleFullscreen != null) {
                    googleFullscreen.show(this);
                } else {
//                    Toast.makeText(context, "Ad did not load", Toast.LENGTH_SHORT).show();
//                    googleInterstitialAd();
//            startGame();
                }
            } else {
                if (fbFullscreen != null && fbFullscreen.isAdLoaded()) {
                    fbFullscreen.show();
                }
            }
        } else {

        }
    }


}
