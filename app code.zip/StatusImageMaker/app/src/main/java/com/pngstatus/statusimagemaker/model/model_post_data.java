package com.pngstatus.statusimagemaker.model;

import com.google.gson.annotations.SerializedName;

public class model_post_data {
    @SerializedName("view")
    private boolean view=false;
    @SerializedName("downloadId")
    private String downloadId ;
    @SerializedName("fileName")
    private String fileName ;
    @SerializedName("id")
    private String id;
    @SerializedName("category_id")
    private String category_id;
    @SerializedName("language_id")
    private String language_id;
    @SerializedName("preview_image")
    private String preview_image;
    @SerializedName("frame_image")
    private String frame_image;
    @SerializedName("status")
    private String status;
    @SerializedName("created_at")
    private String created_at;
    @SerializedName("updated_at")
    private String updated_at;
    @SerializedName("deleted_at")
    private String deleted_at;
    @SerializedName("view_count")
    private String view_count;
    @SerializedName("download_count")
    private String download_count;
    @SerializedName("share_count")
    private String share_count;
    @SerializedName("edit_count")
    private String edit_count;

    /*
    @SerializedName("total_view")
    private String total_view;
    @SerializedName("total_share")
    private String total_share;
    @SerializedName("total_download")
    private String total_download;*/
    @SerializedName("is_my_favorite")
    private String is_my_favorite;
    @SerializedName("preview_image_url")
    private String preview_image_url;
    @SerializedName("frame_image_url")
    private String frame_image_url;
    @SerializedName("favourite")
    private model_post_data_favourite favourite;

    public model_post_data() {
    }

    public boolean isView() {
        return view;
    }

    public void setView(boolean view) {
        this.view = view;
    }

    public String getDownloadId() {
        return downloadId;
    }

    public void setDownloadId(String downloadId) {
        this.downloadId = downloadId;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCategory_id() {
        return category_id;
    }

    public void setCategory_id(String category_id) {
        this.category_id = category_id;
    }

    public String getLanguage_id() {
        return language_id;
    }

    public void setLanguage_id(String language_id) {
        this.language_id = language_id;
    }

    public String getPreview_image() {
        return preview_image;
    }

    public void setPreview_image(String preview_image) {
        this.preview_image = preview_image;
    }

    public String getFrame_image() {
        return frame_image;
    }

    public void setFrame_image(String frame_image) {
        this.frame_image = frame_image;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCreated_at() {
        return created_at;
    }

    public void setCreated_at(String created_at) {
        this.created_at = created_at;
    }

    public String getUpdated_at() {
        return updated_at;
    }

    public void setUpdated_at(String updated_at) {
        this.updated_at = updated_at;
    }

    public String getDeleted_at() {
        return deleted_at;
    }

    public void setDeleted_at(String deleted_at) {
        this.deleted_at = deleted_at;
    }

    public String getPreview_image_url() {
        return preview_image_url;
    }

    public void setPreview_image_url(String preview_image_url) {
        this.preview_image_url = preview_image_url;
    }

    public String getFrame_image_url() {
        return frame_image_url;
    }

    public void setFrame_image_url(String frame_image_url) {
        this.frame_image_url = frame_image_url;
    }

    public String getView_count() {
        return view_count;
    }

    public void setView_count(String view_count) {
        this.view_count = view_count;
    }

    public String getDownload_count() {
        return download_count;
    }

    public void setDownload_count(String download_count) {
        this.download_count = download_count;
    }

    public String getShare_count() {
        return share_count;
    }

    public void setShare_count(String share_count) {
        this.share_count = share_count;
    }

    public String getEdit_count() {
        return edit_count;
    }

    public void setEdit_count(String edit_count) {
        this.edit_count = edit_count;
    }

    public String getIs_my_favorite() {
        return is_my_favorite;
    }

    public void setIs_my_favorite(String is_my_favorite) {
        this.is_my_favorite = is_my_favorite;
    }

    public model_post_data_favourite getFavourite() {
        return favourite;
    }

    public void setFavourite(model_post_data_favourite favourite) {
        this.favourite = favourite;
    }
}
