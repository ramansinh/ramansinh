package com.pngstatus.statusimagemaker.Activity;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.facebook.ads.Ad;
import com.facebook.ads.InterstitialAdListener;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.pngstatus.statusimagemaker.Adapter.AdapterImgTextChng;
import com.pngstatus.statusimagemaker.R;
import com.pngstatus.statusimagemaker.Retrofit.RetrofitClient;
import com.pngstatus.statusimagemaker.Retrofit.RetrofitInterface;
import com.pngstatus.statusimagemaker.Utils.Constance;
import com.pngstatus.statusimagemaker.Utils.EndlessRecyclerOnScrollListener;
import com.pngstatus.statusimagemaker.Utils.ImageSelection;
import com.pngstatus.statusimagemaker.Utils.LocaleHelper;
import com.pngstatus.statusimagemaker.Utils.OnItemClickListener;
import com.pngstatus.statusimagemaker.Utils.Popup_success;
import com.pngstatus.statusimagemaker.Utils.Prefs;
import com.pngstatus.statusimagemaker.model.Model_active_ad;
import com.pngstatus.statusimagemaker.model.Response_active_ad;
import com.pngstatus.statusimagemaker.model.Response_post;
import com.pngstatus.statusimagemaker.model.model_post;
import com.pngstatus.statusimagemaker.model.model_post_data;
import com.yalantis.ucrop.UCrop;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import butterknife.BindView;
import butterknife.ButterKnife;
import id.zelory.compressor.Compressor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.pngstatus.statusimagemaker.Utils.ImageSelection.getFilePath;

public class EditFvrtPostActivity extends AppCompatActivity {
    Context context;
    @BindView(R.id.ivShare)
    Button ivShare;
    @BindView(R.id.ivSave)
    Button ivSave;
    @BindView(R.id.tvTitle)
    TextView tvTitle;

    final int TAKE_PHOTO_FROM_CAMARA = 0, TAKE_PHOTO_FROM_GALLARY = 1;
    String[] permissionsRequired = {Manifest.permission.CAMERA,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_EXTERNAL_STORAGE};
    private final int PERMISSION_CALLBACK_CONSTANT = 200;
    boolean imgselected = false;

    String realPath = "", imgpath1 = "";
    Bitmap bitmap;

    @BindView(R.id.btn_slct_bckgrnd)
    Button btn_slct_bckgrnd;
    @BindView(R.id.btn_advnc_editr)
    Button btn_advnc_editr;
    @BindView(R.id.iv_main_img)
    ImageView iv_main_img;
    @BindView(R.id.iv_text_img)
    ImageView iv_text_img;
    @BindView(R.id.rl_final_img)
    RelativeLayout rl_final_img;
    @BindView(R.id.rv_list)
    RecyclerView rv_list;
    @BindView(R.id.loader)
    ProgressBar loader;

    Uri sourceUri, destinationUri;

    private static final int REQUEST_SELECT_PICTURE_FOR_FRAGMENT = 0x02;
    private static final String SAMPLE_CROPPED_IMAGE_NAME = "SampleCropImage";
    Bitmap bmp;

    AdapterImgTextChng adapterImgTextChng;
    ArrayList<model_post_data> arrayList = new ArrayList<>();
    String url = "";
    model_post model;
    Uri resultUri;
    String frameUrl = "";
    int pos = 0;

    @BindView(R.id.ll_adView)
    public LinearLayout ll_adView;
    public com.facebook.ads.AdView fadView;
    public Timer timer;
    public TimerTask hourlyTask;
    public InterstitialAd googleFullscreen;
    public com.facebook.ads.InterstitialAd fbFullscreen;
    Model_active_ad modelad;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_post);
        context = EditFvrtPostActivity.this;
        ButterKnife.bind(this);
        checkPermission();
        if (Build.VERSION.SDK_INT < 16) {
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                    WindowManager.LayoutParams.FLAG_FULLSCREEN);
        } else {
            View decorView = getWindow().getDecorView();
            // Hide Status Bar.
            int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
            decorView.setSystemUiVisibility(uiOptions);
        }

        if (getIntent().hasExtra(Constance.img_url)) {
            url = getIntent().getStringExtra(Constance.img_url);
            Glide.with(context).load(url).into(iv_text_img);
        }

        if (getIntent().hasExtra(Constance.pos)) {
            pos = getIntent().getIntExtra(Constance.pos, 0);
        }

        ivSave.setVisibility(View.VISIBLE);
        ivShare.setVisibility(View.VISIBLE);
        tvTitle.setText("");
        getFvrtPost();
        btn_slct_bckgrnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isPermission()) {
                    pickFromGallery();
                } else {
                    checkPermission();
                }
            }
        });

        String applang = Prefs.getPrefString(context, Constance.select_app_lang, "en");
        LocaleHelper.setLocale(context, applang);
        arrayList.clear();
        LinearLayoutManager lm = new LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false);
        rv_list.setLayoutManager(lm);

        rv_list.addOnScrollListener(new EndlessRecyclerOnScrollListener(lm) {
            @Override
            public void onLoadMore(int page, int totalItemsCount, RecyclerView view) {
                if (model != null && model.getNext_page_url() != null) {
                    loadNextDataFromApi();
                }
            }
        });

        btn_advnc_editr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (imgselected) {
//                    bitmap=viewToBitmap(rl_final_img);
//                    download_snd_Img();
                    File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + "/pngStatus/", "tempimg.png");
                    if (file.exists()) {
                        file.delete();
                    }
                    try {
                        Uri uri = saveImage();
                        File file1 = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + "/pngStatus/" + getFilePath(context, uri));
                        Intent intent = new Intent(context, CustomEditorActivity.class);
//                        intent.putExtra("bitmap", file1.getAbsolutePath());
                        intent.putExtra("imgpath", imgpath1);
                        intent.putExtra("frameUrl", frameUrl);
                        startActivity(intent);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                } else {
                    Toast.makeText(context, getResources().getString(R.string.selct_img), Toast.LENGTH_SHORT).show();
                }
            }
        });

        handlerStart();

        active_ad();

        ivShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isPermission()) {
                    String filename = String.valueOf(Calendar.getInstance().getTimeInMillis());
                    download_ShareImg(filename);
                } else {
                    checkPermission();
                }
            }
        });
        ivSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isPermission()) {
                    String filename = String.valueOf(Calendar.getInstance().getTimeInMillis());
                    try {
                        download_Img(filename);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } else {
                    checkPermission();
                }
            }
        });
       /* adapterImgTextChng=new AdapterImgTextChng(context,arrayList);
        rv_list.setAdapter(adapterImgTextChng);*/
    }

    private void getFvrtPost() {
        loader.setVisibility(View.VISIBLE);
        String token = Prefs.getPrefString(context, Constance.api_token, "");

        RetrofitInterface retrofitInterface = RetrofitClient.getClient().create(RetrofitInterface.class);
        Call<Response_post> call = retrofitInterface.my_favorite_post(token);
        call.enqueue(new Callback<Response_post>() {
            @Override
            public void onResponse(Call<Response_post> call, Response<Response_post> response) {
                if (response != null && response.body() != null) {
                    if (response.body().getRecords() != null) {
                        model = response.body().getRecords();
                        if (model.getData() != null &&
                                model.getData().size() > 0) {
                            arrayList.clear();
                            arrayList.addAll(model.getData());
                            if (arrayList.get(pos).getFrame_image_url() != null) {
                                frameUrl = arrayList.get(pos).getFrame_image_url();
                            }
                            adapterImgTextChng = new AdapterImgTextChng(context, arrayList, new OnItemClickListener() {
                                @Override
                                public void onItemClick(View item, int position) {
                                    if (arrayList.get(position).getFrame_image_url() != null) {
                                        frameUrl = arrayList.get(position).getFrame_image_url();
                                        Glide.with(context).load(arrayList.get(position).getFrame_image_url()).into(iv_text_img);
                                    }
                                }

                                @Override
                                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                                }
                            });

                            // Adding the Adapter to the ViewPager
                            rv_list.setAdapter(adapterImgTextChng);
                            loader.setVisibility(View.GONE);
                        } else {
                            loader.setVisibility(View.GONE);
//                        Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        }

                    } else {
                        loader.setVisibility(View.GONE);
//                        Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                } else {
                    loader.setVisibility(View.GONE);
//                        Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                }
                loader.setVisibility(View.GONE);
            }

            @Override
            public void onFailure(Call<Response_post> call, Throwable t) {
                loader.setVisibility(View.GONE);
//                Toast.makeText(context, t.getMessage(), Toast.LENGTH_SHORT).show();
                Log.e("response", "login :" + t.getMessage());
            }
        });
    }

    public void loadNextDataFromApi() {
        loader.setVisibility(View.VISIBLE);
        String token = Prefs.getPrefString(context, Constance.api_token, "");

        StringRequest stringRequest = new StringRequest(Request.Method.POST, model.getNext_page_url(), new com.android.volley.Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONObject records = jsonObject.getJSONObject("records");
                    Gson gson = new Gson();
                    Type type = new TypeToken<model_post>() {
                    }.getType();
                    model = gson.fromJson(records.toString(), type);
                    ArrayList<model_post_data> list = model.getData();


                    if (list!=null && list.size() != 0) {
                        arrayList.addAll(list);
                        adapterImgTextChng.notifyDataSetChanged();
                        loader.setVisibility(View.GONE);
                    } else {
                        loader.setVisibility(View.GONE);
                    }
                  /*  if (jsonObject.getString("result").equals("1")) {
                        JSONObject jsonPostObject = jsonObject.getJSONObject("records");
                        Gson gson = new Gson();
                        Type type = new TypeToken<model_post>() {
                        }.getType();

                        model = gson.fromJson(jsonPostObject.toString(), type);

                       *//* JSONArray jsonArray = jsonPostObject.getJSONArray("data");
                        Type typeForPostArray = new TypeToken<List<model_receive_message>>() {
                        }.getType();
                        List<model_receive_message_data> list = gson.fromJson(jsonArray.toString(), typeForPostArray);
                       *//*

                        ArrayList<model_post_data> list = model.getData();
                        arrayList.addAll(list);

                        if (list.size() != 0) {
                            adapterImgTextChng.notifyDataSetChanged();
                            loader.setVisibility(View.GONE);
                        } else {
                            loader.setVisibility(View.GONE);
                        }
                        loader.setVisibility(View.GONE);
                    } else {
//                        AlertDialogBox.AlertMessage(context, jsonObject.getString("message"));
                        loader.setVisibility(View.GONE);
                    }*/
                    loader.setVisibility(View.GONE);
                } catch (JSONException e) {
                    e.printStackTrace();
                    loader.setVisibility(View.GONE);
                }
            }
        }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
//                Toast.makeText(context, "Please Check Your Internet Connection", Toast.LENGTH_SHORT).show();
                loader.setVisibility(View.GONE);
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
//                params.put("token",Prefs.getPrefString(context,Constance.auth_token,""));
                params.put("api_token", token);
//                params.put("category_id", "");
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(context);
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(60000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(stringRequest);
    }

    private void pickFromGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
                .setType("image/*");
//                .addCategory(Intent.CATEGORY_OPENABLE);

       /* if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            String[] mimeTypes = {"image/jpeg","image/png"};
            intent.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes);
        }*/
        String[] mimeTypes = {"image/jpeg", "image/png"};
        intent.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes);
        startActivityForResult(intent, 1);
//        startActivityForResult(Intent.createChooser(intent, getString(R.string.select_photo)), 1);
    }

    private void startCrop(@NonNull Uri uri) {
        String destinationFileName = SAMPLE_CROPPED_IMAGE_NAME;
//        String filename = UUID.randomUUID().toString();
//        String fileName = Integer.toString(new Random().nextInt(1000000000)) + ".jpeg";
        String filename = String.valueOf(Calendar.getInstance().getTimeInMillis());
        File storageDir;
     /*   if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            // only for gingerbread and newer versions
            storageDir = new File(context.getExternalFilesDir(null), "/pngStatus/");
        } else {
//            storageDir = new File(Environment.getExternalStorageDirectory() + "/pngStatus/");
            storageDir =new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).toString()+ "/pngStatus/");
        }*/
        storageDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + "/pngStatus/");
        UCrop.Options options = new UCrop.Options();
        UCrop uCrop = UCrop.of(uri, Uri.fromFile(new File(getCacheDir(), filename + ".png")));
        options.setHideBottomControls(true);
//        options.setFreeStyleCropEnabled(true);

        options.setToolbarColor(getResources().getColor(R.color.colorPrimarylight));
        uCrop.withAspectRatio(9, 16);
        uCrop.withMaxResultSize(720, 1080);
        uCrop.withOptions(options);
        uCrop.start(this);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == 1) {
                if (data != null && data.getData() != null) {
                    final Uri selectedUri = data.getData();
                    if (selectedUri != null) {
                        startCrop(selectedUri);
                    } else {
                        Toast.makeText(this, getResources().getString(R.string.toast_cannot_retrieve_selected_image), Toast.LENGTH_SHORT).show();
                    }
                }
            } else if (requestCode == UCrop.REQUEST_CROP) {
//                handleCropResult(data);
                resultUri = UCrop.getOutput(data);
                Bitmap bm1 = null;
                if (data != null && resultUri != null) {
                   /* try {
                        bm1 = MediaStore.Images.Media.getBitmap(context.getApplicationContext().getContentResolver(), data.getData());
                    } catch (IOException e) {
                        e.printStackTrace();
                    }*/
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
//                        realPath = ImageSelection.getPath(context, data.getData());
                        realPath = ImageSelection.getPath(context, resultUri);
//                            imgpath1 = realPath;
                    } else {
                        realPath = ImageSelection.getPath1(context, resultUri);
//                            imgpath1 = realPath;
                    }
                   /* File file=new File(data.getData().toString());
                    String path=file.getAbsolutePath();*/
                    File compressedImageFile = null;
                    String uriString = realPath;
                    File file = new File(uriString);
                    try {
                        compressedImageFile = new Compressor(context).compressToFile(file);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    imgpath1 = compressedImageFile.getAbsolutePath();
//                    iv_main_img.setImageBitmap(bm1);
                    imgselected = true;
                    btn_advnc_editr.setVisibility(View.VISIBLE);
                    bitmap = getBitmap(resultUri);
//                    Glide.with(context).load(imgpath1).into(iv_main_img);
                    int height = bitmap.getHeight();
                    int width = bitmap.getWidth();
                    iv_main_img.setImageBitmap(bitmap);
//
                } else {
                    btn_advnc_editr.setVisibility(View.GONE);
                }
            }
        }

        if (resultCode == UCrop.RESULT_ERROR) {
            handleCropError(data);
        }
    }

    public Bitmap viewToBitmap(View view) {
        Bitmap bitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        view.draw(canvas);
        return bitmap;
    }

    private Bitmap getBitmap(Uri uri) {
        if (uri == null) return null;

        Bitmap bitmap = null;
        try {
            ContentResolver cr = this.getContentResolver();
            bitmap = BitmapFactory.decodeStream(cr.openInputStream(uri));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
//            LogUtils.e("Exception", e.getMessage(),e);
        }
        return bitmap;
    }

    private void download_snd_Img() {
        if (imgselected) {
            String filename = "tempimg";
            Bitmap bm = viewToBitmap(rl_final_img);

            File storageDir;
            storageDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + "/pngStatus/");

            /*if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                // only for gingerbread and newer versions
                storageDir = new File(context.getExternalFilesDir(null), "/pngStatus/");
//                storageDir = new File(context.getExternalFilesDir(null), "/pngStatus/");
            } else {
                storageDir =new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).toString()+ "/pngStatus/");
//                storageDir = new File(Environment.getExternalStorageDirectory() + "/pngStatus/");
            }*/

            if (storageDir.exists()) {
                Log.e("tag", "exitst file path" + storageDir.getAbsolutePath());
            } else {
                storageDir.mkdirs();
            }
            Constance.createdBitmap = scaleBitmap(bm, bm.getWidth(), bm.getHeight());

            File file = new File(storageDir, filename + ".png");
            if (file.exists())
                file.delete();
            try {
                FileOutputStream out = new FileOutputStream(file);
                Constance.createdBitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
                Toast.makeText(context, filename + ".png" + getResources().getString(R.string.msg_dwnld_sucssfully), Toast.LENGTH_SHORT).show();
//                out.flush();
                out.close();

                Uri uri = Uri.parse(file.getAbsolutePath());
                Intent intent = new Intent(context, CustomEditorActivity.class);
                intent.putExtra("bitmap", file.getAbsolutePath());
                startActivity(intent);
//                finish();
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            Toast.makeText(context, getResources().getString(R.string.label_select_picture), Toast.LENGTH_SHORT).show();
        }
    }

    private Uri saveImage() throws IOException {
        OutputStream fos = null;
        File imageFile = null;
        Uri imageUri = null;
        Bitmap bitmap = viewToBitmap(rl_final_img);

        File imagesDir1 = new File(Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_PICTURES).toString() + "/pngStatus/");
//                Environment.DIRECTORY_PICTURES).toString() + File.separator + "tempimg.png");
        if (!imagesDir1.exists())
            imagesDir1.mkdir();
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                ContentResolver resolver = context.getContentResolver();
                ContentValues contentValues = new ContentValues();
                contentValues.put(MediaStore.MediaColumns.DISPLAY_NAME, "tempimg.png");
                contentValues.put(MediaStore.MediaColumns.MIME_TYPE, "image/png");
                contentValues.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/pngStatus");
                imageUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues);
                if (imageUri == null)
                    throw new IOException("Failed to create new MediaStore record.");
//                fos = resolver.openOutputStream(imageUri);
                try {
                    fos = resolver.openOutputStream(imageUri);

                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            } else {
                imagesDir1 = new File(Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_PICTURES) + "/pngStatus/");
                if (!imagesDir1.exists())
                    imagesDir1.mkdir();
                File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + "/pngStatus", "tempimg.png");
                if (file.exists())
                    file.delete();
                imageFile = new File(imagesDir1, "tempimg.png");
                try {
                    fos = new FileOutputStream(imageFile);
//                    Constance.createdBitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            }
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
//                throw new IOException("Failed to save bitmap.");
            fos.flush();
        } finally {
            if (fos != null)
                fos.close();
        }
        if (imageFile != null) {//pre Q
            MediaScannerConnection.scanFile(context, new String[]{imageFile.toString()}, null, null);
            imageUri = Uri.fromFile(imageFile);

        } /*else {
            Toast.makeText(context,getResources().getString( R.string.img_not_saved), Toast.LENGTH_SHORT).show();
        }*/
      /* else {
            Toast.makeText(context,getResources().getString( R.string.img_not_saved), Toast.LENGTH_SHORT).show();
        }*/
        return imageUri;
    }

    private void download_Img(String fname) throws IOException {
        OutputStream fos = null;
        File imageFile = null;
        Uri imageUri = null;

        if (imgselected) {
            String filename = fname;
            Bitmap bm = viewToBitmap(rl_final_img);
            File storageDir;
            /*if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                // only for gingerbread and newer versions
                storageDir = new File(context.getExternalFilesDir(null), "/pngStatus/");
//                storageDir = new File(context.getExternalFilesDir(null), "/pngStatus/");
            } else {
                storageDir =new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).toString()+ "/pngStatus/");
//                storageDir = new File(Environment.getExternalStorageDirectory() + "/pngStatus/");
            }*/
            storageDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + "/pngStatus/");
            if (storageDir.exists()) {
                Log.e("tag", "exitst file path" + storageDir.getAbsolutePath());
            } else {
                storageDir.mkdirs();
                Log.e("tag", "gnrt exitst file path" + storageDir.getAbsolutePath());
            }
//            Constance.createdBitmap = scaleBitmap(bm, bm.getWidth(), bm.getHeight());

            File file = new File(storageDir, filename + ".png");
            if (file.exists())
                file.delete();
            /*try {
                FileOutputStream out = new FileOutputStream(file);
                Constance.createdBitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
//                Toast.makeText(context, filename + ".png" + getResources().getString(R.string.msg_dwnld_sucssfully), Toast.LENGTH_SHORT).show();
                out.flush();
                out.close();
                Popup_success popup_success = new Popup_success();
                popup_success.Popup_success(context, filename + ".png" + getResources().getString(R.string.msg_dwnld_sucssfully));
            } catch (Exception e) {
                e.printStackTrace();
            }*/
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    ContentResolver resolver = context.getContentResolver();
                    ContentValues contentValues = new ContentValues();
                    contentValues.put(MediaStore.MediaColumns.DISPLAY_NAME, filename + ".png");
                    contentValues.put(MediaStore.MediaColumns.MIME_TYPE, "image/png");
                    contentValues.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/pngStatus/");
                    imageUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues);
                    if (imageUri == null)
                        throw new IOException("Failed to create new MediaStore record.");
//                fos = resolver.openOutputStream(imageUri);
                    try {
                        fos = resolver.openOutputStream(imageUri);
                        bm.compress(Bitmap.CompressFormat.PNG, 100, fos);
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                } else {

                    file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + "/pngStatus/", filename + ".png");
                    if (file.exists())
                        file.delete();
                    imageFile = new File(storageDir, filename + ".png");
                    try {
                        fos = new FileOutputStream(imageFile);
                        bm.compress(Bitmap.CompressFormat.PNG, 100, fos);
//                    Constance.createdBitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                }

//                throw new IOException("Failed to save bitmap.");
                fos.flush();
            } finally {
                if (fos != null)
                    fos.close();
            }
            if (imageFile != null) {//pre Q
                MediaScannerConnection.scanFile(context, new String[]{imageFile.toString()}, null, null);
                imageUri = Uri.fromFile(imageFile);
            }
            Popup_success popup_success = new Popup_success();
            popup_success.Popup_success(context, getResources().getString(R.string.msg_dwnld_sucssfully));
        } else {
            Toast.makeText(context, getResources().getString(R.string.label_select_picture), Toast.LENGTH_SHORT).show();
        }
    }

    private void saveimg(Bitmap bitmap) {
        String imgname = "tempimg.jpg";
        String path = (new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + "/pngStatus/")).getAbsolutePath();
        Uri uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;

    }

    private void download_ShareImg(String name) {
        OutputStream fos = null;
        File imageFile = null;
        Uri imageUri = null;
        if (imgselected) {
            String filename = name;
            Bitmap bm = viewToBitmap(rl_final_img);

            File storageDir;
           /* if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                // only for gingerbread and newer versions
                storageDir = new File(context.getExternalFilesDir(null), "/pngStatus/");
            } else {
//                storageDir = new File(Environment.getExternalStorageDirectory() + "/pngStatus/");
                storageDir =new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).toString()+ "/pngStatus/");
            }*/
            storageDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + "/pngStatus");
            if (storageDir.exists()) {
                Log.e("tag", "exitst file path" + storageDir.getAbsolutePath());
            } else {
                storageDir.mkdirs();
            }
//            Constance.createdBitmap = scaleBitmap(bm, bm.getWidth(), bm.getHeight());
//            Constance.createdBitmap = scaleBitmap(bm, 780, 1080);

            File file = new File(storageDir, filename + ".png");
            if (file.exists())
                file.delete();
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    ContentResolver resolver = context.getContentResolver();
                    ContentValues contentValues = new ContentValues();
                    contentValues.put(MediaStore.MediaColumns.DISPLAY_NAME, filename + ".png");
                    contentValues.put(MediaStore.MediaColumns.MIME_TYPE, "image/png");
                    contentValues.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/pngStatus/");
                    imageUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues);
                    if (imageUri == null)
                        throw new IOException("Failed to create new MediaStore record.");
//                fos = resolver.openOutputStream(imageUri);
                    try {
                        fos = resolver.openOutputStream(imageUri);
                        bm.compress(Bitmap.CompressFormat.PNG, 100, fos);
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                } else {
                    file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + "/pngStatus/", filename + ".png");
                    if (file.exists())
                        file.delete();
                    imageFile = new File(storageDir, filename + ".png");
                    try {
                        fos = new FileOutputStream(imageFile);
                        bm.compress(Bitmap.CompressFormat.PNG, 100, fos);
//                    Constance.createdBitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                }

//                throw new IOException("Failed to save bitmap.");

                fos.flush();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (fos != null) {
                    try {
                        fos.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            if (imageFile != null) {//pre Q
                MediaScannerConnection.scanFile(context, new String[]{imageFile.toString()}, null, null);
                imageUri = Uri.fromFile(imageFile);
            }
            shareItem(imageUri);
          /*  try {
                FileOutputStream out = new FileOutputStream(file);
                Constance.createdBitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
                StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
                StrictMode.setVmPolicy(builder.build());
                shareItem(getLocalBitmapUri(filename + ".png"));
                out.flush();
                out.close();
            } catch (Exception e) {
                e.printStackTrace();
            }*/

        } else {
            Toast.makeText(context, getResources().getString(R.string.selct_img), Toast.LENGTH_SHORT).show();
        }
    }

    public void shareItem(Uri uri) {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("image/*");
//        File file = new File(uri.getPath());
        File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + "/pngStatus/" + ImageSelection.getFilePath(context, uri));
      /*  Uri photoUri = FileProvider.getUriForFile(
                context,
                getResources().getString(R.string.file_provider_authority),
                file);*/
//        share.putExtra(Intent.EXTRA_SUBJECT, "Title Of The Post");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        i.putExtra(Intent.EXTRA_TEXT, getResources().getString(R.string.sim_link) + getApplication().getPackageName());
        i.putExtra(Intent.EXTRA_STREAM, uri);
        startActivity(Intent.createChooser(i, getResources().getString(R.string.share_img)));

    }

    public Uri getLocalBitmapUri(String name) {
//    public Uri getLocalBitmapUri(Bitmap bmp, String name) {
        Uri bmpUri = null;
        try {
            File file;
            file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).toString() + "/pngStatus/");
           /* if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                // only for gingerbread and newer versions
                file = new File(context.getExternalFilesDir(null), "/pngStatus/");
            } else {
                file = new File(Environment.getExternalStorageDirectory() + "/pngStatus/");
            }*/
            File filePath = new File(file, name);
            FileOutputStream out = new FileOutputStream(filePath);
//            bmp.compress(Bitmap.CompressFormat.PNG, 90, out);
            out.close();
            bmpUri = Uri.fromFile(filePath);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return bmpUri;
    }

    private Bitmap scaleBitmap(Bitmap bitmap, int wantedWidth, int wantedHeight) {
        float originalWidth = bitmap.getWidth();
        float originalHeight = bitmap.getHeight();
        Bitmap output = Bitmap.createBitmap(wantedWidth, wantedHeight, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(output);
        Matrix m = new Matrix();
        float scalex = wantedWidth / originalWidth;
        float scaley = wantedHeight / originalHeight;
        float xTranslation = 0.0f;
        float yTranslation = (wantedHeight - originalHeight * scaley) / 2.0f;
        m.postTranslate(xTranslation, yTranslation);
        m.preScale(scalex, scaley);
        // m.setScale((float) wantedWidth / bitmap.getWidth(), (float) wantedHeight / bitmap.getHeight());
        Paint paint = new Paint();
        paint.setFilterBitmap(true);
        canvas.drawBitmap(bitmap, m, paint);
        return output;

    }

    private void handleCropError(@NonNull Intent result) {
        final Throwable cropError = UCrop.getError(result);
        if (cropError != null) {
            Log.e("ucrop", "handleCropError: ", cropError);
            Toast.makeText(context, cropError.getMessage(), Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(context, getResources().getString(R.string.toast_unexpected_error), Toast.LENGTH_SHORT).show();
        }
    }

    private boolean isPermission() {
        if (ActivityCompat.checkSelfPermission(context, permissionsRequired[0]) != PackageManager.PERMISSION_GRANTED
                || ActivityCompat.checkSelfPermission(context, permissionsRequired[1]) != PackageManager.PERMISSION_GRANTED
                || ActivityCompat.checkSelfPermission(context, permissionsRequired[2]) != PackageManager.PERMISSION_GRANTED) {
//            checkPermission();
            return false;
        } else {
            return true;
        }
    }

    public void checkPermission() {
        if (ActivityCompat.checkSelfPermission(context, permissionsRequired[0]) != PackageManager.PERMISSION_GRANTED
                || ActivityCompat.checkSelfPermission(context, permissionsRequired[1]) != PackageManager.PERMISSION_GRANTED
                || ActivityCompat.checkSelfPermission(context, permissionsRequired[2]) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale((Activity) context, permissionsRequired[0])
                    || ActivityCompat.shouldShowRequestPermissionRationale((Activity) context, permissionsRequired[1])
                    || ActivityCompat.shouldShowRequestPermissionRationale((Activity) context, permissionsRequired[2])) {
                //Show Information about why you need the permission
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setTitle(getResources().getString(R.string.need_multiple_prmisn));
                builder.setMessage(getResources().getString(R.string.app_need_multiple_prmisn));
                builder.setPositiveButton(getResources().getString(R.string.grant), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                        ActivityCompat.requestPermissions((Activity) context, permissionsRequired, PERMISSION_CALLBACK_CONSTANT);
                    }
                });
                builder.setNegativeButton(getResources().getString(R.string.cancel), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
//                        onBackPressed();
                    }
                });
                builder.show();
            } else {
                //just request the permission
                ActivityCompat.requestPermissions((Activity) context, permissionsRequired, PERMISSION_CALLBACK_CONSTANT);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case 200: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0 &&
                        grantResults[0] == PackageManager.PERMISSION_GRANTED &&
                        grantResults[1] == PackageManager.PERMISSION_GRANTED &&
                        grantResults[2] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.
                } else {
                    checkPermission();
//                    onBackPressed();
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }

    public void facebookAd(String adId) {
        if (adId.equals("")){
            adId="IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID";
        }
        ll_adView.removeAllViews();
        fadView = new com.facebook.ads.AdView(this, adId, com.facebook.ads.AdSize.BANNER_HEIGHT_50);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        fadView.setLayoutParams(lp);
        ll_adView.addView(fadView);
        fadView.loadAd();
    }

    public void googleBannerAd(String unitId) {
        ll_adView.removeAllViews();
        AdView adView = new AdView(context);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        adView.setLayoutParams(lp);
        adView.setAdSize(AdSize.BANNER);
        adView.setAdUnitId(unitId);
        ll_adView.addView(adView);
        AdRequest adRequest = new AdRequest.Builder().build();
//        List<String> testDeviceIds = Arrays.asList("33BE2250B43518CCDA7DE426D04EE231");
      /*  RequestConfiguration configuration =
                new RequestConfiguration.Builder().setTestDeviceIds(testDeviceIds).build();
        MobileAds.setRequestConfiguration(configuration);*/

        adView.loadAd(adRequest);
        adView.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                super.onAdClosed();
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                super.onAdFailedToLoad(loadAdError);
            }

            @Override
            public void onAdOpened() {
                super.onAdOpened();
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
            }

            @Override
            public void onAdClicked() {
                super.onAdClicked();
            }

            @Override
            public void onAdImpression() {
                super.onAdImpression();
            }
        });

    }

    public void googleInterstitialAd(String adId) {
//        String  adId = Constance.admob_fullscreen;
        if (adId.equals("")) {
            adId = "ca-app-pub-3940256099942544/1033173712";
        }
        AdRequest adRequest = new AdRequest.Builder().build();

        InterstitialAd.load(context, adId, adRequest, new InterstitialAdLoadCallback() {
            @Override
            public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                super.onAdLoaded(interstitialAd);
                // The mInterstitialAd reference will be null until
                // an ad is loaded.
                googleFullscreen = interstitialAd;
//                if (Constance.isFirstTimeOpen) {
                show_fullScreen_Ad();
//                }
                Log.i("TAG", "onAdLoaded");
                googleFullscreen.setFullScreenContentCallback(new FullScreenContentCallback() {
                    @Override
                    public void onAdDismissedFullScreenContent() {
                        // Called when fullscreen content is dismissed.
                        Log.d("TAG", "The ad was dismissed.");
                        Constance.AllowToOpenAdvertise = false;
                        googleFullscreen = null;
                        handlerStart();
                     /*   stopTask();
                        startTimer();*/
                        googleInterstitialAd(Constance.admob_fullscreen);
                    }

                    @Override
                    public void onAdFailedToShowFullScreenContent(AdError adError) {
                        // Called when fullscreen content failed to show.
                        Log.d("TAG", "The ad failed to show.");
                        googleFullscreen = null;
//                        Constance.AllowToOpenAdvertise = false;
//                        stopTask();
//                        startTimer();

//                        googleInterstitialAd();
                    }

                    @Override
                    public void onAdShowedFullScreenContent() {
                        // Called when fullscreen content is shown.
                        // Make sure to set your reference to null so you don't
                        // show it a second time.
//                        mInterstitialAd = null;
                        Log.d("TAG", "The ad was shown.");
//                        Constance.AllowToOpenAdvertise = false;
//                        stopTask();
//                        startTimer();
//                        handlerStart();
//                        googleInterstitialAd();
                    }
                });
               /* if (Constance.isFirstTimeOpen){
                    googleFullscreen.show(activity);
                    Constance.isFirstTimeOpen=false;
                }*/
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                super.onAdFailedToLoad(loadAdError);
                // Handle the error
                Log.i("TAG", loadAdError.getMessage());
//                Constance.AllowToOpenAdvertise = false;
//                googleFullscreen = null;
//                stopTask();
//                startTimer();
//                handlerStart();
//                googleInterstitialAd();
            }
        });
    }

    public void fbInterstitialAd() {
        String adId = Constance.facebook_fullscreen;
        fbFullscreen = new com.facebook.ads.InterstitialAd(this, adId);
        InterstitialAdListener fblistener = new InterstitialAdListener() {
            @Override
            public void onInterstitialDisplayed(Ad ad) {
//                stopTask();
//                startTimer();
            }

            @Override
            public void onInterstitialDismissed(Ad ad) {
//                stopTask();
//                startTimer();
                Constance.AllowToOpenAdvertise = false;
                handlerStart();
                fbInterstitialAd();
            }

            @Override
            public void onError(Ad ad, com.facebook.ads.AdError adError) {
//                stopTask();
//                startTimer();
            }

            @Override
            public void onAdLoaded(Ad ad) {
                fbFullscreen.show();
            }

            @Override
            public void onAdClicked(Ad ad) {
//                stopTask();
//                startTimer();
//                fbInterstitialAd();
            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        };
        fbFullscreen.loadAd(fbFullscreen.buildLoadAdConfig()
                .withAdListener(fblistener)
                .build());
    }

    public void active_ad() {

        String token = Prefs.getPrefString(context, Constance.api_token, "");
        RetrofitInterface retrofitInterface = RetrofitClient.getClient().create(RetrofitInterface.class);
        Call<Response_active_ad> call = retrofitInterface.active_ad(token);
        call.enqueue(new Callback<Response_active_ad>() {
            @Override
            public void onResponse(Call<Response_active_ad> call, Response<Response_active_ad> response) {
                if (response != null && response.body() != null) {
                    if (response.body().getResult() != null && response.body().getResult().equals("1")) {
//                        response.body().getRecords().get(0).setAdmob_banner_id("ca-app-pub-3940256099942544/6300978111");
                        if (response.body().getRecords() != null && response.body().getRecords().size() > 0) {
                            if (response.body().getRecords().get(0) != null) {
                                modelad = response.body().getRecords().get(0);
//                        model=new Model_active_ad("ca-app-pub-3940256099942544/6300978111");
//                        binding.adView.setAdUnitId("ca-app-pub-3940256099942544/6300978111");
                                if (response.body().getRecords().get(0).getActive_ads() != null) {
                                    Constance.active_ads = response.body().getRecords().get(0).getActive_ads();
                                    /*if ( Constance.active_ads .equals("admob_ad")){
                                        googleBannerAd(model.getAdmob_banner_id());
                                    }else {
                                    }*/
                                }
                                if (response.body().getRecords().get(0).getAdmob_banner_id() != null) {
                                    Constance.admob_banner = response.body().getRecords().get(0).getAdmob_banner_id();
                                    if (Constance.active_ads.equals("admob_ad")) {
                                        googleBannerAd(modelad.getAdmob_banner_id());
                                    }
                                }
                                if (response.body().getRecords().get(0).getAdmob_fullscreen_id() != null) {
                                    Constance.admob_fullscreen = response.body().getRecords().get(0).getAdmob_fullscreen_id();
                                    googleInterstitialAd( Constance.admob_fullscreen);
                                    if (Constance.active_ads.equals("admob_ad")) {
                                        googleInterstitialAd(Constance.admob_fullscreen);
                                    }
                                }
                                if (response.body().getRecords().get(0).getAdmob_nativex_id() != null) {
                                    Constance.admob_nativex = response.body().getRecords().get(0).getAdmob_nativex_id();
                                }

                                if (response.body().getRecords().get(0).getFacebook_banner_id() != null) {
                                    Constance.facebook_banner = response.body().getRecords().get(0).getFacebook_banner_id();
                                    if (!Constance.active_ads.equals("admob_ad")) {
                                        facebookAd(Constance.facebook_banner);
                                    }
                                }
                                if (response.body().getRecords().get(0).getFacebook_fullscreen_id() != null) {
                                    Constance.facebook_fullscreen = response.body().getRecords().get(0).getFacebook_fullscreen_id();
                                    fbInterstitialAd();
                                }

                                show_fullScreen_Ad();
                            }
                        }
//                        binding.setModel(model);
//                        binding.adView.setAdSize(AdSize.BANNER);
//                        binding.adView.setAdUnitId("ca-app-pub-3940256099942544/6300978111");
//                        String unitid=binding.adView.getAdUnitId();
//                        AdRequest adRequest = new AdRequest.Builder().build();
//                        binding.adView.loadAd(adRequest);
                    }
                }
            }

            @Override
            public void onFailure(Call<Response_active_ad> call, Throwable t) {
//                Toast.makeText(context, t.getMessage(), Toast.LENGTH_SHORT).show();
                Log.e("response", "reset passwrd :" + t.getMessage());
            }
        });
    }
    public void handlerStart() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
//                displayAdMob();
                Constance.AllowToOpenAdvertise = true;
                Log.d("kkksxsdsdshds", "handler" + Constance.AllowToOpenAdvertise);
            }
        }, 1000 * 40);
    }

    public void show_fullScreen_Ad() {
        if (Constance.AllowToOpenAdvertise) {
            if (Constance.active_ads.equals("admob_ad")) {
                if (googleFullscreen != null) {
                    googleFullscreen.show(this);
                } else {
//                    Toast.makeText(context, "Ad did not load", Toast.LENGTH_SHORT).show();
//                    googleInterstitialAd();
//            startGame();
                }
            } else {
                if (fbFullscreen != null && fbFullscreen.isAdLoaded()) {
                    fbFullscreen.show();
                }
            }
        } else {

        }
    }

}
