package com.pngstatus.statusimagemaker.Utils;

import android.graphics.Bitmap;
import android.os.Environment;

import java.io.File;
import java.util.Arrays;
import java.util.List;

public class Constance {

    public static final String islogin = "islogin";
    public static final String skipLogin = "skipLogin";
    public static final String device_id = "123456789";
    public static final String device = "android";

    public static final String user = "user";
    public static final String api_token = "api_token";
    public static final String userName = "userName";
    public static final String userId = "userId";
    public static final String userEmail = "userEmail";
    public static final String password = "password";
    public static final String userMobile = "userMobile";
    public static final String birth_date = "birth_date";
    public static final String quote_id = "quote_id";
    public static final String CatId = "CatId";
    public static final String Giude = "Giude";
    public static final String lati = "lati";
    public static final String longi = "longi";
    public static final String select_app_lang = "select_app_lang";
    public static final String select_status_lang = "select_status_lang";
    public static final String img_url = "img_url";
    public static final String pos = "pos";
    public static final String dwnlditm = "dwnlditm";
    public static  boolean frmCat = false;

    public static final String notification = "notification";
    public static Bitmap createdBitmap = null;
    public static final String[] fontList = new String[]{"abeezee.otf", "abrilfatface.otf",
            "acknowledgement.otf", "acme.ttf", "after_shok.ttf", "alexbrush.ttf", "alfaslabone.ttf",
            "alisandra.ttf", "allura.ttf", "almendra.otf", "almendraaisplay.otf", "alpha_echo.ttf",
            "amadeus.ttf", "amarillo.ttf", "amersn.ttf", "anudi.ttf", "aquilinetwo.ttf", "arbutus.ttf",
            "archivonarrow.otf", "archivovarrow_regular.otf", "barrio_regular.otf", "bearpaw.ttf",
            "bebasneue.ttf", "bigelowrules.ttf", "blackr.ttf", "boycott.ttf",
            "brushstp.ttf", "carnevalee_freakshow.ttf", "carobtn.TTF", "carousel.ttf",
            "caslon_calligraphic.ttf", "caviardreams.ttf", "cocogoose.ttf", "croissantone.ttf",
            "deftone_stylus.ttf", "diplomata.ttf", "dosis.ttf", "fontl.TTF", "hugtophia.ttf",
            "ice_age.ttf", "kingthings_calligraphica.ttf", "love_like_this.ttf", "made_canvas.otf",
            "merci_heart_brush.ttf", "metropolis.otf", "montserrat.otf", "montserratalternates.otf",
            "norwester.otf", "ostrich.ttf", "squealer.ttf", "titillium.otf", "ubuntu.ttf"};
    public static final String[] fontName = new String[]{"Abeezee", "Abrilfat Face", "Acknowledgement", "Acme", "After Shok", "Alexbrush", "Alfaslabone", "Alisandra", "Allura", "Almendra", "AlmendraaIsplay", "Alpha Echo", "Amadeus", "Amarillo", "Amersn", "Anudi", "AquilineTwo", "Arbutus", "Archivo Narrow.ttf", "Archivo Narrow Regular", "Barrio Regular", "Bearpaw", "Bebasneue", "Bigelow Rules", "Blackr", "Boycott", "Brushstp", "Carnevalee Freakshow", "Carobtn", "Carousel", "Caslon Calligraphic", "Caviar Dreams", "CocoGoose", "Croissan Tone", "DefTone Stylus", "Diplomata", "Ddosis", "Fontl", "Hugtophia", "Ice Age", "Kingthings Calligraphica", "Love Like This", "Made Canvas", "Merci Heart Brush", "Metropolis", "Montserrat", "Montserratalternates", "Norwester", "Ostrich", "Squealer", "Titillium", "Ubuntu"};

    public static String DOWNLOAD_SHARE_PATH = "DOWNLOAD_SHARE_PATH";
    public static boolean AllowToOpenAdvertise = false;
    public static final String privacypolicy = "privacypolicy";
    public static final String admob_banner_id = "admob_banner_id";
    public static final String admob_fullscreen_id = "admob_fullscreen_id";
    public static final String admob_nativex_id = "admob_nativex_id";
    public static final String facebook_banner_id = "facebook_banner_id";
    public static final String facebook_fullscreen_id = "facebook_fullscreen_id";
    public static String admob_banner = "";
    public static String admob_fullscreen = "";
    public static String admob_nativex = "";
    public static String facebook_banner = "";
    public static String facebook_fullscreen = "";
    public static String active_ads = "";


}
