package com.pngstatus.statusimagemaker.Utils;

public class BuildConfig {
    public static final boolean DEBUG = Boolean.parseBoolean("true");
    public static final String APPLICATION_ID = "com.pngstatus.statusimagemaker";
    public static final String BUILD_TYPE = "debug";
    public static final String FLAVOR = "";
    public static final int VERSION_CODE = 1;
    public static final String VERSION_NAME = "1.0";

    // Fields from product flavor: activity
    public static final int RequestMode = 1;
}
