package com.pngstatus.statusimagemaker.Adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.pngstatus.statusimagemaker.Fragment.HomeFragment;
import com.pngstatus.statusimagemaker.MainActivity;
import com.pngstatus.statusimagemaker.model.model_category_data;
import com.pngstatus.statusimagemaker.R;
import com.pngstatus.statusimagemaker.Utils.Constance;

import java.util.ArrayList;

public class AdapterCategory extends RecyclerView.Adapter<AdapterCategory.ItemViewHolder> {
    Context context;
    int resource;
    ArrayList<model_category_data> arrayList = new ArrayList<>();

    public AdapterCategory(Context context, ArrayList<model_category_data> data) {
        this.context = context;
        this.arrayList = data;
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.row_category_list, parent, false);
        ItemViewHolder vh = new ItemViewHolder(view, arrayList);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull final ItemViewHolder holder, final int position) {
        holder.set_data(position);
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class ItemViewHolder extends RecyclerView.ViewHolder {
        View itemView;
        ArrayList<model_category_data> data;
        TextView tv_name;
        ImageView iv_img;

        public ItemViewHolder(View itemView, ArrayList<model_category_data> data) {
            super(itemView);
            this.itemView = itemView;
            this.data = data;
            tv_name = itemView.findViewById(R.id.tv_name);
            iv_img = itemView.findViewById(R.id.iv_img);
        }

        public void set_data(final int position) {
            if (data.get(position).getName() != null) {
                tv_name.setText(data.get(position).getName());
            } else {
                tv_name.setText("");
            }
            if (data.get(position).getImage_url() != null) {
                Glide.with(context).load(data.get(position).getImage_url()).into(iv_img);
            }
//            Constance.catgry=true;
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Constance.frmCat=true;
                    moveFragment(new HomeFragment(), data.get(position).getId());
//                    ((FragmentActivity)context).getSupportFragmentManager().popBackStack();


/*
                    if (Constance.isFrstym){
                        Constance.isFrstym=false;
                        Constance.isBack=true;
                        moveFragment2(new HomeFragment(),data.get(position).getId());
                    }else {
                        if (Constance.isBack){
                            Constance.isBack=false;
//                            ((FragmentActivity)context).getSupportFragmentManager().popBackStack();
                            moveFragment2(new HomeFragment(),data.get(position).getId());
                            ((FragmentActivity)context).getSupportFragmentManager().popBackStack();
                        }
                    }*/
                }
            });
        }
    }

   /* public void moveFragment(Fragment fragment, String id) {
//        FragmentManager fm = ((Activity) context).getFragmentManager();
        FragmentManager fm = ((FragmentActivity) context).getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        Bundle args = new Bundle();
        args.putString(Constance.CatId, id);
        fragment.setArguments(args);
        fm.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
        ft.replace(R.id.main_frame, fragment, fragment.getClass().getSimpleName());
//        ft.replace(R.id.main_frame, fragment, fragment.getClass().getSimpleName()).addToBackStack(null);
        ft.commit();
    }
*/
    public void moveFragment(Fragment fragment, String id) {
//        FragmentManager fm = ((Activity) context).getFragmentManager();
        String backStateName = fragment.getClass().getName();
        FragmentManager fm = ((FragmentActivity) context).getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        boolean fragmentPopped = fm.popBackStackImmediate(backStateName, 0);
        Bundle args = new Bundle();
        args.putString(Constance.CatId, id);
        fragment.setArguments(args);
//        fm.popBackStack(fragment.getClass().getSimpleName(), FragmentManager.POP_BACK_STACK_INCLUSIVE);
//        ft.replace(R.id.main_frame, fragment, fragment.getClass().getSimpleName());
        ft.replace(R.id.main_frame, fragment, fragment.getClass().getSimpleName());
        if (!fragmentPopped) { //fragment not in back stack, create it.
            ft.addToBackStack(null);
            ft.commit();
        }
    }
}
