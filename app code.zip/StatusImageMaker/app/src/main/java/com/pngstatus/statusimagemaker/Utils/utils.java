package com.pngstatus.statusimagemaker.Utils;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;
import android.view.inputmethod.InputMethodManager;

import androidx.core.app.NotificationCompat;


import com.pngstatus.statusimagemaker.MainActivity;
import com.pngstatus.statusimagemaker.R;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class utils {

    public static String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    public static void printLog(String tag,String msg){
        Log.e(tag, msg );
    }

    public static boolean isConnectedToInternet(Context context) {
        if (context != null) {

            ConnectivityManager connectivity = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (connectivity != null) {
                NetworkInfo[] info = connectivity.getAllNetworkInfo();
                for (NetworkInfo networkInfo : info)
                    if (networkInfo.getState() == NetworkInfo.State.CONNECTED) {

                        return true;
                    }

            }
        }
        return false;
    }


    public static void Notificaionbuilder(Context context, String title, String Message) {

        NotificationManager notificationManager = (NotificationManager) context.getSystemService(context.NOTIFICATION_SERVICE);

        Intent repeating_intent = new Intent(context, MainActivity.class);
        repeating_intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, 100, repeating_intent, PendingIntent.FLAG_UPDATE_CURRENT);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context)
                .setContentIntent(pendingIntent)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(title)
                .setContentText(Message)
                .setAutoCancel(true);
        notificationManager.notify(100, builder.build());
    }
    public static void hideKeyboard(Context context) {
        InputMethodManager inputManager = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);

        inputManager.toggleSoftInput(InputMethodManager.HIDE_NOT_ALWAYS, 0);
    }
    public static boolean emailValidation(String email) {
        if (email.matches(emailPattern)) {
            return true;
        } else {
            return false;
        }
    }
    public static boolean mobilevalidation(String mbl){
        Pattern p = Pattern.compile("[6-9][0-9]{9}");

        Matcher m = p.matcher(mbl);
        return (m.find() && m.group().equals(mbl));
    }
}

