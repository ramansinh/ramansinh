package com.pngstatus.statusimagemaker.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.pngstatus.statusimagemaker.Fragment.HomeFragment;
import com.pngstatus.statusimagemaker.R;
import com.pngstatus.statusimagemaker.Utils.Constance;
import com.pngstatus.statusimagemaker.Utils.LocaleHelper;
import com.pngstatus.statusimagemaker.Utils.NumberFormatting;
import com.pngstatus.statusimagemaker.Utils.Popup_LogIn;
import com.pngstatus.statusimagemaker.Utils.Prefs;
import com.pngstatus.statusimagemaker.model.model_post_data;

import java.util.ArrayList;
import java.util.Calendar;

import static com.pngstatus.statusimagemaker.Fragment.HomeFragment.download_ShareImg;
import static com.pngstatus.statusimagemaker.Fragment.HomeFragment.fvrtimg;
import static com.pngstatus.statusimagemaker.Fragment.HomeFragment.total_share_download;


public class AdapterstatusList extends RecyclerView.Adapter<AdapterstatusList.ItemViewHolder> {
    Context context;
    int resource;
    ArrayList<model_post_data> arrayList = new ArrayList<>();

    public AdapterstatusList(Context context, ArrayList<model_post_data> data) {
        this.context = context;
        this.arrayList = data;
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.row_status_list, parent, false);
        ItemViewHolder vh = new ItemViewHolder(view, arrayList);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull final ItemViewHolder holder, final int position) {
        holder.set_data(position);
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class ItemViewHolder extends RecyclerView.ViewHolder {
        View itemView;
        ArrayList<model_post_data> data;
        //        TextView tv_name,tv_postcode,tv_cpmlited;
        TextView tv_view, tv_share, tv_dwnld, tv_edit;
        RelativeLayout rl_view_to_img;
        ImageView iv_main_back, iv_view, iv_txteffct_img, iv_fvrt, iv_fvrt_fill, iv_edit, iv_wp, iv_dwnld;

        public ItemViewHolder(View itemView, ArrayList<model_post_data> data) {
            super(itemView);
            this.itemView = itemView;
            this.data = data;
//            tv_name = itemView.findViewById(R.id.tv_name);
            rl_view_to_img = itemView.findViewById(R.id.rl_view_to_img);
            iv_main_back = itemView.findViewById(R.id.iv_main_back);
            iv_view = itemView.findViewById(R.id.iv_view);
            iv_txteffct_img = itemView.findViewById(R.id.iv_txteffct_img);
            iv_fvrt = itemView.findViewById(R.id.iv_fvrt);
            iv_fvrt_fill = itemView.findViewById(R.id.iv_fvrt_fill);
            iv_edit = itemView.findViewById(R.id.iv_edit);
            iv_wp = itemView.findViewById(R.id.iv_wp);
            iv_dwnld = itemView.findViewById(R.id.iv_dwnld);
            tv_view = itemView.findViewById(R.id.tv_view);
            tv_share = itemView.findViewById(R.id.tv_share);
            tv_dwnld = itemView.findViewById(R.id.tv_dwnld);
            tv_edit = itemView.findViewById(R.id.tv_edit);
            iv_txteffct_img.setVisibility(View.GONE);

        }

        public void set_data(final int position) {
            String typ = "";
//            boolean frvt = false;
            // referencing the image view from the item.xml file

            String applang = Prefs.getPrefString(context, Constance.select_app_lang, "en");
            LocaleHelper.setLocale(context, applang);
//            Glide.with(context).load(arrayList.get(position).getFrame_image_url()).into(iv_txteffct_img);
//            Glide.with(context).load(arrayList.get(position).getPreview_image_url()).thumbnail(R.drawable.loader).into(iv_main_back);
            Glide.with(context).load(arrayList.get(position).getPreview_image_url()).thumbnail(Glide.with(context).load(R.drawable.loader)).into(iv_main_back);

            // setting the image in the imageView

            if (arrayList.get(position).getIs_my_favorite().equals("1") && arrayList.get(position).getFavourite() != null) {
                iv_fvrt_fill.setVisibility(View.VISIBLE);
                iv_fvrt.setVisibility(View.GONE);
            } else {
                iv_fvrt_fill.setVisibility(View.GONE);
                iv_fvrt.setVisibility(View.VISIBLE);
            }

            boolean islogin = Prefs.getPrefBoolean(context, Constance.islogin, false);

            if (arrayList.get(position).getView_count() != null) {
                tv_view.setText(NumberFormatting.CountFormat(arrayList.get(position).getView_count()));
            }
            if (arrayList.get(position).getShare_count() != null) {
                tv_share.setText(NumberFormatting.CountFormat(arrayList.get(position).getShare_count()));
            }
            if (arrayList.get(position).getDownload_count() != null) {
                tv_dwnld.setText(NumberFormatting.CountFormat(arrayList.get(position).getDownload_count()));
            }
            if (arrayList.get(position).getEdit_count() != null) {
                tv_edit.setText(NumberFormatting.CountFormat(arrayList.get(position).getEdit_count()));
            }
            iv_main_back.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    if (islogin) {
                        Animation zoomoin = AnimationUtils.loadAnimation(context, R.anim.blink);
                        iv_edit.startAnimation(zoomoin);
                        String filename = String.valueOf(Calendar.getInstance().getTimeInMillis());
                        total_share_download(arrayList, position, "edit", tv_edit, arrayList.get(position).getEdit_count());
                    } else {
                        Popup_LogIn popupLogIn = new Popup_LogIn();
                        popupLogIn.Popup_LogIn(context);
                    }
                }
            });

            iv_edit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (islogin) {
                        Animation zoomoin = AnimationUtils.loadAnimation(context, R.anim.blink);
                        iv_edit.startAnimation(zoomoin);
                        String filename = String.valueOf(Calendar.getInstance().getTimeInMillis());
                        total_share_download(arrayList, position, "edit", tv_edit, arrayList.get(position).getEdit_count());
                    } else {
                        Popup_LogIn popupLogIn = new Popup_LogIn();
                        popupLogIn.Popup_LogIn(context);
                    }
                }
            });
            iv_dwnld.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
//                    iv_dwnld.startAnimation(zoom);
                    Animation zoomoin = AnimationUtils.loadAnimation(context, R.anim.blink);
                    iv_dwnld.startAnimation(zoomoin);
                    String filename = String.valueOf(Calendar.getInstance().getTimeInMillis());
                    if (HomeFragment.saveImage(rl_view_to_img, filename)) {
                        total_share_download(arrayList, position, "download", tv_dwnld, arrayList.get(position).getDownload_count());
                    }
                }
            });

            iv_wp.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Animation zoomoin = AnimationUtils.loadAnimation(context, R.anim.blink);
                    iv_wp.startAnimation(zoomoin);
                    String filename = String.valueOf(Calendar.getInstance().getTimeInMillis());
                    if (download_ShareImg(rl_view_to_img, filename)) {
                        total_share_download(arrayList, position, "share", tv_share, arrayList.get(position).getShare_count());
                    }
                }
            });

            if (!arrayList.get(position).isView()) {
                Animation zoomoin = AnimationUtils.loadAnimation(context, R.anim.blink);
                iv_view.startAnimation(zoomoin);
                total_share_download(arrayList, position, "view", tv_view, arrayList.get(position).getView_count());
                arrayList.get(position).setView(true);
//                notifyDataSetChanged();
            }

            iv_fvrt.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (islogin) {
                        Animation fadeout = AnimationUtils.loadAnimation(context, R.anim.fade_out);
                        iv_fvrt.startAnimation(fadeout);
                        HomeFragment.fvrtimg(arrayList.get(position).getId(), true, iv_fvrt, iv_fvrt_fill);
                    } else {
                        Popup_LogIn popupLogIn = new Popup_LogIn();
                        popupLogIn.Popup_LogIn(context);
                    }
                }
            });

            iv_fvrt_fill.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (islogin) {
                        Animation fadeout = AnimationUtils.loadAnimation(context, R.anim.fade_out);
                        iv_fvrt_fill.startAnimation(fadeout);
                        fvrtimg(arrayList.get(position).getId(), false, iv_fvrt, iv_fvrt_fill);
                    } else {
                        Popup_LogIn popupLogIn = new Popup_LogIn();
                        popupLogIn.Popup_LogIn(context);
                    }

                }
            });
        }
    }

}
