package com.pngstatus.statusimagemaker.Adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.pngstatus.statusimagemaker.Utils.Constance;
import com.pngstatus.statusimagemaker.Utils.LocaleHelper;
import com.pngstatus.statusimagemaker.Utils.Prefs;
import com.pngstatus.statusimagemaker.model.model_post_data;
import com.pngstatus.statusimagemaker.R;
import com.pngstatus.statusimagemaker.Utils.OnItemClickListener;

import java.util.ArrayList;


public class AdapterImgTextChng extends RecyclerView.Adapter<AdapterImgTextChng.ItemViewHolder> {
    Context context;
    int resource;
    ArrayList<model_post_data> arrayList = new ArrayList<>();
    OnItemClickListener onClick;

    public AdapterImgTextChng(Context context, ArrayList<model_post_data> data,OnItemClickListener onClick) {
        this.context = context;
        this.arrayList = data;
        this.onClick = onClick;
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.row_back_n_text_img_list, parent, false);
        ItemViewHolder vh = new ItemViewHolder(view, arrayList);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull final ItemViewHolder holder, final int position) {
        holder.set_data(position);
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class ItemViewHolder extends RecyclerView.ViewHolder {
        View itemView;
        ArrayList<model_post_data> data;
        ImageView iv_main_back,iv_txteffct_img;
//        TextView tv_name,tv_postcode,tv_cpmlited;

        public ItemViewHolder(View itemView, ArrayList<model_post_data> data) {
            super(itemView);
            this.itemView = itemView;
            this.data = data;
            iv_main_back = itemView.findViewById(R.id.iv_main_back);
            iv_txteffct_img = itemView.findViewById(R.id.iv_main_back);
        }

        public void set_data(final int position) {
            String applang = Prefs.getPrefString(context, Constance.select_app_lang, "en");
            LocaleHelper.setLocale(context,applang);
            if (arrayList.get(position).getPreview_image_url() !=null){
//                Glide.with(context).load(arrayList.get(position).getPreview_image_url()).placeholder(R.drawable.loader).into(iv_main_back);
                Glide.with(context).load(arrayList.get(position).getPreview_image_url()).thumbnail(Glide.with((Activity)context).load(R.drawable.loader)).into(iv_main_back);
            }

//            iv_txteffct_img.setVisibility(View.VISIBLE);
          /*  if (arrayList.get(position).getFrame_image_url() !=null){
                Glide.with(context).load(arrayList.get(position).getFrame_image_url()).into(iv_txteffct_img);
            }*/
//            onClick.onItemClick(itemView,position);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    onClick.onItemClick(view,position);
                }
            });



        }
    }


}
