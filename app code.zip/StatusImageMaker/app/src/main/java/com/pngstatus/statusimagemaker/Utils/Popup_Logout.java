package com.pngstatus.statusimagemaker.Utils;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Point;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.pngstatus.statusimagemaker.MainActivity;
import com.pngstatus.statusimagemaker.R;


public class Popup_Logout {
    Context context;
   PopupWindow popup=new PopupWindow();
    WindowManager.LayoutParams params = null;
    public void Popup_Logout(Context mcontext) {
        context=mcontext;
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        int width = size.x;
        int height = size.y;
        if (!popup.isShowing()) {
            final LayoutInflater inflaterpopup = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
            final View view1 = inflaterpopup.inflate(R.layout.popup_logout, null);
            popup = new PopupWindow(view1, params.MATCH_PARENT, params.MATCH_PARENT);
            popup.setFocusable(true);
            TextView tv_no=view1.findViewById(R.id.tv_no);
            TextView tv_yes=view1.findViewById(R.id.tv_yes);
            tv_no.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    popup.dismiss();
                }
            });
            tv_yes.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Prefs.Logout(context);
                    popup.dismiss();
               /*     Intent intent = new Intent(context, MainActivity.class);
                    context.startActivity(intent);
                    ((Activity)context).finishAffinity();*/
                }
            });
            popup.setOutsideTouchable(true);
//                          popup.showAtLocation(view1, Gravity.TOP, width, height);
            popup.showAtLocation(view1, Gravity.BOTTOM, 0, 0);
        } else {
            popup.dismiss();
        }
    }


}
