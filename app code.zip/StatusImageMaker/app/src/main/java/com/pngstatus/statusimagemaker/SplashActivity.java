package com.pngstatus.statusimagemaker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;

import com.pngstatus.statusimagemaker.Activity.LoginActivity;
import com.pngstatus.statusimagemaker.Utils.Constance;
import com.pngstatus.statusimagemaker.Utils.Prefs;

public class SplashActivity extends AppCompatActivity {
    Context context;
    private static int SPLASH_TIME_OUT = 3000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        context=SplashActivity.this;
        if (Build.VERSION.SDK_INT < 16) {
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                    WindowManager.LayoutParams.FLAG_FULLSCREEN);
        } else {
            View decorView = getWindow().getDecorView();
            // Hide Status Bar.
            int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
            decorView.setSystemUiVisibility(uiOptions);
        }
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                boolean islogin= Prefs.getPrefBoolean(context, Constance.islogin,false);
                Intent i = new Intent(context, MainActivity.class);
                startActivity(i);
                finish();
               /* if (islogin){
                    Log.e("token","login token : "+ Prefs.getPrefString(context, Constance.api_token,""));

                    Intent i = new Intent(context, MainActivity.class);
                    startActivity(i);
                    finish();
                }else {
                    Intent i = new Intent(context, LoginActivity.class);
                    startActivity(i);
                    finish();
                }*/
            }
        }, SPLASH_TIME_OUT);
    }
}
