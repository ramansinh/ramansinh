package com.pngstatus.statusimagemaker.Utils;

import android.view.View;
import android.widget.AdapterView;

public interface OnItemClickListener extends AdapterView.OnItemClickListener {
    void onItemClick(View item, int position);
}
