package com.pngstatus.statusimagemaker.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class Response_policy {
    @SerializedName("result")
    private String result;
    @SerializedName("message")
    private String message;
    @SerializedName("records")
    private ArrayList<Model_policy> records;

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public ArrayList<Model_policy> getRecords() {
        return records;
    }

    public void setRecords(ArrayList<Model_policy> records) {
        this.records = records;
    }
}
