package com.pngstatus.statusimagemaker.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.facebook.ads.Ad;
import com.facebook.ads.InterstitialAdListener;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.pngstatus.statusimagemaker.Adapter.AdapterDownloadImg;
import com.pngstatus.statusimagemaker.MainActivity;
import com.pngstatus.statusimagemaker.R;
import com.pngstatus.statusimagemaker.Retrofit.RetrofitClient;
import com.pngstatus.statusimagemaker.Retrofit.RetrofitInterface;
import com.pngstatus.statusimagemaker.Utils.Constance;
import com.pngstatus.statusimagemaker.Utils.Popup_success;
import com.pngstatus.statusimagemaker.Utils.Prefs;
import com.pngstatus.statusimagemaker.model.Model_active_ad;
import com.pngstatus.statusimagemaker.model.Response_active_ad;
import com.pngstatus.statusimagemaker.model.mode_file_list;

import java.io.File;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DownloadImgActivity extends AppCompatActivity {
    Context context;
    Activity activity;
    public MainActivity instance;
    String[] permissionsRequired = {Manifest.permission.CAMERA,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_EXTERNAL_STORAGE};
    private final int PERMISSION_CALLBACK_CONSTANT = 200;
    @BindView(R.id.logo)
    public ImageView logo;
    @BindView(R.id.ivBack)
    public ImageView ivBack;
    @BindView(R.id.tvTitle)
    public TextView tvTitle;
    @BindView(R.id.loader)
    ProgressBar loader;
    @BindView(R.id.rv_list)
    RecyclerView rv_list;
    @BindView(R.id.ll_adView)
    public LinearLayout ll_adView;
    public  com.facebook.ads.AdView fadView;
    public Timer timer;
    public TimerTask hourlyTask;
    public InterstitialAd googleFullscreen;
    public  com.facebook.ads.InterstitialAd fbFullscreen;
    Model_active_ad model;

    AdapterDownloadImg adapterDownloadImg;
    ArrayList<mode_file_list> arrayList = new ArrayList<mode_file_list>();
    File storageDir;
    TextView tv_nodata;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_download_img);
        context = DownloadImgActivity.this;
        activity = DownloadImgActivity.this;
        tv_nodata=findViewById(R.id.tv_nodata);
        ButterKnife.bind(this);
        instance = MainActivity.getInstance();
        checkPermission();

        handlerStart();
        active_ad();

        instance.show_fullScreen_Ad();
        logo.setVisibility(View.GONE);
        ivBack.setVisibility(View.VISIBLE);
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        arrayList.clear();
        GridLayoutManager gm = new GridLayoutManager(context, 2);
        rv_list.setLayoutManager(gm);
//        count_download();
    }
    private void count_download(){
        storageDir =new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)+ "/pngStatus/");
        if (storageDir.exists()) {
            Log.e("tag", "exitst file path" + storageDir.getAbsolutePath());
            arrayList.clear();
            getfile(storageDir);
        }else {
            Popup_success popup_success=new Popup_success();
            popup_success.Popup_success(context,context.getResources().getString(R.string.dirctry_not_found));
        }
    }
    public void getfile(File dir) {
//    public ArrayList<File> getfile(File dir) {
        File listFile[] = dir.listFiles();
//        Log.e("tag", "size of dir : " + listFile.length);

        if (listFile != null && listFile.length > 0) {
            for (int i = 0; i < listFile.length; i++) {

                if (listFile[i].isDirectory()) {
                    getfile(listFile[i]);
                } else {
                    if (listFile[i].getName().endsWith(".png")) {
                        arrayList.add(new mode_file_list(listFile[i], listFile[i].getName()));
                    }
                }
            }
        }

        if (arrayList.size()>0) {
            tv_nodata.setVisibility(View.GONE);
            rv_list.setVisibility(View.VISIBLE);
            adapterDownloadImg = new AdapterDownloadImg(context, arrayList);
            rv_list.setAdapter(adapterDownloadImg);
        }else {
            tv_nodata.setVisibility(View.VISIBLE);
            rv_list.setVisibility(View.GONE);
        }
//        return fileList;
    }
    public void checkPermission() {
        if (ActivityCompat.checkSelfPermission(context, permissionsRequired[0]) != PackageManager.PERMISSION_GRANTED
                || ActivityCompat.checkSelfPermission(context, permissionsRequired[1]) != PackageManager.PERMISSION_GRANTED
                || ActivityCompat.checkSelfPermission(context, permissionsRequired[2]) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale((Activity) context, permissionsRequired[0])
                    || ActivityCompat.shouldShowRequestPermissionRationale((Activity) context, permissionsRequired[1])
                    || ActivityCompat.shouldShowRequestPermissionRationale((Activity) context, permissionsRequired[2])) {
                //Show Information about why you need the permission
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setTitle(getResources().getString(R.string.need_multiple_prmisn));
                builder.setMessage(getResources().getString(R.string.app_need_multiple_prmisn));
                builder.setPositiveButton(getResources().getString(R.string.grant), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                        ActivityCompat.requestPermissions((Activity) context, permissionsRequired, PERMISSION_CALLBACK_CONSTANT);
                    }
                });
                builder.setNegativeButton(getResources().getString(R.string.cancel), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
//                        onBackPressed();
                    }
                });
                builder.show();
            } else {
                //just request the permission
                ActivityCompat.requestPermissions((Activity) context, permissionsRequired, PERMISSION_CALLBACK_CONSTANT);
            }
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case 200: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0 &&
                        grantResults[0] == PackageManager.PERMISSION_GRANTED &&
                        grantResults[1] == PackageManager.PERMISSION_GRANTED &&
                        grantResults[2] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.
                } else {
                    checkPermission();
//                    onBackPressed();
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        count_download();
    }
    public void facebookAd(String adId) {
        if (adId.equals("")){
            adId="IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID";
        }
        ll_adView.removeAllViews();
        fadView = new com.facebook.ads.AdView(this, adId, com.facebook.ads.AdSize.BANNER_HEIGHT_50);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        fadView.setLayoutParams(lp);
        ll_adView.addView(fadView);
        fadView.loadAd();
    }

    public void googleBannerAd(String unitId) {
        ll_adView.removeAllViews();
        AdView adView = new AdView(context);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        adView.setLayoutParams(lp);
        adView.setAdSize(AdSize.BANNER);
        adView.setAdUnitId(unitId);
        ll_adView.addView(adView);
        AdRequest adRequest = new AdRequest.Builder().build();
//        List<String> testDeviceIds = Arrays.asList("33BE2250B43518CCDA7DE426D04EE231");
      /*  RequestConfiguration configuration =
                new RequestConfiguration.Builder().setTestDeviceIds(testDeviceIds).build();
        MobileAds.setRequestConfiguration(configuration);*/

        adView.loadAd(adRequest);
        adView.setAdListener(new AdListener() {
            @Override
            public void onAdClosed() {
                super.onAdClosed();
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                super.onAdFailedToLoad(loadAdError);
            }

            @Override
            public void onAdOpened() {
                super.onAdOpened();
            }

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
            }

            @Override
            public void onAdClicked() {
                super.onAdClicked();
            }

            @Override
            public void onAdImpression() {
                super.onAdImpression();
            }
        });

    }

    public void googleInterstitialAd(String adId) {
//        String  adId = Constance.admob_fullscreen;
        if (adId.equals("")) {
            adId = "ca-app-pub-3940256099942544/1033173712";
        }
        AdRequest adRequest = new AdRequest.Builder().build();

        InterstitialAd.load(context, adId, adRequest, new InterstitialAdLoadCallback() {
            @Override
            public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                super.onAdLoaded(interstitialAd);
                // The mInterstitialAd reference will be null until
                // an ad is loaded.
                googleFullscreen = interstitialAd;
//                if (Constance.isFirstTimeOpen) {
                show_fullScreen_Ad();
//                }
                Log.i("TAG", "onAdLoaded");
                googleFullscreen.setFullScreenContentCallback(new FullScreenContentCallback() {
                    @Override
                    public void onAdDismissedFullScreenContent() {
                        // Called when fullscreen content is dismissed.
                        Log.d("TAG", "The ad was dismissed.");
                        Constance.AllowToOpenAdvertise = false;
                        googleFullscreen = null;
                        handlerStart();
                     /*   stopTask();
                        startTimer();*/
                        googleInterstitialAd(Constance.admob_fullscreen);
                    }

                    @Override
                    public void onAdFailedToShowFullScreenContent(AdError adError) {
                        // Called when fullscreen content failed to show.
                        Log.d("TAG", "The ad failed to show.");
                        googleFullscreen = null;
//                        Constance.AllowToOpenAdvertise = false;
//                        stopTask();
//                        startTimer();

//                        googleInterstitialAd();
                    }

                    @Override
                    public void onAdShowedFullScreenContent() {
                        // Called when fullscreen content is shown.
                        // Make sure to set your reference to null so you don't
                        // show it a second time.
//                        mInterstitialAd = null;
                        Log.d("TAG", "The ad was shown.");
//                        Constance.AllowToOpenAdvertise = false;
//                        stopTask();
//                        startTimer();
//                        handlerStart();
//                        googleInterstitialAd();
                    }
                });
               /* if (Constance.isFirstTimeOpen){
                    googleFullscreen.show(activity);
                    Constance.isFirstTimeOpen=false;
                }*/
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                super.onAdFailedToLoad(loadAdError);
                // Handle the error
                Log.i("TAG", loadAdError.getMessage());
//                Constance.AllowToOpenAdvertise = false;
//                googleFullscreen = null;
//                stopTask();
//                startTimer();
//                handlerStart();
//                googleInterstitialAd();
            }
        });
    }

    public void fbInterstitialAd() {
        String adId = Constance.facebook_fullscreen;
        fbFullscreen = new com.facebook.ads.InterstitialAd(this, adId);
        InterstitialAdListener fblistener = new InterstitialAdListener() {
            @Override
            public void onInterstitialDisplayed(Ad ad) {
//                stopTask();
//                startTimer();
            }

            @Override
            public void onInterstitialDismissed(Ad ad) {
//                stopTask();
//                startTimer();
                Constance.AllowToOpenAdvertise = false;
                handlerStart();
                fbInterstitialAd();
            }

            @Override
            public void onError(Ad ad, com.facebook.ads.AdError adError) {
//                stopTask();
//                startTimer();
            }

            @Override
            public void onAdLoaded(Ad ad) {
                fbFullscreen.show();
            }

            @Override
            public void onAdClicked(Ad ad) {
//                stopTask();
//                startTimer();
//                fbInterstitialAd();
            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        };
        fbFullscreen.loadAd(fbFullscreen.buildLoadAdConfig()
                .withAdListener(fblistener)
                .build());
    }

    public void active_ad() {

        String token = Prefs.getPrefString(context, Constance.api_token, "");
        RetrofitInterface retrofitInterface = RetrofitClient.getClient().create(RetrofitInterface.class);
        Call<Response_active_ad> call = retrofitInterface.active_ad(token);
        call.enqueue(new Callback<Response_active_ad>() {
            @Override
            public void onResponse(Call<Response_active_ad> call, Response<Response_active_ad> response) {
                if (response != null && response.body() != null) {
                    if (response.body().getResult() != null && response.body().getResult().equals("1")) {
//                        response.body().getRecords().get(0).setAdmob_banner_id("ca-app-pub-3940256099942544/6300978111");
                        if (response.body().getRecords() != null && response.body().getRecords().size() > 0) {
                            if (response.body().getRecords().get(0) != null) {
                                model = response.body().getRecords().get(0);
//                        model=new Model_active_ad("ca-app-pub-3940256099942544/6300978111");
//                        binding.adView.setAdUnitId("ca-app-pub-3940256099942544/6300978111");
                                if (response.body().getRecords().get(0).getActive_ads() != null) {
                                    Constance.active_ads = response.body().getRecords().get(0).getActive_ads();
                                    /*if ( Constance.active_ads .equals("admob_ad")){
                                        googleBannerAd(model.getAdmob_banner_id());
                                    }else {
                                    }*/
                                }
                                if (response.body().getRecords().get(0).getAdmob_banner_id() != null) {
                                    Constance.admob_banner = response.body().getRecords().get(0).getAdmob_banner_id();
                                    if (Constance.active_ads.equals("admob_ad")) {
                                        googleBannerAd(model.getAdmob_banner_id());
                                    }
                                }
                                if (response.body().getRecords().get(0).getAdmob_fullscreen_id() != null) {
                                    Constance.admob_fullscreen = response.body().getRecords().get(0).getAdmob_fullscreen_id();
                                    googleInterstitialAd( Constance.admob_fullscreen);
                                    if (Constance.active_ads.equals("admob_ad")) {
                                        googleInterstitialAd(Constance.admob_fullscreen);
                                    }
                                }
                                if (response.body().getRecords().get(0).getAdmob_nativex_id() != null) {
                                    Constance.admob_nativex = response.body().getRecords().get(0).getAdmob_nativex_id();
                                }

                                if (response.body().getRecords().get(0).getFacebook_banner_id() != null) {
                                    Constance.facebook_banner = response.body().getRecords().get(0).getFacebook_banner_id();
                                    if (!Constance.active_ads.equals("admob_ad")) {
                                        facebookAd(Constance.facebook_banner);
                                    }
                                }
                                if (response.body().getRecords().get(0).getFacebook_fullscreen_id() != null) {
                                    Constance.facebook_fullscreen = response.body().getRecords().get(0).getFacebook_fullscreen_id();
                                    fbInterstitialAd();
                                }

                                show_fullScreen_Ad();
                            }
                        }
//                        binding.setModel(model);
//                        binding.adView.setAdSize(AdSize.BANNER);
//                        binding.adView.setAdUnitId("ca-app-pub-3940256099942544/6300978111");
//                        String unitid=binding.adView.getAdUnitId();
//                        AdRequest adRequest = new AdRequest.Builder().build();
//                        binding.adView.loadAd(adRequest);
                    }
                }
            }

            @Override
            public void onFailure(Call<Response_active_ad> call, Throwable t) {
//                Toast.makeText(context, t.getMessage(), Toast.LENGTH_SHORT).show();
                Log.e("response", "reset passwrd :" + t.getMessage());
            }
        });
    }

    public void handlerStart() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
//                displayAdMob();
                Constance.AllowToOpenAdvertise = true;
                Log.d("kkksxsdsdshds", "handler" + Constance.AllowToOpenAdvertise);
            }
        }, 1000 * 40);
    }

    public void show_fullScreen_Ad() {
        if (Constance.AllowToOpenAdvertise) {
            if (Constance.active_ads.equals("admob_ad")) {
                if (googleFullscreen != null) {
                    googleFullscreen.show(this);
                } else {
//                    Toast.makeText(context, "Ad did not load", Toast.LENGTH_SHORT).show();
//                    googleInterstitialAd();
//            startGame();
                }
            } else {
                if (fbFullscreen != null && fbFullscreen.isAdLoaded()) {
                    fbFullscreen.show();
                }
            }
        } else {

        }
    }

}