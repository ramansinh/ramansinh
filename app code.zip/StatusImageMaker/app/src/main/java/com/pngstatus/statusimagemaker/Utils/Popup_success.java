package com.pngstatus.statusimagemaker.Utils;

import android.content.Context;
import android.graphics.Point;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.pngstatus.statusimagemaker.R;


public class Popup_success {
    Context context;
   PopupWindow popup=new PopupWindow();
    WindowManager.LayoutParams params = null;
    public void Popup_success(Context mcontext,String msg) {
        context=mcontext;
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        int width = size.x;
        int height = size.y;
        if (!popup.isShowing()) {
            final LayoutInflater inflaterpopup = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
            final View view1 = inflaterpopup.inflate(R.layout.popup_success, null);
            popup = new PopupWindow(view1, params.MATCH_PARENT, params.MATCH_PARENT);
            popup.setFocusable(true);
            TextView tv_msg=view1.findViewById(R.id.tv_msg);
            TextView tv_close=view1.findViewById(R.id.tv_close);

            tv_msg.setText(msg);
            tv_close.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    popup.dismiss();
//                    ((Activity)context).onBackPressed();
                }
            });

            popup.setOutsideTouchable(true);
//                          popup.showAtLocation(view1, Gravity.TOP, width, height);
            popup.showAtLocation(view1, Gravity.BOTTOM, 0, 0);
        } else {
            popup.dismiss();
        }
    }
}
