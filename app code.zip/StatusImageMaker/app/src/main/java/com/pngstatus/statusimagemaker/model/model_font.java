package com.pngstatus.statusimagemaker.model;

import com.google.gson.annotations.SerializedName;

public class model_font {
    @SerializedName("font")
    private String font;

    @SerializedName("name")
    private String name;

    public model_font(String font, String name) {
        this.font = font;
        this.name = name;
    }

    public String getFont() {
        return font;
    }

    public void setFont(String font) {
        this.font = font;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
