package com.pngstatus.statusimagemaker.model;

import com.google.gson.annotations.SerializedName;

public class Response_login {
    @SerializedName("result")
    private String result;
    @SerializedName("message")
    private String message;
    @SerializedName("api_token")
    private String api_token;
    @SerializedName("record")
    private model_login record;
    @SerializedName("user_action_list")
    private model_user_action_list model_user_action_list;

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getApi_token() {
        return api_token;
    }

    public void setApi_token(String api_token) {
        this.api_token = api_token;
    }

    public model_login getRecord() {
        return record;
    }

    public void setRecord(model_login record) {
        this.record = record;
    }

    public model_user_action_list getUser_action_list() {
        return model_user_action_list;
    }

    public void setUser_action_list(model_user_action_list model_user_action_list) {
        this.model_user_action_list = model_user_action_list;
    }
}
