package com.pngstatus.statusimagemaker.Fragment;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.pngstatus.statusimagemaker.Activity.CustomEditorActivity;
import com.pngstatus.statusimagemaker.Adapter.AdapterCategory;
import com.pngstatus.statusimagemaker.MainActivity;
import com.pngstatus.statusimagemaker.Utils.LocaleHelper;
import com.pngstatus.statusimagemaker.model.Response_category;
import com.pngstatus.statusimagemaker.model.model_category;
import com.pngstatus.statusimagemaker.model.model_category_data;
import com.pngstatus.statusimagemaker.R;
import com.pngstatus.statusimagemaker.Retrofit.RetrofitClient;
import com.pngstatus.statusimagemaker.Retrofit.RetrofitInterface;
import com.pngstatus.statusimagemaker.Utils.Constance;
import com.pngstatus.statusimagemaker.Utils.EndlessRecyclerOnScrollListener;
import com.pngstatus.statusimagemaker.Utils.Prefs;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * A simple {@link Fragment} subclass.
 */
public class CategoryFragment extends Fragment {

    Context context;
    Activity activity;
    public MainActivity instance;
    private Unbinder unbinder;
    @BindView(R.id.loader)
    ProgressBar loader;
    @BindView(R.id.rv_list)
    RecyclerView rv_list;

    model_category model;
    ArrayList<model_category_data> arrayList = new ArrayList<>();
    AdapterCategory adapterCategory;

    public CategoryFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_category, container, false);
        context = getActivity();
        activity = getActivity();
        unbinder = ButterKnife.bind(this, view);
        instance = MainActivity.getInstance();

        instance.ivPhotos.setSelected(false);
        instance.tvPhotos.setSelected(false);
        instance.ivCatgry.setSelected(true);
        instance.tvCatgry.setSelected(true);
        instance.ivFvrt.setSelected(false);
        instance.tvFvrt.setSelected(false);
        instance.ivProfile.setSelected(false);
        instance.tvProfile.setSelected(false);

        instance.ivCatgry.setEnabled(false);
        instance.ivPhotos.setEnabled(true);
        instance.ivProfile.setEnabled(true);
        instance.ivFvrt.setEnabled(true);

        instance.show_fullScreen_Ad();
        String applang = Prefs.getPrefString(context, Constance.select_app_lang, "en");
        LocaleHelper.setLocale(context,applang);
        GridLayoutManager gm = new GridLayoutManager(context, 3);
        rv_list.setLayoutManager(gm);

        rv_list.addOnScrollListener(new EndlessRecyclerOnScrollListener(gm) {
            @Override
            public void onLoadMore(int page, int totalItemsCount, RecyclerView view) {
                if (model != null && model.getNext_page_url() != null) {
                    loadNextDataFromApi();
                }
            }
        });

      /*  instance.ivPhotos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setHomeFragment();
            }
        });

        instance.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, CustomEditorActivity.class);
                startActivity(intent);
            }
        });

        instance.ivProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                moveFragment(new ProfileFragment());
            }
        });
        instance.ivFvrt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                moveFragment(new FavouriteFragment());
            }
        });*/
        getCategory();
        return view;
    }

    private void getCategory() {
        loader.setVisibility(View.VISIBLE);
        String token = Prefs.getPrefString(context, Constance.api_token, "");

        RetrofitInterface retrofitInterface = RetrofitClient.getClient().create(RetrofitInterface.class);
        Call<Response_category> call = retrofitInterface.category_list(token);
        call.enqueue(new Callback<Response_category>() {
            @Override
            public void onResponse(Call<Response_category> call, Response<Response_category> response) {
                if (response != null && response.body() != null) {

                    if (response.body().getResult() != null && response.body().getResult().equals("1")) {
                        if (response.body().getRecords() != null) {
                            if (response.body().getRecords().getData()!=null &&
                                    response.body().getRecords().getData().size()>0){
                                arrayList.clear();
                                arrayList.addAll(response.body().getRecords().getData());
                                adapterCategory=new AdapterCategory(context,arrayList);
                                rv_list.setAdapter(adapterCategory);
                                loader.setVisibility(View.GONE);
                            }else {
                                loader.setVisibility(View.GONE);
                                Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                            }
                            loader.setVisibility(View.GONE);
                        } else {
                            loader.setVisibility(View.GONE);
                            Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                        loader.setVisibility(View.GONE);
                    } else {
                        loader.setVisibility(View.GONE);
                        Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                    loader.setVisibility(View.GONE);
                } else {
                    loader.setVisibility(View.GONE);
                    Toast.makeText(context, response.message(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Response_category> call, Throwable t) {
                loader.setVisibility(View.GONE);
                Toast.makeText(context, t.getMessage(), Toast.LENGTH_SHORT).show();
                Log.e("response", "login :" + t.getMessage());
            }
        });
    }

    public void loadNextDataFromApi() {
        loader.setVisibility(View.VISIBLE);
        String token = Prefs.getPrefString(context, Constance.api_token, "");

        StringRequest stringRequest = new StringRequest(Request.Method.POST, model.getNext_page_url(), new com.android.volley.Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if (jsonObject.getString("result").equals("1")) {
                        JSONObject jsonPostObject = jsonObject.getJSONObject("records");
                        Gson gson = new Gson();
                        Type type = new TypeToken<model_category>() {
                        }.getType();

                        model = gson.fromJson(jsonPostObject.toString(), type);

                       /* JSONArray jsonArray = jsonPostObject.getJSONArray("data");
                        Type typeForPostArray = new TypeToken<List<model_receive_message>>() {
                        }.getType();
                        List<model_receive_message_data> list = gson.fromJson(jsonArray.toString(), typeForPostArray);
                       */

                        ArrayList<model_category_data> list = model.getData();


                        if (list!=null && list.size() != 0) {
                            arrayList.addAll(list);
                            adapterCategory.notifyDataSetChanged();
                            loader.setVisibility(View.GONE);
                        } else {
                            loader.setVisibility(View.GONE);
                        }
                        loader.setVisibility(View.GONE);
                    } else {
//                        AlertDialogBox.AlertMessage(context, jsonObject.getString("message"));
                        loader.setVisibility(View.GONE);
                    }
                    loader.setVisibility(View.GONE);
                } catch (JSONException e) {
                    e.printStackTrace();
                    loader.setVisibility(View.GONE);
                }
            }
        }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
//                Toast.makeText(context, "Please Check Your Internet Connection", Toast.LENGTH_SHORT).show();
                loader.setVisibility(View.GONE);
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
//                params.put("token",Prefs.getPrefString(context,Constance.auth_token,""));
                params.put("api_token", token);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(context);
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(60000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(stringRequest);
    }

    public void setHomeFragment() {
        Fragment fragment = new HomeFragment();
        FragmentManager fm = ((FragmentActivity)context).getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();

        fm.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
        ft.replace(R.id.main_frame, fragment, fragment.getClass().getSimpleName());
        ft.commit();
    }

    public void moveFragment(Fragment fragment) {

//        FragmentManager fm = ((Activity) context).getFragmentManager();
        FragmentManager fm = ((FragmentActivity)context).getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
       /* Bundle args = new Bundle();
        args.putString(Constance.CatId, id);
        fragment.setArguments(args);*/
//        fm.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
//        ft.replace(R.id.main_frame, fragment, fragment.getClass().getSimpleName());
        ft.replace(R.id.main_frame, fragment, fragment.getClass().getSimpleName()).addToBackStack(null);
        ft.commit();
    }

    @Override
    public void onResume() {
        super.onResume();
        instance = MainActivity.getInstance();

        instance.ivPhotos.setSelected(false);
        instance.tvPhotos.setSelected(false);
        instance.ivCatgry.setSelected(true);
        instance.tvCatgry.setSelected(true);
        instance.ivFvrt.setSelected(false);
        instance.tvFvrt.setSelected(false);
        instance.ivProfile.setSelected(false);
        instance.tvProfile.setSelected(false);

        instance.ivCatgry.setEnabled(false);
        instance.ivPhotos.setEnabled(true);
        instance.ivProfile.setEnabled(true);
        instance.ivFvrt.setEnabled(true);
    }
}
