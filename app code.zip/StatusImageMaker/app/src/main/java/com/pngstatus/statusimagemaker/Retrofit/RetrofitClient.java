package com.pngstatus.statusimagemaker.Retrofit;


import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.IOException;
import java.security.cert.CertificateException;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitClient {

    public static final String BASE_URL = "http://demo.api.com/";

    private static Retrofit retrofit = null;
    public static OkHttpClient.Builder getUnsafeOkHttpClient() {
        try {
            // Create a trust manager that does not validate certificate chains
            final TrustManager[] trustAllCerts = new TrustManager[]{

                    new X509TrustManager() {
                        @Override
                        public void checkClientTrusted(java.security.cert.X509Certificate[] chain, String authType) throws CertificateException {
                        }

                        @Override
                        public void checkServerTrusted(java.security.cert.X509Certificate[] chain, String authType) throws CertificateException {
                        }

                        @Override
                        public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                            return new java.security.cert.X509Certificate[]{};
                        }
                    }
            };
            // Install the all-trusting trust manager
            final SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, trustAllCerts, new java.security.SecureRandom());

            // Create an ssl socket factory with our all-trusting manager
            final SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();

            OkHttpClient.Builder builder = new OkHttpClient.Builder();
            builder.sslSocketFactory(sslSocketFactory, (X509TrustManager) trustAllCerts[0]);
            builder.hostnameVerifier(new HostnameVerifier() {
                @Override
                public boolean verify(String hostname, SSLSession session) {
                    return true;
                }
            });
            return builder;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static Gson gson = new GsonBuilder().setLenient().create();

   /* public static OkHttpClient okHttpClient = new OkHttpClient().newBuilder()
            .connectTimeout(1, TimeUnit.MINUTES)
            .readTimeout(1, TimeUnit.MINUTES)
            .writeTimeout(1, TimeUnit.MINUTES)
            .build();*/
//   String authTokenBearer ="Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJuYW1laWQiOiI2MzcxMCIsInVuaXF1ZV9uYW1lIjoiVXRpbGlzYXRldXJFdHVkZUlOb3RBY3Rlc18yNzAzNjAiLCJBc3BOZXQuSWRlbnRpdHkuU2VjdXJpdHlTdGFtcCI6IjMzMkEyMDFFLUJBQUItNDRFRS1CNzYyLTM2QkY3QTRCMkE2OSIsImZhbWlseV9uYW1lIjoiaU5vdCBBY3RlcyIsInJvbGUiOlsiQWRtaW5pc3RyYXRldXJQcm9maWxzIiwiQXBwbGljYXRpb24iXSwiSU5PVEFDVEUiOiJBZG1pbiIsIklOT1RDT01QVEFCSUxJVEUiOiJnZW5hcGkiLCJOT1RJRklDQVRJT05TIjoiTk9USUZJQ0FUSU9OUyIsIlBBSUVNRU5UR0VTVElPTiI6IlBBSUVNRU5UR0VTVElPTiIsIlBBSUVNRU5UIjoiVXRpbGlzYXRldXJFdHVkZUlOb3RBY3Rlc18yNzAzNjAiLCJFU1BBQ0VDTElFTlQiOiJJTk9UQUNURSIsIkVTSUdOQVRVUkVTIjoiSU5PVEFDVEUiLCJhdWQiOiIyNzAzNjAiLCJpc3MiOiJHZW5hcGkiLCJleHAiOjE1ODcxOTY4NDQsIm5iZiI6MTU4Njg1MTI0NH0.nYf6SBlOE0AFEenWD8yLBPewyTQ9kMinCnL5eVEblZ_4CXKSbct-plvoJ7iIpugCdAiTJjiDWD4vNLIQ_ylzp93s8wctHbN2HLbZg_t-20CJwt8HQK0AmOup_jT3ayomGVOym0_ptmJNnzT6ozvmOkuYZtf5OQ0BCNuLJF4oVw1L6-KB0AXdigV-8UPbRehkuVRdTj8V1zrZqlyDGAIqDKm72UkmCtD3PTQASi428ZExSAZnfkiVF1TvloGpaeSPbhMwClX6KO5xr5ZJ9o75sCCrc8Onhtb80w43O3YH02U3PaYFd6TKL7p6ipphszg7kALeAQDSFxuUE9SJ_G3P5w"

   public static OkHttpClient okHttpClient = new OkHttpClient.Builder().connectTimeout(1, TimeUnit.MINUTES)
           .readTimeout(1, TimeUnit.MINUTES)
           .writeTimeout(1, TimeUnit.MINUTES).addInterceptor(new Interceptor() {
               @Override
               public Response intercept(Chain chain) throws IOException {
                 /*
                    Chain original = chain.request()
                  Request request = original.newBuilder()
                           .header("Authorization",  authTokenBearer)
                           .method(original.method(), original.body())
                           .build()*/
                   Request newRequest  = chain.request().newBuilder()
                           .build();
                   return chain.proceed(newRequest);
               }
           }).build();

    public static Retrofit getClient() {
        if (retrofit == null) {
            retrofit = new Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .client(okHttpClient)
                    .addConverterFactory(GsonConverterFactory.create(gson))
                    .build();
        }
        return retrofit;

    }
}
