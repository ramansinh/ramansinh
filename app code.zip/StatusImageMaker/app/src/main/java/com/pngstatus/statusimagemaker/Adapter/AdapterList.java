package com.pngstatus.statusimagemaker.Adapter;

import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.pngstatus.statusimagemaker.model.model_font;
import com.pngstatus.statusimagemaker.R;

import java.util.ArrayList;

import static android.content.Context.LAYOUT_INFLATER_SERVICE;

public class AdapterList extends ArrayAdapter<model_font> {
    ArrayList<model_font> arrayList;
    Context context;
int cur_pos=0;
    public AdapterList(Context context, int resource, ArrayList<model_font> arrayList) {
        super(context, resource, arrayList);
        this.context = context;
        this.arrayList = arrayList;
    }

    public View getView(final int position, final View view, final ViewGroup parent) {
        View row = parent;
        LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(LAYOUT_INFLATER_SERVICE);
        row = inflater.inflate(R.layout.row_list_itm, parent, false);

        TextView item_name;
        item_name = row.findViewById(R.id.item_name);
        item_name.setTextColor(context.getResources().getColor(R.color.gray333));
       /* if (position==0){
            item_name.setTextColor(context.getResources().getColor(R.color.gray333));
        }else {
            item_name.setTextColor(context.getResources().getColor(R.color.gray333));
        }*/
//        String[] fontlist = arrayList.get(position).split("\\.");

//        item_name.setText(fontlist[0]);
//        item_name.setText(fontlist[0].replace("-", " "));
        item_name.setText(arrayList.get(position).getName());
        item_name.setTypeface(Typeface.createFromAsset(getContext().getAssets(), "fonts/"  +  arrayList.get(position).getFont()));

//        item_name.setTypeface(Typeface.createFromFile("/fonts/" + arrayList.get(position) + ".ttf"));
//        tv_myMsg.setTextIsSelectable(true);

        return row;
    }

}
