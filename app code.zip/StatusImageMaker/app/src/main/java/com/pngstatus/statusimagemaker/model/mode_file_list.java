package com.pngstatus.statusimagemaker.model;

import com.google.gson.annotations.SerializedName;

import java.io.File;

public class mode_file_list {
    @SerializedName("id")
    private String id;
    @SerializedName("path")
    private File path;
    @SerializedName("name")
    private String name;

    public mode_file_list(File path, String name) {

        this.path = path;
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public File getPath() {
        return path;
    }

    public void setPath(File path) {
        this.path = path;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
