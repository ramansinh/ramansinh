package com.pngstatus.statusimagemaker.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.pngstatus.statusimagemaker.Utils.LocaleHelper;
import com.pngstatus.statusimagemaker.Utils.Prefs;
import com.pngstatus.statusimagemaker.model.Response_login;
import com.pngstatus.statusimagemaker.model.model_login;
import com.pngstatus.statusimagemaker.R;
import com.pngstatus.statusimagemaker.Retrofit.RetrofitClient;
import com.pngstatus.statusimagemaker.Retrofit.RetrofitInterface;
import com.pngstatus.statusimagemaker.Utils.Constance;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SignUpActivity extends AppCompatActivity {

    Context context;
    @BindView(R.id.et_name)
    EditText et_name;
    @BindView(R.id.et_email)
    EditText et_email;
    @BindView(R.id.et_pass)
    EditText et_pass;
    @BindView(R.id.tv_login)
    TextView tv_login;
    @BindView(R.id.btn_signup)
    Button btn_signup;
    model_login model;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        context = SignUpActivity.this;
        ButterKnife.bind(this);
        if (Build.VERSION.SDK_INT < 16) {
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                    WindowManager.LayoutParams.FLAG_FULLSCREEN);
        } else {
            View decorView = getWindow().getDecorView();
            // Hide Status Bar.
            int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
            decorView.setSystemUiVisibility(uiOptions);
        }
        String applang = Prefs.getPrefString(context, Constance.select_app_lang, "en");
        LocaleHelper.setLocale(context,applang);
        tv_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(context, LoginActivity.class);
                startActivity(intent);
            }
        });

        btn_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (validation()) {
                    getSignUp(et_name.getText().toString(),
                            et_email.getText().toString(),
                            et_pass.getText().toString());
                }
            }
        });

    }

    private boolean validation() {
        if (et_name.getText().toString().isEmpty()) {
            et_name.requestFocus();
            et_name.setError(getResources().getString(R.string.err_entr_name));
            return false;
        } else if (et_email.getText().toString().isEmpty()) {
            et_email.requestFocus();
            et_email.setError(getResources().getString(R.string.err_enter_email));
            return false;
        } else if (et_pass.getText().toString().isEmpty()) {
            et_email.requestFocus();
            et_email.setError(getResources().getString(R.string.err_entr_paswrd));
            return false;
        } else {
            return true;
        }
    }

    private void getSignUp(String name, String email, String passwrd) {
        final ProgressDialog dialog = new ProgressDialog(context);
        dialog.setCancelable(false);
        dialog.setMessage(getResources().getString(R.string.wait_dot_dot));
        dialog.show();

        RetrofitInterface retrofitInterface = RetrofitClient.getClient().create(RetrofitInterface.class);
        Call<Response_login> call = retrofitInterface.user_register(name, email, passwrd, Constance.device_id, Constance.device);
        call.enqueue(new Callback<Response_login>() {
            @Override
            public void onResponse(Call<Response_login> call, Response<Response_login> response) {
                if (response != null && response.body() != null) {
                    if (response.body().getResult() != null && response.body().getResult().equals("1")) {
                        if (response.body().getApi_token() != null) {
//                            Prefs.savePreferance(context, Constance.api_token, response.body().getApi_token());
                            if (response.body().getRecord() != null) {
                                model = response.body().getRecord();
                               /* if (model.getId() != null) {
                                    Prefs.savePreferance(context, Constance.userId, model.getId());
                                }
                                if (model.getName() != null) {
                                    Prefs.savePreferance(context, Constance.userName, model.getName());
                                }
                                if (model.getEmail() != null) {
                                    Prefs.savePreferance(context, Constance.userEmail, model.getEmail());
                                }*/
                                Intent intent = new Intent(context, LoginActivity.class);
                                dialog.dismiss();
                                startActivity(intent);
                                finishAffinity();
                            } else {
                                dialog.dismiss();
                                Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            dialog.dismiss();
                            Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                        dialog.dismiss();
                    } else {
                        dialog.dismiss();
                        Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    dialog.dismiss();
                    Toast.makeText(context, response.message(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Response_login> call, Throwable t) {
                dialog.dismiss();
                Toast.makeText(context, t.getMessage(), Toast.LENGTH_SHORT).show();
                Log.e("response", "login :" + t.getMessage());
            }
        });
    }
}
