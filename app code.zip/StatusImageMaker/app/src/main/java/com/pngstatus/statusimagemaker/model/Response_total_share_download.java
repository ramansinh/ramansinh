package com.pngstatus.statusimagemaker.model;

import com.google.gson.annotations.SerializedName;

public class Response_total_share_download {
    @SerializedName("result")
    private String result;
    @SerializedName("message")
    private String message;
    @SerializedName("record")
    private model_total_share_download record;
    @SerializedName("records")
    private model_add_user_action records;

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public model_total_share_download getRecord() {
        return record;
    }

    public void setRecord(model_total_share_download record) {
        this.record = record;
    }

    public model_add_user_action getRecords() {
        return records;
    }

    public void setRecords(model_add_user_action records) {
        this.records = records;
    }
}
