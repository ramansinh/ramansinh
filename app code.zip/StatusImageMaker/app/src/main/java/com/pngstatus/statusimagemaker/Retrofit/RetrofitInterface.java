package com.pngstatus.statusimagemaker.Retrofit;

import com.pngstatus.statusimagemaker.model.Response_active_ad;
import com.pngstatus.statusimagemaker.model.Response_category;
import com.pngstatus.statusimagemaker.model.Response_login;
import com.pngstatus.statusimagemaker.model.Response_common;
import com.pngstatus.statusimagemaker.model.Response_policy;
import com.pngstatus.statusimagemaker.model.Response_post;
import com.pngstatus.statusimagemaker.model.Response_total_share_download;
import com.pngstatus.statusimagemaker.model.model_post;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;

public interface RetrofitInterface {

    @FormUrlEncoded
    @POST("user/register")
    Call<Response_login> user_register(@Field("name") String name,
                                       @Field("email") String email,
                                       @Field("password") String password,
                                       @Field("device_id") String device_id,
                                       @Field("device") String device);

    @FormUrlEncoded
    @POST("user/login")
    Call<Response_login> user_login(@Field("email") String email,
                                    @Field("password") String password);

    @FormUrlEncoded
    @POST("user/forgot_password")
    Call<Response_common> forgot_password(@Field("email") String email);

    @FormUrlEncoded
    @POST("user/profile")
    Call<Response_login> get_profile(@Field("api_token") String api_token);

    @FormUrlEncoded
    @POST("user/profile")
    Call<Response_login> get_favourite(@Field("api_token") String api_token,
                                       @Field("type") String type);

  /*  @Multipart
    @POST("user/profile")
    Call<Response_login> update_profile(@Part("api_token") RequestBody api_token,
                                        @Part("name") RequestBody name,
                                        @Part("email") RequestBody email,
                                        @Part("language") RequestBody language); */

    @Multipart
    @POST("user/profile")
    Call<Response_login> update_profile(@Part("api_token") RequestBody api_token,
                                        @Part("name") RequestBody name,
                                        @Part("email") RequestBody email,
                                        @Part("language") RequestBody language);
    @Multipart
    @POST("user/profile")
    Call<Response_login> update_profile_image(@Part("api_token") RequestBody api_token,
                                              @Part MultipartBody.Part image);

    @Multipart
    @POST("user/profile")
    Call<Response_login> update_password(@Part("api_token") RequestBody api_token,
                                         @Part("password") RequestBody password);

    @Multipart
    @POST("user/profile")
    Call<Response_login> updateLang(@Part("api_token") RequestBody api_token,
                                    @Part("language") RequestBody language);

    @FormUrlEncoded
    @POST("category/category_list")
    Call<Response_category> category_list(@Field("api_token") String api_token);


    @FormUrlEncoded
    @POST("post/latest_post")
    Call<Response_post> latest_post(@Field("api_token") String api_token,
                                    @Field("category_id") String category_id);

    @FormUrlEncoded
    @POST("category/category_images_list")
    Call<Response_post> category_images_list(@Field("api_token") String api_token,
                                             @Field("category_id") String category_id);

    @FormUrlEncoded
    @POST("user/my_favorite_post")
    Call<Response_post> my_favorite_post(@Field("api_token") String api_token);

    @FormUrlEncoded
    @POST("user/my_edited_post")
    Call<Response_post> my_edited_post(@Field("api_token") String api_token,
                                       @Field("type") String type);

    @FormUrlEncoded
    @POST("category/favourite")
    Call<Response_common> favourite(@Field("api_token") String api_token,
                                    @Field("image_id") String image_id);

    @FormUrlEncoded
    @POST("ad/active_ad")
    Call<Response_active_ad> active_ad(@Field("api_token") String api_token);

    @FormUrlEncoded
    @POST("user/privacy")
    Call<Response_policy> get_privacy(@Field("api_token") String api_token);

    @FormUrlEncoded
    @POST("post/add_user_action")
    Call<Response_total_share_download> add_user_action(@Field("api_token") String api_token,
                                                        @Field("image_id") String image_id,
                                                        @Field("type") String type);

    @FormUrlEncoded
    @POST("post/total_share_download")
    Call<Response_total_share_download> total_share_download(@Field("api_token") String api_token,
                                                             @Field("image_id") String image_id,
                                                             @Field("type") String type);
}
