package com.pngstatus.statusimagemaker.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.documentfile.provider.DocumentFile;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Point;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.pngstatus.statusimagemaker.R;
import com.pngstatus.statusimagemaker.Utils.Constance;
import com.pngstatus.statusimagemaker.Utils.Prefs;

import java.io.File;
import java.io.FileOutputStream;

public class FullScrnImgActivity extends AppCompatActivity {
    Context context;
    ImageView iv_img, iv_close, iv_dlt, iv_share;
    String img_url = "";
    String path;
    PopupWindow popup=new PopupWindow();
    WindowManager.LayoutParams params = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_full_scrn_img);
        context = FullScrnImgActivity.this;
        iv_close = findViewById(R.id.iv_close);
        iv_img = findViewById(R.id.iv_img);
        iv_dlt = findViewById(R.id.iv_dlt);
        iv_share = findViewById(R.id.iv_share);

        iv_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        if (getIntent().hasExtra(Constance.img_url)) {
            path = getIntent().getStringExtra(Constance.img_url);
            Glide.with(context).load(path).into(iv_img);
        }
        iv_dlt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Popup_Logout();
            }
        });
        iv_share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shareItem(Uri.parse(path));
            }
        });
    }

    private void deletefile(String path) {
//        DocumentFile pickedDir = DocumentFile.fromTreeUri(this, uri);
        String d_path = path;
        File file = new File(d_path);
//        file.delete();

//        DocumentFile file = pickedDir.findFile(filename);
//        File file=new File(uri.getPath());

        if (file.delete()) {
            Log.d("Log ID", "Delete successful");
            onBackPressed();
        } else {
            Log.d("Log ID", "Delete unsuccessful");
        }
    }

    public void shareItem(Uri uri) {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("image/*");
        File file = new File(uri.getPath());
      /*  Uri photoUri = FileProvider.getUriForFile(
                context,
                getResources().getString(R.string.file_provider_authority),
                file);*/
//        share.putExtra(Intent.EXTRA_SUBJECT, "Title Of The Post");
        i.putExtra(Intent.EXTRA_TEXT, getResources().getString(R.string.sim_link)+getApplication().getPackageName() );
        i.putExtra(Intent.EXTRA_STREAM, uri);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(i, getResources().getString(R.string.share_img)));
    }
    public void Popup_Logout() {
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        int width = size.x;
        int height = size.y;
        if (!popup.isShowing()) {
            final LayoutInflater inflaterpopup = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
            final View view1 = inflaterpopup.inflate(R.layout.popup_logout, null);
            popup = new PopupWindow(view1, params.MATCH_PARENT, params.MATCH_PARENT);
            popup.setFocusable(true);
            TextView tv_msg=view1.findViewById(R.id.tv_msg);
            TextView tv_no=view1.findViewById(R.id.tv_no);
            TextView tv_yes=view1.findViewById(R.id.tv_yes);
            tv_msg.setText(getResources().getString(R.string.are_u_sure_to_dlt_file));
            tv_no.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    popup.dismiss();
                }
            });
            tv_yes.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    popup.dismiss();
                    String filename[] = path.split("/");
                    // deletefile(path, filename[(filename.length - 1)]);
                     deletefile(path);
               /*     Intent intent = new Intent(context, MainActivity.class);
                    context.startActivity(intent);
                    ((Activity)context).finishAffinity();*/
                }
            });
            popup.setOutsideTouchable(true);
//                          popup.showAtLocation(view1, Gravity.TOP, width, height);
            popup.showAtLocation(view1, Gravity.BOTTOM, 0, 0);
        } else {
            popup.dismiss();
        }
    }

}