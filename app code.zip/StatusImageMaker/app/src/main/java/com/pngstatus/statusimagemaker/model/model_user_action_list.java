package com.pngstatus.statusimagemaker.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class model_user_action_list {
    @SerializedName("favourite")
    private ArrayList<model_user_action_list_data> favourite;
    @SerializedName("download")
    private ArrayList<model_user_action_list_data> download;

    @SerializedName("view")
    private ArrayList<model_user_action_list_data> view;

    @SerializedName("share")
    private ArrayList<model_user_action_list_data> share;

    @SerializedName("edit")
    private ArrayList<model_user_action_list_data> edit;

    public ArrayList<model_user_action_list_data> getFavourite() {
        return favourite;
    }

    public void setFavourite(ArrayList<model_user_action_list_data> favourite) {
        this.favourite = favourite;
    }

    public ArrayList<model_user_action_list_data> getDownload() {
        return download;
    }

    public void setDownload(ArrayList<model_user_action_list_data> download) {
        this.download = download;
    }

    public ArrayList<model_user_action_list_data> getView() {
        return view;
    }

    public void setView(ArrayList<model_user_action_list_data> view) {
        this.view = view;
    }

    public ArrayList<model_user_action_list_data> getShare() {
        return share;
    }

    public void setShare(ArrayList<model_user_action_list_data> share) {
        this.share = share;
    }

    public ArrayList<model_user_action_list_data> getEdit() {
        return edit;
    }

    public void setEdit(ArrayList<model_user_action_list_data> edit) {
        this.edit = edit;
    }
}
