package com.pngstatus.statusimagemaker.Fragment;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.PagerSnapHelper;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SnapHelper;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.pngstatus.statusimagemaker.Activity.CustomEditorActivity;
import com.pngstatus.statusimagemaker.Activity.EditFvrtPostActivity;
import com.pngstatus.statusimagemaker.Activity.EditPostActivity;
import com.pngstatus.statusimagemaker.Adapter.AdapterFvrtList;
import com.pngstatus.statusimagemaker.Adapter.AdapterHashTagList;
import com.pngstatus.statusimagemaker.Adapter.AdapterstatusList;
import com.pngstatus.statusimagemaker.MainActivity;
import com.pngstatus.statusimagemaker.Utils.EndlessRecyclerOnScrollListener;
import com.pngstatus.statusimagemaker.Utils.LocaleHelper;
import com.pngstatus.statusimagemaker.Utils.Popup_success;
import com.pngstatus.statusimagemaker.model.Response_common;
import com.pngstatus.statusimagemaker.model.Response_post;
import com.pngstatus.statusimagemaker.model.Response_total_share_download;
import com.pngstatus.statusimagemaker.model.model_post;
import com.pngstatus.statusimagemaker.model.model_post_data;
import com.pngstatus.statusimagemaker.R;
import com.pngstatus.statusimagemaker.Retrofit.RetrofitClient;
import com.pngstatus.statusimagemaker.Retrofit.RetrofitInterface;
import com.pngstatus.statusimagemaker.Utils.Constance;
import com.pngstatus.statusimagemaker.Utils.Prefs;
import com.pngstatus.statusimagemaker.Utils.VerticalViewPager;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class FavouriteFragment extends Fragment {
    public static Context context;
    Activity activity;
    public MainActivity instance;
    private Unbinder unbinder;
    @BindView(R.id.loader)
    ProgressBar loader;
//    @BindView(R.id.myViewpager)
//    VerticalViewPager myViewpager;
//    MyPagerAdapter mViewPagerAdapter;

    @BindView(R.id.rv_list)
    RecyclerView rv_list;
    public static TextView tv_nodata;
    boolean imgselected = false;
    model_post model;
    ArrayList<model_post_data> arrayList = new ArrayList<>();

    ArrayList<String> arrayListHashTag = new ArrayList<>();
    AdapterHashTagList adapterHashTagList;
    String categryId = "";

    int cur_pos = 0;
    public  static  AdapterFvrtList adapterFvrtList;

    public FavouriteFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_favourite, container, false);
        context = getActivity();
        activity = getActivity();
        tv_nodata=view.findViewById(R.id.tv_nodata);
        unbinder = ButterKnife.bind(this, view);
        instance = MainActivity.getInstance();
        instance.ivPhotos.setSelected(false);
        instance.tvPhotos.setSelected(false);
        instance.ivCatgry.setSelected(false);
        instance.tvCatgry.setSelected(false);
        instance.ivFvrt.setSelected(true);
        instance.tvFvrt.setSelected(true);
        instance.ivProfile.setSelected(false);
        instance.tvProfile.setSelected(false);

        instance.ivPhotos.setEnabled(true);
        instance.ivProfile.setEnabled(true);
        instance.ivCatgry.setEnabled(true);
        instance.ivFvrt.setEnabled(false);

        instance.logo.setVisibility(View.GONE);
        instance.ivBack.setVisibility(View.VISIBLE);
        instance.ivSave.setVisibility(View.GONE);
        instance.btnLogout.setVisibility(View.GONE);
        instance.ivShare.setVisibility(View.GONE);


        instance.show_fullScreen_Ad();
        String applang = Prefs.getPrefString(context, Constance.select_app_lang, "en");
        LocaleHelper.setLocale(context,applang);
        arrayList.clear();
        SnapHelper linearSnapHelper = new PagerSnapHelper();
        linearSnapHelper.attachToRecyclerView(rv_list);
        LinearLayoutManager lm=new LinearLayoutManager(context);
        rv_list.setLayoutManager(lm);
        rv_list.setHasFixedSize(false);

      /*  instance.ivPhotos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setHomeFragment();
            }
        });
        instance.ivCatgry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                moveFragment(new CategoryFragment());
            }
        });
        instance.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, CustomEditorActivity.class);
                startActivity(intent);
            }
        });
        instance.ivProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                moveFragment(new ProfileFragment());
            }
        });*/

        arrayList.clear();

  /*      myViewpager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                cur_pos = position;
//                Log.e("apicall", "onPageScrolled " + position);
                if (position == (arrayList.size() - 2)) {
                    if (model != null && model.getNext_page_url() != null) {
//                        Log.e("apicall", "moredata api call " + position);
                        loadNextDataFromApi();
                    } else {
//                        Log.e("apicall", "moredata api not call " + position);
                    }
                } else {
//                    Log.e("apicall", "post api call " + position);
                }
            }

            @Override
            public void onPageSelected(int position) {

//                Log.e("apicall","onPageSelected "+position);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });*/

        getPost("");

        rv_list.addOnScrollListener(new EndlessRecyclerOnScrollListener(lm) {
            @Override
            public void onLoadMore(int page, int totalItemsCount, RecyclerView view) {
                if (model != null && model.getNext_page_url() != null) {
                    loadNextDataFromApi();
                }
            }
        });

        return view;
    }

    private void getPost(String catid) {
        loader.setVisibility(View.VISIBLE);
        String token = Prefs.getPrefString(context, Constance.api_token, "");

        RetrofitInterface retrofitInterface = RetrofitClient.getClient().create(RetrofitInterface.class);
        Call<Response_post> call = retrofitInterface.my_favorite_post(token);
        call.enqueue(new Callback<Response_post>() {
            @Override
            public void onResponse(Call<Response_post> call, Response<Response_post> response) {
                if (response != null && response.body() != null) {
                    if (response.body().getRecords()!=null){
                        model = response.body().getRecords();
                        arrayList.clear();
                        if (model.getData() != null && model.getData().size() > 0) {
                            /*for (int i=0;i<model.getData().size();i++){
                                if (model.getData().get(i).getIs_my_favorite().equals("1") && model.getData().get(i).getFavourite()!=null){
                                    arrayList.add((model.getData().get(i)));
                                }
                            }*/
                            arrayList.addAll(response.body().getRecords().getData());
                            adapterFvrtList=new AdapterFvrtList(context,arrayList);
                            rv_list.setAdapter(adapterFvrtList);
//                            mViewPagerAdapter = new MyPagerAdapter(context, arrayList);
                            // Adding the Adapter to the ViewPager
//                            myViewpager.setAdapter(mViewPagerAdapter);
                            tv_nodata.setVisibility(View.GONE);
                            loader.setVisibility(View.GONE);
                            nodatafound(arrayList);
                        } else {
                            tv_nodata.setVisibility(View.VISIBLE);
                            loader.setVisibility(View.GONE);
//                            Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                        loader.setVisibility(View.GONE);
                    }

                    loader.setVisibility(View.GONE);
                } else {
                    tv_nodata.setVisibility(View.VISIBLE);
                    loader.setVisibility(View.GONE);
//                    Toast.makeText(context, response.message(), Toast.LENGTH_SHORT).show();
                }
                loader.setVisibility(View.GONE);
            }

            @Override
            public void onFailure(Call<Response_post> call, Throwable t) {
                loader.setVisibility(View.GONE);
//                Toast.makeText(context, t.getMessage(), Toast.LENGTH_SHORT).show();
                Log.e("response", "login :" + t.getMessage());
            }
        });
    }
    public void loadNextDataFromApi() {
        loader.setVisibility(View.VISIBLE);
        String token = Prefs.getPrefString(context, Constance.api_token, "");

        StringRequest stringRequest = new StringRequest(Request.Method.POST, model.getNext_page_url(), new com.android.volley.Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONObject records = jsonObject.getJSONObject("records");
                    Gson gson = new Gson();
                    Type type = new TypeToken<model_post>() {
                    }.getType();

                    model = gson.fromJson(records.toString(), type);
                    ArrayList<model_post_data> list = model.getData();
//                    arrayList.addAll(list);
                  /*  for (int i=0;i<model.getData().size();i++){
                        if (model.getData().get(i).getIs_my_favorite().equals("1") && model.getData().get(i).getFavourite()!=null){
                            arrayList.add((model.getData().get(i)));
                        }
                    }*/

                    if (list!=null && list.size() != 0) {
                        arrayList.addAll(list);
                        adapterFvrtList.notifyDataSetChanged();
//                        mViewPagerAdapter.notifyDataSetChanged();
//                            myViewpager.setAdapter(mViewPagerAdapter);
                        loader.setVisibility(View.GONE);
                    } else {
                        loader.setVisibility(View.GONE);
                    }


                    loader.setVisibility(View.GONE);
                } catch (JSONException e) {
                    e.printStackTrace();
                    loader.setVisibility(View.GONE);
                }
            }
        }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
//                Toast.makeText(context, "Please Check Your Internet Connection", Toast.LENGTH_SHORT).show();
                loader.setVisibility(View.GONE);
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
//                params.put("token",Prefs.getPrefString(context,Constance.auth_token,""));
                params.put("api_token", token);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(context);
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(60000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(stringRequest);
    }
    public class MyPagerAdapter extends PagerAdapter {
        // Context object
        Context context;
        // Array of images
        ArrayList<model_post_data> arrayList = new ArrayList<>();
        LayoutInflater mLayoutInflater;

        public MyPagerAdapter(Context context, ArrayList<model_post_data> data) {
            this.context = context;
            this.arrayList = data;
            mLayoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        @Override
        public int getCount() {
            return arrayList.size();
        }

        @Override
        public int getItemPosition(@NonNull Object object) {
//            return super.getItemPosition(object);
            return POSITION_NONE;
        }

        @Override
        public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
//            return false;
            return view == ((LinearLayout) object);
        }

        @NonNull
        @Override
        public Object instantiateItem(@NonNull ViewGroup container, final int position) {
            // inflating the item.xml
            cur_pos=position;
            View itemView = mLayoutInflater.inflate(R.layout.row_status_list, container, false);
            String typ = "";
//            boolean frvt = false;
            // referencing the image view from the item.xml file
            TextView tv_view, tv_share, tv_dwnld, tv_edit;
            RelativeLayout rl_view_to_img = itemView.findViewById(R.id.rl_view_to_img);
            ImageView iv_main_back = itemView.findViewById(R.id.iv_main_back);
            ImageView iv_view = itemView.findViewById(R.id.iv_view);
            ImageView iv_txteffct_img = itemView.findViewById(R.id.iv_txteffct_img);
            ImageView iv_fvrt = itemView.findViewById(R.id.iv_fvrt);
            ImageView iv_fvrt_fill = itemView.findViewById(R.id.iv_fvrt_fill);
            ImageView iv_edit = itemView.findViewById(R.id.iv_edit);
            ImageView iv_wp = itemView.findViewById(R.id.iv_wp);
            ImageView iv_dwnld = itemView.findViewById(R.id.iv_dwnld);
            tv_view = itemView.findViewById(R.id.tv_view);
            tv_share = itemView.findViewById(R.id.tv_share);
            tv_dwnld = itemView.findViewById(R.id.tv_dwnld);
            tv_edit = itemView.findViewById(R.id.tv_edit);
            iv_txteffct_img.setVisibility(View.GONE);
//            Glide.with(context).load(arrayList.get(position).getFrame_image_url()).into(iv_txteffct_img);
            Glide.with(context).load(arrayList.get(position).getPreview_image_url()).into(iv_main_back);

            iv_wp.setVisibility(View.INVISIBLE);
            iv_edit.setVisibility(View.INVISIBLE);
            iv_view.setVisibility(View.INVISIBLE);
            iv_dwnld.setVisibility(View.INVISIBLE);

            tv_dwnld.setVisibility(View.INVISIBLE);
            tv_edit.setVisibility(View.INVISIBLE);
            tv_share.setVisibility(View.INVISIBLE);
            tv_view.setVisibility(View.INVISIBLE);

            // setting the image in the imageView

            if (arrayList.get(position).getFavourite() != null ) {
                iv_fvrt_fill.setVisibility(View.VISIBLE);
                iv_fvrt.setVisibility(View.GONE);
            } else {
                iv_fvrt_fill.setVisibility(View.GONE);
                iv_fvrt.setVisibility(View.VISIBLE);
            }


          /*  iv_fvrt.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Animation fadeout = AnimationUtils.loadAnimation(context, R.anim.fade_out);
                    iv_fvrt.startAnimation(fadeout);
                    fvrtimg(arrayList,position, true, iv_fvrt, iv_fvrt_fill);
                }
            });

            iv_fvrt_fill.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Animation fadeout = AnimationUtils.loadAnimation(context, R.anim.fade_out);
                    iv_fvrt_fill.startAnimation(fadeout);

                    fvrtimg(arrayList,position, false, iv_fvrt, iv_fvrt_fill);
                }
            });*/

            if (arrayList.get(position).getView_count() != null) {
                tv_view.setText(arrayList.get(position).getView_count());
            }
            if (arrayList.get(position).getShare_count() != null) {
                tv_share.setText(arrayList.get(position).getShare_count());
            }
            if (arrayList.get(position).getDownload_count() != null) {
                tv_dwnld.setText(arrayList.get(position).getDownload_count());
            }
            if (arrayList.get(position).getEdit_count() != null) {
                tv_edit.setText(arrayList.get(position).getEdit_count());
            }


            // Adding the View
            Objects.requireNonNull(container).addView(itemView);

            return itemView;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {

            container.removeView((LinearLayout) object);
        }
    }
    public static void fvrtimg(ArrayList<model_post_data> arrayList, int pos, boolean status, ImageView line, ImageView fill) {
        String id=arrayList.get(pos).getId();

        final ProgressDialog dialog = new ProgressDialog(context);
        dialog.setCancelable(false);
        dialog.setMessage(context.getResources().getString(R.string.wait_dot_dot));
        dialog.show();
        String token = Prefs.getPrefString(context, Constance.api_token, "");
        RetrofitInterface retrofitInterface = RetrofitClient.getClient().create(RetrofitInterface.class);
        Call<Response_common> call = retrofitInterface.favourite(token, id);
        call.enqueue(new Callback<Response_common>() {
            @Override
            public void onResponse(Call<Response_common> call, Response<Response_common> response) {
                if (response != null && response.body() != null) {
                    if (response.body().getResult() != null && response.body().getResult().equals("1")) {

                        Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        if (status) {
                            line.setVisibility(View.GONE);
                            fill.setVisibility(View.VISIBLE);
                            Animation fadein = AnimationUtils.loadAnimation(context, R.anim.fade_in);
                            fill.startAnimation(fadein);

                        } else {
//                            getPost("");
                            arrayList.remove(pos);
                            adapterFvrtList.notifyDataSetChanged();
//                            mViewPagerAdapter.notifyDataSetChanged();
                          /*  notifyItemRemoved(position);
                            notifyItemRangeChanged(position, mDataSet.size());*/
                          /*  arrayList.remove(pos);
                            mViewPagerAdapter.notifyDataSetChanged();*/
                            line.setVisibility(View.VISIBLE);
                            fill.setVisibility(View.GONE);
                            Animation fadein = AnimationUtils.loadAnimation(context, R.anim.fade_in);
                            line.startAnimation(fadein);
                        }
                        nodatafound(arrayList);
                        dialog.dismiss();
                    } else {
                        dialog.dismiss();
                        Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    dialog.dismiss();
//                    Toast.makeText(context, response.message(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Response_common> call, Throwable t) {
                dialog.dismiss();
//                Toast.makeText(context, t.getMessage(), Toast.LENGTH_SHORT).show();
                Log.e("response", "reset passwrd :" + t.getMessage());
            }
        });
    }
    public void moveFragment(Fragment fragment) {
//        FragmentManager fm = ((Activity) context).getFragmentManager();
        FragmentManager fm = getActivity().getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
//        Bundle args = new Bundle();
//        args.putString(Constance.maincategoryId, getId);
//        fragment.setArguments(args);
//        fm.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
//        ft.replace(R.id.main_frame, fragment, fragment.getClass().getSimpleName());
        ft.replace(R.id.main_frame, fragment, fragment.getClass().getSimpleName()).addToBackStack(null);
        ft.commit();
    }
    public void setHomeFragment() {
        Fragment fragment = new HomeFragment();
        FragmentManager fm = getActivity().getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        fm.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
        ft.replace(R.id.main_frame, fragment, fragment.getClass().getSimpleName());
        ft.commit();
    }
    public static void nodatafound(ArrayList<model_post_data>arrayList){
        if (arrayList.size()==0){
            tv_nodata.setVisibility(View.VISIBLE);
        }else {
            tv_nodata.setVisibility(View.GONE);
        }
    }
    public static void total_share_download(ArrayList<model_post_data> arrayList, int pos, String typ, TextView textView, String count) {

        String id = arrayList.get(pos).getId();
        String token = Prefs.getPrefString(context, Constance.api_token, "");
        RetrofitInterface retrofitInterface = RetrofitClient.getClient().create(RetrofitInterface.class);
        Call<Response_total_share_download> call = retrofitInterface.add_user_action(token, id, typ);
        call.enqueue(new Callback<Response_total_share_download>() {
            @Override
            public void onResponse(Call<Response_total_share_download> call, Response<Response_total_share_download> response) {
                if (response != null && response.body() != null) {
                    if (response.body().getResult() != null && response.body().getResult().equals("1")) {
                        if (response.body().getRecords() != null) {
//                            edit/share/download/view
                            if (response.body().getRecords().getType().equals("edit")) {
                                textView.setText((Integer.parseInt(count) + 1) + "");
                                arrayList.get(pos).setEdit_count(textView.getText().toString());
                                Intent intent = new Intent(context, EditFvrtPostActivity.class);
                                intent.putExtra(Constance.img_url, arrayList.get(pos).getFrame_image_url());
                                intent.putExtra(Constance.pos, pos);
                                context.startActivity(intent);
                            }
                            if (response.body().getRecords().getType().equals("share")) {
                                textView.setText((Integer.parseInt(count) + 1) + "");
                                arrayList.get(pos).setShare_count(textView.getText().toString());
                            }
                            if (response.body().getRecords().getType().equals("view")) {
                                textView.setText((Integer.parseInt(count) + 1) + "");
                                arrayList.get(pos).setView_count(textView.getText().toString());
                            }
                            if (response.body().getRecords().getType().equals("download")) {
                                textView.setText((Integer.parseInt(count) + 1) + "");
                                arrayList.get(pos).setDownload_count(textView.getText().toString());
                            }
                            adapterFvrtList.notifyDataSetChanged();
//                            mViewPagerAdapter.notifyDataSetChanged();
                        }
                    } else {
                        if (typ.equals("edit")) {
                            Intent intent = new Intent(context, EditFvrtPostActivity.class);
                            intent.putExtra(Constance.img_url, arrayList.get(pos).getFrame_image_url());
                            intent.putExtra(Constance.pos, pos);
                            context.startActivity(intent);
                        }
                    }
                } else {
//                    dialog.dismiss();
//                    Toast.makeText(context, response.message(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Response_total_share_download> call, Throwable t) {
//                dialog.dismiss();
//                Toast.makeText(context, t.getMessage(), Toast.LENGTH_SHORT).show();
                Log.e("response", "total _share n all :" + t.getMessage());
            }
        });
    }
    public static Bitmap viewToBitmap(View view) {
        Bitmap bitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        view.draw(canvas);
        return bitmap;
    }
    public static boolean saveImage(RelativeLayout view, String filename) {
        Bitmap bm = viewToBitmap(view);
        OutputStream fos = null;
        File imageFile = null;
        Uri imageUri = null;
        /*String root = Environment.getExternalStorageDirectory().toString();
        File myDir = newicon File(root);
        myDir.mkdirs();
        String fname = "Image-" + image_name+ ".jpg";*/
        File storageDir;

       /* if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            // only for gingerbread and newer versions
            storageDir = new File(context.getExternalFilesDir(null), "/pngStatus/");
        } else {
//            storageDir = new File(Environment.getExternalStorageDirectory() + "/pngStatus/");
            storageDir =new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).toString()+ "/pngStatus/");
        }*/

        storageDir =new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)+ "/pngStatus/");
        if (storageDir.exists()) {
            Log.e("tag", "exitst file path" + storageDir.getAbsolutePath());
        } else {
            storageDir.mkdirs();
        }
        File file = new File(storageDir, filename + ".png");
        if (file.exists()) file.delete();
//        Log.i("LOAD", root + fname);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                ContentResolver resolver = context.getContentResolver();
                ContentValues contentValues = new ContentValues();
                contentValues.put(MediaStore.MediaColumns.DISPLAY_NAME, filename + ".png");
                contentValues.put(MediaStore.MediaColumns.MIME_TYPE, "image/png");
                contentValues.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/pngStatus/");
                imageUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues);
                if (imageUri == null)
                    throw new IOException("Failed to create new MediaStore record.");
//                fos = resolver.openOutputStream(imageUri);
                try {
                    fos = resolver.openOutputStream(imageUri);
                    bm.compress(Bitmap.CompressFormat.PNG, 100, fos);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            } else {
                file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + "/pngStatus/", filename + ".png");
                if (file.exists())
                    file.delete();
                imageFile = new File(storageDir, filename + ".png");
                try {
                    fos = new FileOutputStream(imageFile);
                    bm.compress(Bitmap.CompressFormat.PNG, 100, fos);
//                    Constance.createdBitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            }
            if (imageFile != null) {//pre Q
                MediaScannerConnection.scanFile(context, new String[]{imageFile.toString()}, null, null);
                imageUri = Uri.fromFile(imageFile);
            }
//                throw new IOException("Failed to save bitmap.");

//                shareItem(getLocalBitmapUri(filename + ".png"));
            fos.flush();
            fos.close();

            Popup_success popup_success=new Popup_success();
            popup_success.Popup_success(context,context.getResources().getString(R.string.msg_dwnld_sucssfully));
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean download_ShareImg(RelativeLayout view, String name) {
        ProgressDialog pDialog = new ProgressDialog(context, R.style.AppTheme);
        pDialog.setCancelable(false);
        pDialog.setProgressStyle(android.R.style.Widget_ProgressBar_Small);
        pDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        pDialog.show();
        OutputStream fos = null;
        File imageFile = null;
        Uri imageUri = null;
//        if (imgselected) {
        String filename = name;
        Bitmap bm = viewToBitmap(view);
//        Bitmap bm = getBitmapFromURL(url);

        File storageDir;
       /* if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            // only for gingerbread and newer versions
            storageDir = new File(context.getExternalFilesDir(null), "/pngStatus/");
        } else {
//            storageDir = new File(Environment.getExternalStorageDirectory() + "/pngStatus/");
            storageDir =new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).toString()+ "/pngStatus/");
        }*/
        storageDir =new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)+ "/pngStatus/");
        if (storageDir.exists()) {
            Log.e("tag", "exitst file path" + storageDir.getAbsolutePath());
        } else {
            storageDir.mkdirs();
        }
        File file = new File(storageDir, filename + ".png");
        if (file.exists())
            file.delete();

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                ContentResolver resolver = context.getContentResolver();
                ContentValues contentValues = new ContentValues();
                contentValues.put(MediaStore.MediaColumns.DISPLAY_NAME, filename + ".png");
                contentValues.put(MediaStore.MediaColumns.MIME_TYPE, "image/png");
                contentValues.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/pngStatus/");
                imageUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues);
                if (imageUri == null)
                    throw new IOException("Failed to create new MediaStore record.");
//                fos = resolver.openOutputStream(imageUri);
                try {
                    fos = resolver.openOutputStream(imageUri);
                    bm.compress(Bitmap.CompressFormat.PNG, 100, fos);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            } else {
                file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + "/pngStatus/", filename + ".png");
                if (file.exists())
                    file.delete();
                imageFile = new File(storageDir, filename + ".png");
                try {
                    fos = new FileOutputStream(imageFile);
                    bm.compress(Bitmap.CompressFormat.PNG, 100, fos);
//                    Constance.createdBitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            }

//                throw new IOException("Failed to save bitmap.");

//                shareItem(getLocalBitmapUri(filename + ".png"));
            fos.flush();
          /*  FileOutputStream out = new FileOutputStream(file);
//                Constance.createdBitmap.compress(Bitmap.CompressFormat.JPEG, 100, out);
            StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
            StrictMode.setVmPolicy(builder.build());
            shareItem(getLocalBitmapUri(filename + ".png"));
            out.flush();
            out.close();
            pDialog.dismiss();

            Toast.makeText(context, context.getResources().getString(R.string.msg_share_img_sucscfuly), Toast.LENGTH_SHORT).show();*/

            if (imageFile != null) {//pre Q
                MediaScannerConnection.scanFile(context, new String[]{imageFile.toString()}, null, null);
                imageUri = Uri.fromFile(imageFile);
            }
//            shareItem(getLocalBitmapUri(filename + ".png"));
            shareItem(imageUri);
            pDialog.dismiss();
            return true;
        } catch (Exception e) {
            pDialog.dismiss();
            e.printStackTrace();
            Toast.makeText(context, e.getMessage(), Toast.LENGTH_SHORT).show();
            return false;
        }finally {
            if (fos != null) {
                try {
                    fos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

       /* } else {
            Toast.makeText(context, "Select Image", Toast.LENGTH_SHORT).show();
        }*/
    }
    public static void shareItem(Uri uri) {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("image/*");
        File file = new File(uri.getPath());
      /*  Uri photoUri = FileProvider.getUriForFile(
                context,
                context.getResources().getString(R.string.file_provider_authority),
                file);*/
        i.putExtra(Intent.EXTRA_SUBJECT, "Status Image Maker");
        i.putExtra(Intent.EXTRA_TEXT, "Download and create your own status :+ Link");
        i.putExtra(Intent.EXTRA_STREAM, uri);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
//        i.setPackage("com.whatsapp");//package name of the app
        context.startActivity(Intent.createChooser(i, context.getResources().getString(R.string.share_img)));
        /*PackageManager packageManager = context.getPackageManager();
    Intent i = new Intent(Intent.ACTION_VIEW);

    try {
        String url = "https://api.whatsapp.com/send?phone="+ phone +"&text=" + URLEncoder.encode(message, "UTF-8");
        i.setPackage("com.whatsapp");
        i.setData(Uri.parse(url));
        if (i.resolveActivity(packageManager) != null) {
            context.startActivity(i);
        }
    } catch (Exception e){
        e.printStackTrace();
    }*/
    }
    @Override
    public void onResume() {
        super.onResume();
        instance = MainActivity.getInstance();
        instance.ivPhotos.setSelected(false);
        instance.tvPhotos.setSelected(false);
        instance.ivCatgry.setSelected(false);
        instance.tvCatgry.setSelected(false);
        instance.tvFvrt.setFocusable(true);
        instance.ivFvrt.setFocusable(true);
        instance.ivFvrt.setSelected(true);
        instance.tvFvrt.setSelected(true);
        instance.ivProfile.setSelected(false);
        instance.tvProfile.setSelected(false);

        instance.ivPhotos.setEnabled(true);
        instance.ivProfile.setEnabled(true);
        instance.ivCatgry.setEnabled(true);
        instance.ivFvrt.setEnabled(false);

        instance.logo.setVisibility(View.GONE);
        instance.ivBack.setVisibility(View.VISIBLE);
        instance.ivSave.setVisibility(View.GONE);
        instance.ivShare.setVisibility(View.GONE);
    }
}