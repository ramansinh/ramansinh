package com.pngstatus.statusimagemaker.model;

import com.google.gson.annotations.SerializedName;

public class Model_active_ad {
    @SerializedName("id")
    private String id;
    @SerializedName("active_ads")
    private String active_ads;
    @SerializedName("admob_app_id")
    private String admob_app_id;
    @SerializedName("admob_banner_id")
    private String admob_banner_id;
    @SerializedName("admob_fullscreen_id")
    private String admob_fullscreen_id;
    @SerializedName("admob_nativex_id")
    private String admob_nativex_id;
    @SerializedName("facebook_banner_id")
    private String facebook_banner_id;
    @SerializedName("facebook_fullscreen_id")
    private String facebook_fullscreen_id;
    @SerializedName("created_at")
    private String created_at;
    @SerializedName("updated_at")
    private String updated_at;
    @SerializedName("deleted_at")
    private String deleted_at;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getActive_ads() {
        return active_ads;
    }

    public void setActive_ads(String active_ads) {
        this.active_ads = active_ads;
    }

    public String getAdmob_app_id() {
        return admob_app_id;
    }

    public void setAdmob_app_id(String admob_app_id) {
        this.admob_app_id = admob_app_id;
    }

    public String getAdmob_banner_id() {
        return admob_banner_id;
    }

    public void setAdmob_banner_id(String admob_banner_id) {
        this.admob_banner_id = admob_banner_id;
    }

    public String getAdmob_fullscreen_id() {
        return admob_fullscreen_id;
    }

    public void setAdmob_fullscreen_id(String admob_fullscreen_id) {
        this.admob_fullscreen_id = admob_fullscreen_id;
    }

    public String getAdmob_nativex_id() {
        return admob_nativex_id;
    }

    public void setAdmob_nativex_id(String admob_nativex_id) {
        this.admob_nativex_id = admob_nativex_id;
    }

    public String getFacebook_banner_id() {
        return facebook_banner_id;
    }

    public void setFacebook_banner_id(String facebook_banner_id) {
        this.facebook_banner_id = facebook_banner_id;
    }

    public String getFacebook_fullscreen_id() {
        return facebook_fullscreen_id;
    }

    public void setFacebook_fullscreen_id(String facebook_fullscreen_id) {
        this.facebook_fullscreen_id = facebook_fullscreen_id;
    }

    public String getCreated_at() {
        return created_at;
    }

    public void setCreated_at(String created_at) {
        this.created_at = created_at;
    }

    public String getUpdated_at() {
        return updated_at;
    }

    public void setUpdated_at(String updated_at) {
        this.updated_at = updated_at;
    }

    public String getDeleted_at() {
        return deleted_at;
    }

    public void setDeleted_at(String deleted_at) {
        this.deleted_at = deleted_at;
    }
}
