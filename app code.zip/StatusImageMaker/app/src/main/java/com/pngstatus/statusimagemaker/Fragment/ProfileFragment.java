package com.pngstatus.statusimagemaker.Fragment;
import android.Manifest;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Point;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Environment;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.Patterns;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.URLUtil;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.pngstatus.statusimagemaker.Activity.DownloadImgActivity;
import com.pngstatus.statusimagemaker.Activity.PolicyActivity;
import com.pngstatus.statusimagemaker.Activity.ShareNEditListActivity;
import com.pngstatus.statusimagemaker.MainActivity;
import com.pngstatus.statusimagemaker.Utils.BuildConfig;
import com.pngstatus.statusimagemaker.Utils.Popup_success;
import com.pngstatus.statusimagemaker.model.Response_login;
import com.pngstatus.statusimagemaker.model.Response_policy;
import com.pngstatus.statusimagemaker.model.mode_file_list;
import com.pngstatus.statusimagemaker.model.model_login;
import com.pngstatus.statusimagemaker.R;
import com.pngstatus.statusimagemaker.Retrofit.RetrofitClient;
import com.pngstatus.statusimagemaker.Retrofit.RetrofitInterface;
import com.pngstatus.statusimagemaker.Utils.Constance;
import com.pngstatus.statusimagemaker.Utils.ImageSelection;
import com.pngstatus.statusimagemaker.Utils.LocaleHelper;
import com.pngstatus.statusimagemaker.Utils.Prefs;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Locale;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import id.zelory.compressor.Compressor;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.app.Activity.RESULT_OK;

/**
 * A simple {@link Fragment} subclass.
 */

public class ProfileFragment extends Fragment {
    Context context;
    Activity activity;
    public MainActivity instance;
    private Unbinder unbinder;
    final int TAKE_PHOTO_FROM_CAMARA = 0, TAKE_PHOTO_FROM_GALLARY = 1;
    String[] permissionsRequired = {Manifest.permission.CAMERA,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_EXTERNAL_STORAGE};
    private final int PERMISSION_CALLBACK_CONSTANT = 200;

    @BindView(R.id.iv_edit)
    ImageView iv_edit;
    @BindView(R.id.iv_profile)
    ImageView iv_profile;
    @BindView(R.id.tv_name)
    TextView tv_name;
    @BindView(R.id.tv_email)
    TextView tv_email;
    @BindView(R.id.tv_edit)
    TextView tv_edit;
    @BindView(R.id.tv_dwnld)
    TextView tv_dwnld;
    @BindView(R.id.tv_dwnld_list)
    TextView tv_dwnld_list;
    @BindView(R.id.tv_edit_list)
    TextView tv_edit_list;
    @BindView(R.id.tv_share_list)
    TextView tv_share_list;
    @BindView(R.id.tv_share)
    TextView tv_share;
    @BindView(R.id.rl_app_lnge)
    RelativeLayout rl_app_lnge;
    @BindView(R.id.rl_status_lnge)
    RelativeLayout rl_status_lnge;
    @BindView(R.id.rl_nitif)
    RelativeLayout rl_nitif;
    @BindView(R.id.rl_policy)
    RelativeLayout rl_policy;
    @BindView(R.id.rl_contct)
    RelativeLayout rl_contct;
    @BindView(R.id.rl_rate)
    RelativeLayout rl_rate;
    @BindView(R.id.rl_shareapp)
    RelativeLayout rl_shareapp;
    @BindView(R.id.rl_chng_pass)
    RelativeLayout rl_chng_pass;
    /*
    @BindView(R.id.rl_logout)
    RelativeLayout rl_logout;*/
    @BindView(R.id.ll_app_language)
    LinearLayout ll_app_language;
    @BindView(R.id.ll_status_language)
    LinearLayout ll_status_language;

    @BindView(R.id.btn_app_eng)
    Button btn_app_eng;
    @BindView(R.id.btn_app_guj)
    Button btn_app_guj;
    @BindView(R.id.btn_app_hindi)
    Button btn_app_hindi;

    @BindView(R.id.btn_status_all)
    Button btn_status_all;
    @BindView(R.id.btn_status_eng)
    Button btn_status_eng;
    @BindView(R.id.btn_status_guj)
    Button btn_status_guj;
    @BindView(R.id.btn_status_hindi)
    Button btn_status_hindi;
    @BindView(R.id.sw_notif)
    Switch sw_notif;
    @BindView(R.id.ll_edit)
    LinearLayout ll_edit;
    @BindView(R.id.ll_dwnld)
    LinearLayout ll_dwnld;
    @BindView(R.id.ll_share)
    LinearLayout ll_share;

    String imgPath, imgPathold, realpath;
    public RequestBody requestFile;
    public MultipartBody.Part body;
    model_login model;
    PopupWindow popup = new PopupWindow();
    WindowManager.LayoutParams params = null;
    String url = "";
    String lang = "";
    //All,English,Hindi,Gujrati
    File storageDir;
    private ArrayList<mode_file_list> arrayList = new ArrayList<>();

    public ProfileFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_profile, container, false);
        context = getActivity();
        activity = getActivity();
        unbinder = ButterKnife.bind(this, view);
        checkPermission();
        instance = MainActivity.getInstance();

        instance.ivPhotos.setSelected(false);
        instance.tvPhotos.setSelected(false);
        instance.ivCatgry.setSelected(false);
        instance.tvCatgry.setSelected(false);
        instance.ivFvrt.setSelected(false);
        instance.tvFvrt.setSelected(false);
        instance.ivProfile.setSelected(true);
        instance.tvProfile.setSelected(true);

        instance.ivProfile.setEnabled(false);
        instance.ivPhotos.setEnabled(true);
        instance.ivCatgry.setEnabled(true);
        instance.ivFvrt.setEnabled(true);
        instance.btnLogout.setVisibility(View.VISIBLE);

        instance.show_fullScreen_Ad();
        if (Prefs.getPrefBoolean(context, Constance.islogin, false)) {
            getProfile();
            get_privacy();
        }
        if (sw_notif.isChecked()) {
            Prefs.savebooleanPreferance(context, Constance.notification, true);
        } else {
            Prefs.savebooleanPreferance(context, Constance.notification, false);
        }
        iv_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isPermission()) {
                    selectImage();
                } else {
                    checkPermission();
                }
            }
        });
        sw_notif.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Prefs.savebooleanPreferance(context, Constance.notification, true);
                } else {
                    Prefs.savebooleanPreferance(context, Constance.notification, false);
                }
            }
        });
        ll_dwnld.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, DownloadImgActivity.class);
                startActivity(intent);
            }
        });
        iv_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Popup_editProfile();
            }
        });

        instance.btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               /* new AlertDialog.Builder(context)
                        .setMessage(getResources().getString(R.string.alrt_logout))
                        .setPositiveButton(getResources().getString(R.string.ok), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                             *//*   Prefs.Logout(context);
                                instance.ivLogin.setVisibility(View.VISIBLE);
                                instance.tvLogin.setVisibility(View.VISIBLE);
                                instance.ivProfile.setVisibility(View.GONE);
                                instance.tvProfile.setVisibility(View.GONE);
                                setHomeFragment();*//*

                            }
                        }).setNegativeButton(getResources().getString(R.string.cancel), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                }).show();*/
                Popup_Logout();
            }
        });
        rl_app_lnge.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ll_app_language.getVisibility() == View.GONE) {
                    ll_app_language.setVisibility(View.VISIBLE);
                } else {
                    ll_app_language.setVisibility(View.GONE);
                }
            }
        });

        rl_status_lnge.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ll_status_language.getVisibility() == View.GONE) {
                    ll_status_language.setVisibility(View.VISIBLE);
                } else {
                    ll_status_language.setVisibility(View.GONE);
                }
            }
        });
        rl_contct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                composeEmail();
            }
        });
        ll_share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, ShareNEditListActivity.class);
                intent.putExtra("type", "share");
                context.startActivity(intent);
            }
        });
        ll_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, ShareNEditListActivity.class);
                intent.putExtra("type", "edit");
                context.startActivity(intent);
            }
        });
        String applang = Prefs.getPrefString(context, Constance.select_app_lang, "en");
        setAppLocale(applang);

        btn_app_eng.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ll_app_language.setVisibility(View.GONE);
                Prefs.savePreferance(context, Constance.select_app_lang, "en");
                LocaleHelper.setLocale(context, "en");
                setAppLocale("en");
                restart(new ProfileFragment());

            }
        });
        btn_app_guj.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ll_app_language.setVisibility(View.GONE);
                Prefs.savePreferance(context, Constance.select_app_lang, "gu");
                LocaleHelper.setLocale(context, "gu");
                setAppLocale("gu");
                restart(new ProfileFragment());
            }
        });

        btn_app_hindi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ll_app_language.setVisibility(View.GONE);

                Prefs.savePreferance(context, Constance.select_app_lang, "hi");
                LocaleHelper.setLocale(context, "hi");
                setAppLocale("hi");
                restart(new ProfileFragment());

            }
        });

        btn_status_all.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ll_status_language.setVisibility(View.GONE);
                Prefs.savePreferance(context, Constance.select_status_lang, "All");
                lang = "All";
                updateLang(lang);
//                LocaleHelper.setLocale(context, "en");

            }
        });

        btn_status_eng.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ll_status_language.setVisibility(View.GONE);
                Prefs.savePreferance(context, Constance.select_status_lang, "English");
                lang = "English";
                updateLang(lang);
//                LocaleHelper.setLocale(context, "en");
            }
        });

        btn_status_guj.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ll_status_language.setVisibility(View.GONE);
                Prefs.savePreferance(context, Constance.select_status_lang, "Gujrati");
                lang = "Gujrati";
                updateLang(lang);
//                LocaleHelper.setLocale(context, "gu");
            }
        });

        btn_status_hindi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ll_status_language.setVisibility(View.GONE);
                Prefs.savePreferance(context, Constance.select_status_lang, "Hindi");
                lang = "Hindi";
                updateLang(lang);
//                LocaleHelper.setLocale(context, "hi");
            }
        });

        rl_policy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, PolicyActivity.class);
                intent.putExtra(Constance.img_url, url);
               /* if (IsValidUrl(url)) {
                    intent.putExtra(Constance.img_url, url);
                } else {
                    intent.putExtra(Constance.img_url, "https://www.google.com/");
                }*/
                startActivity(intent);
            }
        });


        rl_rate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri uri = Uri.parse(context.getResources().getString(R.string.rate_app_url) + getActivity().getPackageName());
                Intent myAppLinkToMarket = new Intent(Intent.ACTION_VIEW, uri);
                try {
                    startActivity(myAppLinkToMarket);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(context, "unable to find market app", Toast.LENGTH_LONG).show();
                }
            }
        });
        rl_shareapp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent shareIntent = new Intent(Intent.ACTION_SEND);
                    shareIntent.setType("text/plain");
                    shareIntent.putExtra(Intent.EXTRA_SUBJECT, context.getResources().getString(R.string.app_name));
                    String shareMessage = "\nLet me recommend you this application\n\n";
//                    shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID + "\n\n";
                    shareMessage = shareMessage + getResources().getString(R.string.sim_link) + BuildConfig.APPLICATION_ID + "\n\n";
                    shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
                    startActivity(Intent.createChooser(shareIntent, "choose one"));
                } catch (Exception e) {
                    //e.toString();
                }
            }
        });
        rl_chng_pass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Popup_Update_password();
            }
        });

        return view;

    }

    private void showRateAppFallbackDialog() {


    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);

        instance.tvPhotos.setText(getResources().getString(R.string.photos));

        instance.tvCatgry.setText(getResources().getString(R.string.category));

        instance.tvFvrt.setText(getResources().getString(R.string.favorite));

        instance.tvProfile.setText(getResources().getString(R.string.profile));

    }

    private void restart(Fragment frgmn) {
      /*  Intent intent = getIntent();
        finish();
        startActivity(intent);*/
        Fragment currentFragment = getActivity().getSupportFragmentManager().findFragmentById(R.id.main_frame);
        FragmentManager fragmentManager = (getActivity()).getSupportFragmentManager();
        int fragments = fragmentManager.getBackStackEntryCount();
        if (fragments > 1) {
            for (int i = 0; i < fragments - 1; i++) {
                fragmentManager.popBackStack();
            }
        }
        if (currentFragment instanceof ProfileFragment) {

//            fragmentManager.popBackStack(new HomeFragment().getTag(), FragmentManager.POP_BACK_STACK_INCLUSIVE);
            FragmentTransaction fragTransaction = fragmentManager.beginTransaction().replace(R.id.main_frame, new ProfileFragment(), new ProfileFragment().getTag());
            fragTransaction.commit();
//            fragTransaction.detach(frgmn);
//            fragTransaction.attach(frgmn);
//            fragTransaction.commit();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
//                fragTransaction.commitNow();
            } else {
//                fragTransaction.commit();
            }
        }
//        getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.main_frame, new ProfileFragment(),new ProfileFragment().getTag()).commitAllowingStateLoss();
 /*       ProfileFragment fragment = (new ProfileFragment());
                getActivity().getSupportFragmentManager().findFragmentById(R.id.main_frame);

        getActivity().getSupportFragmentManager().beginTransaction()
                .detach(fragment)
                .attach(new ProfileFragment())
                .commit();*/

      /*  FragmentManager fm = getActivity().getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        ft.detach(fragment).attach(fragment).commit();*/

    }

    public void moveFragment2(Fragment fragment) {
//        FragmentManager fm = ((Activity) context).getFragmentManager();
        FragmentManager fm = getActivity().getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
//        Bundle args = new Bundle();
//        args.putString(Constance.maincategoryId, getId);
//        fragment.setArguments(args);
        fm.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
//        ft.replace(R.id.main_frame, fragment, fragment.getClass().getSimpleName());
        ft.replace(R.id.main_frame, fragment, fragment.getClass().getSimpleName()).addToBackStack(null);
        ft.commit();
    }

    private void setAppLocale(String localeCode) {
        Prefs.savePreferance(context, Constance.select_app_lang, localeCode);

        Resources resources = getResources();
        DisplayMetrics dm = resources.getDisplayMetrics();
        Configuration config = resources.getConfiguration();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            config.setLocale(new Locale(localeCode.toLowerCase()));
        } else {
            config.locale = new Locale(localeCode.toLowerCase());
        }
        context.getResources().updateConfiguration(config,
                context.getResources().getDisplayMetrics());
        resources.updateConfiguration(config, dm);

//        getActivity().recreate();
        onConfigurationChanged(config);

//        moveFragment2(new ProfileFragment());(new ProfileFragment());
    }

    private void getProfile() {
        final ProgressDialog dialog = new ProgressDialog(context);
        dialog.setCancelable(false);
        dialog.setMessage(getResources().getString(R.string.wait_dot_dot));
        dialog.show();
        String token = Prefs.getPrefString(context, Constance.api_token, "");

        RetrofitInterface retrofitInterface = RetrofitClient.getClient().create(RetrofitInterface.class);
        Call<Response_login> call = retrofitInterface.get_profile(token);
        call.enqueue(new Callback<Response_login>() {
            @Override
            public void onResponse(Call<Response_login> call, Response<Response_login> response) {
                if (response != null && response.body() != null) {
                    if (response.body().getResult() != null && response.body().getResult().equals("1")) {

                        if (response.body().getRecord() != null) {
                            model = response.body().getRecord();

                            if (model.getName() != null) {
                                tv_name.setText(model.getName());
                            }
                            if (model.getEmail() != null) {
                                tv_email.setText(model.getEmail());
                            }
                            if (model.getImage_url() != null) {
//                                imgPath = Constance.Image_Url + model.getImage();
                                imgPathold = model.getImage_url();
                                imgPath = model.getImage_url();
//                                Glide.with(context).load(Constance.Image_Url + model.getImage()).into(iv_profile);
                                Glide.with(context).load(model.getImage_url()).into(iv_profile);
                            }
                            if (model.getLanguage() != null) {
                                lang = model.getLanguage();
                                Prefs.savePreferance(context, Constance.select_status_lang, lang);
                            }
                        } else {
                            dialog.dismiss();
                            Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        }

                        if (response.body().getUser_action_list() != null) {
                            if (response.body().getUser_action_list().getEdit() != null && response.body().getUser_action_list().getEdit().size() > 0) {
                                tv_edit.setText(response.body().getUser_action_list().getEdit().size() + "");
                            }
                            if (response.body().getUser_action_list().getShare() != null && response.body().getUser_action_list().getShare().size() > 0) {
                                tv_share.setText(response.body().getUser_action_list().getShare().size() + "");
                            }
                           /* if (response.body().getUser_action_list().getDownload() != null && response.body().getUser_action_list().getDownload().size() > 0) {
                                tv_dwnld.setText(response.body().getUser_action_list().getDownload().size() + "");
                            }*/
                        }
                        dialog.dismiss();
                    } else {
                        dialog.dismiss();
                        Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    dialog.dismiss();
                    Toast.makeText(context, response.message(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Response_login> call, Throwable t) {
                dialog.dismiss();
                Toast.makeText(context, t.getMessage(), Toast.LENGTH_SHORT).show();
                Log.e("response", "login :" + t.getMessage());
            }
        });
    }

    private void updateLang(String language) {
        final ProgressDialog dialog = new ProgressDialog(context);
        dialog.setCancelable(false);
        dialog.setMessage(getResources().getString(R.string.wait_dot_dot));
        dialog.show();
        String token = Prefs.getPrefString(context, Constance.api_token, "");
        if (imgPath != null && !imgPath.equals("")) {
            File file1 = new File(imgPath);
            requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), file1);
            body = MultipartBody.Part.createFormData("image", file1.getName(), requestFile);
        } else {
            requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), "");
            body = MultipartBody.Part.createFormData("image", "", requestFile);
        }

        RequestBody rb_toke, rb_language;
        rb_toke = RequestBody.create(MultipartBody.FORM, token);
        rb_language = RequestBody.create(MultipartBody.FORM, language);

        RetrofitInterface retrofitInterface = RetrofitClient.getClient().create(RetrofitInterface.class);
        Call<Response_login> call = retrofitInterface.updateLang(rb_toke, rb_language);
        call.enqueue(new Callback<Response_login>() {
            @Override
            public void onResponse(Call<Response_login> call, Response<Response_login> response) {
                if (response != null && response.body() != null) {
                    if (response.body().getResult() != null && response.body().getResult().equals("1")) {

                        if (response.body().getRecord() != null) {
                            model = response.body().getRecord();
                            if (model.getName() != null) {
                                tv_name.setText(model.getName());
                            }
                            if (model.getEmail() != null) {
                                tv_email.setText(model.getEmail());
                            }
                            if (model.getImage() != null) {
                                imgPath = model.getImage();
                                Glide.with(context).load( model.getImage()).into(iv_profile);
                            }

                        } else {
                            dialog.dismiss();
                            Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                        dialog.dismiss();
                    } else {
                        dialog.dismiss();
                        Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    dialog.dismiss();
                    Toast.makeText(context, response.message(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Response_login> call, Throwable t) {
                dialog.dismiss();
                Toast.makeText(context, t.getMessage(), Toast.LENGTH_SHORT).show();
                Log.e("response", "login :" + t.getMessage());
            }
        });

    }

    private void updatePassword(String password) {
        final ProgressDialog dialog = new ProgressDialog(context);
        dialog.setCancelable(false);
        dialog.setMessage(getResources().getString(R.string.wait_dot_dot));
        dialog.show();
        String token = Prefs.getPrefString(context, Constance.api_token, "");
        if (imgPath != null && !imgPath.equals("")) {
            File file1 = new File(imgPath);
            requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), file1);
            body = MultipartBody.Part.createFormData("image", file1.getName(), requestFile);
        } else {
            requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), "");
            body = MultipartBody.Part.createFormData("image", "", requestFile);
        }

        RequestBody rb_toke, rb_password;
        rb_toke = RequestBody.create(MultipartBody.FORM, token);
        rb_password = RequestBody.create(MultipartBody.FORM, password);

        RetrofitInterface retrofitInterface = RetrofitClient.getClient().create(RetrofitInterface.class);
        Call<Response_login> call = retrofitInterface.update_password(rb_toke, rb_password);
        call.enqueue(new Callback<Response_login>() {
            @Override
            public void onResponse(Call<Response_login> call, Response<Response_login> response) {
                if (response != null && response.body() != null) {
                    if (response.body().getResult() != null && response.body().getResult().equals("1")) {

                        if (response.body().getRecord() != null) {
                            model = response.body().getRecord();
                        } else {
                            dialog.dismiss();
                            Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                        dialog.dismiss();
                    } else {
                        dialog.dismiss();
                        Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    dialog.dismiss();
                    Toast.makeText(context, response.message(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Response_login> call, Throwable t) {
                dialog.dismiss();
                Toast.makeText(context, t.getMessage(), Toast.LENGTH_SHORT).show();
                Log.e("response", "login :" + t.getMessage());
            }
        });

    }

    private void updateProfile(String name, String email, String language) {
        final ProgressDialog dialog = new ProgressDialog(context);
        dialog.setCancelable(false);
        dialog.setMessage(getResources().getString(R.string.wait_dot_dot));
        dialog.show();
        String token = Prefs.getPrefString(context, Constance.api_token, "");
        if (imgPath != null && !imgPath.equals("")) {
            File file1 = new File(imgPath);
            requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), file1);
            body = MultipartBody.Part.createFormData("image", file1.getName(), requestFile);
        } else {
            requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), "");
            body = MultipartBody.Part.createFormData("image", "", requestFile);
        }

        RequestBody rb_toke, rb_name, rb_email, rb_language;
        rb_toke = RequestBody.create(MultipartBody.FORM, token);
        rb_name = RequestBody.create(MultipartBody.FORM, name);
        rb_email = RequestBody.create(MultipartBody.FORM, email);
        rb_language = RequestBody.create(MultipartBody.FORM, language);

        RetrofitInterface retrofitInterface = RetrofitClient.getClient().create(RetrofitInterface.class);
        Call<Response_login> call = retrofitInterface.update_profile(rb_toke, rb_name, rb_email, rb_language);
        call.enqueue(new Callback<Response_login>() {
            @Override
            public void onResponse(Call<Response_login> call, Response<Response_login> response) {
                if (response != null && response.body() != null) {
                    if (response.body().getResult() != null && response.body().getResult().equals("1")) {
                        if (response.body().getRecord() != null) {
                            model = response.body().getRecord();
                            if (model.getName() != null) {
                                tv_name.setText(model.getName());
                            }
                            if (model.getEmail() != null) {
                                tv_email.setText(model.getEmail());
                            }
                            if (model.getImage() != null) {
                                imgPath = model.getImage();
                                Glide.with(context).load( model.getImage()).into(iv_profile);
                            }

                        } else {
                            dialog.dismiss();
                            Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                        dialog.dismiss();
                    } else {
                        dialog.dismiss();
                        Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    dialog.dismiss();
                    Toast.makeText(context, response.message(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Response_login> call, Throwable t) {
                dialog.dismiss();
                Toast.makeText(context, t.getMessage(), Toast.LENGTH_SHORT).show();
                Log.e("response", "login :" + t.getMessage());
            }
        });

    }

    private void updateImage() {
        final ProgressDialog dialog = new ProgressDialog(context);
        dialog.setCancelable(false);
        dialog.setMessage(getResources().getString(R.string.wait_dot_dot));
        dialog.show();
        String token = Prefs.getPrefString(context, Constance.api_token, "");
        if (imgPath != null && !imgPath.equals("")) {
            File file1 = new File(imgPath);
            requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), file1);
            body = MultipartBody.Part.createFormData("image", file1.getName(), requestFile);
        } else {
            requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), "");
            body = MultipartBody.Part.createFormData("image", "", requestFile);
        }

        RequestBody rb_toke, rb_name, rb_email, rb_language;
        rb_toke = RequestBody.create(MultipartBody.FORM, token);


        RetrofitInterface retrofitInterface = RetrofitClient.getClient().create(RetrofitInterface.class);
        Call<Response_login> call = retrofitInterface.update_profile_image(rb_toke, body);
        call.enqueue(new Callback<Response_login>() {
            @Override
            public void onResponse(Call<Response_login> call, Response<Response_login> response) {
                if (response != null && response.body() != null) {
                    if (response.body().getResult() != null && response.body().getResult().equals("1")) {
                        if (response.body().getRecord() != null) {
                            model = response.body().getRecord();
                            if (model.getName() != null) {
                                tv_name.setText(model.getName());
                            }
                            if (model.getEmail() != null) {
                                tv_email.setText(model.getEmail());
                            }
                            if (model.getImage() != null) {
                                imgPath = model.getImage();
                                Glide.with(context).load(model.getImage()).into(iv_profile);
                            }

                        } else {
                            dialog.dismiss();
                            Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                        dialog.dismiss();
                    } else {
                        dialog.dismiss();
                        Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    dialog.dismiss();
                    Toast.makeText(context, response.message(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Response_login> call, Throwable t) {
                dialog.dismiss();
                Toast.makeText(context, t.getMessage(), Toast.LENGTH_SHORT).show();
                Log.e("response", "login :" + t.getMessage());
            }
        });

    }

    public void Popup_editProfile() {
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        int width = size.x;
        int height = size.y;
        if (!popup.isShowing()) {

            final LayoutInflater inflaterpopup = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
            final View view1 = inflaterpopup.inflate(R.layout.popup_edit_profile, null);
            popup = new PopupWindow(view1, params.MATCH_PARENT, params.MATCH_PARENT);

            popup.setFocusable(true);

            EditText et_name = view1.findViewById(R.id.et_name);
            TextView et_email = view1.findViewById(R.id.et_email);
            TextView tv_ok = view1.findViewById(R.id.tv_ok);
            TextView tv_cancel = view1.findViewById(R.id.tv_cancel);

            et_email.setText(model.getEmail());
            et_name.setText(model.getName());

            tv_ok.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (!et_name.getText().toString().isEmpty()) {
                        if (!et_email.getText().toString().isEmpty()) {
                            popup.dismiss();
                            updateProfile(et_name.getText().toString(),
                                    et_email.getText().toString(), lang);
                        } else {
                            et_name.requestFocus();
                            et_name.setError(getResources().getString(R.string.err_enter_email));
                        }
                    } else {
                        et_name.requestFocus();
                        et_name.setError(getResources().getString(R.string.err_entr_name));
                    }
                }
            });
            tv_cancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    popup.dismiss();
                }
            });
            popup.setOutsideTouchable(false);
//                          popup.showAtLocation(view1, Gravity.TOP, width, height);
            popup.showAtLocation(view1, Gravity.CENTER, 0, 0);
        } else {
            popup.dismiss();
        }
    }

    public void Popup_Update_password() {
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        int width = size.x;
        int height = size.y;
        if (!popup.isShowing()) {

            final LayoutInflater inflaterpopup = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
            final View view1 = inflaterpopup.inflate(R.layout.popup_password, null);
            popup = new PopupWindow(view1, params.MATCH_PARENT, params.MATCH_PARENT);

            popup.setFocusable(true);

            EditText et_name = view1.findViewById(R.id.et_name);
            TextView et_email = view1.findViewById(R.id.et_email);
            TextView tv_ok = view1.findViewById(R.id.tv_ok);
            TextView tv_cancel = view1.findViewById(R.id.tv_cancel);

            tv_ok.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    popup.dismiss();
                    if (!et_name.getText().toString().isEmpty()) {
                        if (!et_email.getText().toString().equals("")) {

                            if (et_name.getText().toString().equals(et_email.getText().toString())) {
                                updatePassword(et_name.getText().toString());
                            } else {
                                et_email.requestFocus();
                                et_email.setError(context.getResources().getString(R.string.err_paswwrd_not_match));
                            }
                        } else {
                            et_email.requestFocus();
                            et_email.setError(context.getResources().getString(R.string.err_entr_paswrd));
                        }
                    } else {
                        et_name.requestFocus();
                        et_name.setError(context.getResources().getString(R.string.err_entr_paswrd));
                    }
                }
            });
            tv_cancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    popup.dismiss();
                }
            });
            popup.setOutsideTouchable(false);
//                          popup.showAtLocation(view1, Gravity.TOP, width, height);
            popup.showAtLocation(view1, Gravity.CENTER, 0, 0);
        } else {
            popup.dismiss();
        }
    }

    public void setHomeFragment() {
        Fragment fragment = new HomeFragment();
        FragmentManager fm = getActivity().getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        fm.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
        ft.replace(R.id.main_frame, fragment, fragment.getClass().getSimpleName());
        ft.commit();
    }

    public void moveFragment(Fragment fragment) {
//        FragmentManager fm = ((Activity) context).getFragmentManager();
        FragmentManager fm = getActivity().getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
//        Bundle args = new Bundle();
//        args.putString(Constance.maincategoryId, getId);
//        fragment.setArguments(args);
//        fm.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
//        ft.replace(R.id.main_frame, fragment, fragment.getClass().getSimpleName());
        ft.replace(R.id.main_frame, fragment, fragment.getClass().getSimpleName()).addToBackStack(null);
        ft.commit();
    }

    public void Popup_profile_img() {

        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        int width = size.x;
        int height = size.y;
        if (!popup.isShowing()) {
            final LayoutInflater inflaterpopup = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
            final View view1 = inflaterpopup.inflate(R.layout.popup_logout, null);
            popup = new PopupWindow(view1, params.MATCH_PARENT, params.MATCH_PARENT);
            popup.setFocusable(true);
            TextView tv_msg = view1.findViewById(R.id.tv_msg);
            TextView tv_no = view1.findViewById(R.id.tv_no);
            TextView tv_yes = view1.findViewById(R.id.tv_yes);
            tv_msg.setText(getResources().getString(R.string.sure_to_updt_profile_pic));
            tv_no.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Glide.with(context).load(imgPathold).into(iv_profile);
                    popup.dismiss();
                }
            });
            tv_yes.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    popup.dismiss();
                    updateImage();
               /*     Intent intent = new Intent(context, MainActivity.class);
                    context.startActivity(intent);
                    ((Activity)context).finishAffinity();*/
                }
            });
            popup.setOutsideTouchable(true);
//                          popup.showAtLocation(view1, Gravity.TOP, width, height);
            popup.showAtLocation(view1, Gravity.BOTTOM, 0, 0);
        } else {
            popup.dismiss();
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            if (resultCode == RESULT_OK) {
                Bitmap bm1 = null;
                if (data != null && data.getData() != null) {
                    try {
                        bm1 = MediaStore.Images.Media.getBitmap(context.getApplicationContext().getContentResolver(), data.getData());
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                        realpath = ImageSelection.getPath(context, data.getData());
                    } else {
                        realpath = ImageSelection.getPath1(context, data.getData());
                    }
                 /*   File file=new File(data.getData().toString());
                    String path=file.getAbsolutePath();*/
                    File compressedImageFile = null;
                    String uriString = realpath;
                    File file = new File(uriString);
//                    File file = new File(uriString);
                    try {
                        compressedImageFile = new Compressor(context).compressToFile(file);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    imgPath = compressedImageFile.getAbsolutePath();
//                    iv_main_img.setImageBitmap(bm1);
                    Glide.with(context).load(imgPath).into(iv_profile);
                    Popup_profile_img();
                }
            }
        }
    }

    private boolean isPermission() {
        if (ActivityCompat.checkSelfPermission(context, permissionsRequired[0]) != PackageManager.PERMISSION_GRANTED
                || ActivityCompat.checkSelfPermission(context, permissionsRequired[1]) != PackageManager.PERMISSION_GRANTED
                || ActivityCompat.checkSelfPermission(context, permissionsRequired[2]) != PackageManager.PERMISSION_GRANTED) {
//            checkPermission();
            return false;
        } else {
            return true;
        }
    }

    private void selectImage() {
        final CharSequence[] items = {getResources().getString(R.string.choose_from_glry),
                getResources().getString(R.string.capture_frm_camra),
                getResources().getString(R.string.cancel)};
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(context);
        builder.setTitle(getResources().getString(R.string.select_photo));
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                if (items[item].equals(getResources().getString(R.string.choose_from_glry))) {
                               /* Intent intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                                startActivityForResult(intent, TAKE_PHOTO_FROM_GALLARY);*/
                    Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
                    photoPickerIntent.setType("image/*");
                    startActivityForResult(photoPickerIntent, 1);
                } else if (items[item].equals(getResources().getString(R.string.capture_frm_camra))) {
                               /* Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                                File f = new File(android.os.Environment.getExternalStorageDirectory(), "temp1.jpg");
                                intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(f));
                                startActivityForResult(intent, TAKE_PHOTO_FROM_CAMARA);*/
                    dispatchTakePictureIntent();
                } else if (items[item].equals(getResources().getString(R.string.cancel))) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }

    private void dispatchTakePictureIntent() {
        int camera = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA);
        int grant = PackageManager.PERMISSION_GRANTED;

        Log.i("tag", "camera : " + camera);
        Log.i("tag", "grant : " + grant);

        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        // Ensure that there's a camera activity to handle the intent

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.ECLAIR) {
            if (context.getApplicationContext().getPackageManager().hasSystemFeature(
                    PackageManager.FEATURE_CAMERA)) {
                //           if (takePictureIntent.resolveActivity(CompanyUploadMultiFileActivity.this.getPackageManager()) != null) {
                // Create the File where the photo should go
                File photoFile = null;
                try {
                    photoFile = createImageFile();
                } catch (IOException ex) {
                    // Error occurred while creating the File
                }
                // Continue only if the File was successfully created
                if (photoFile != null) {
                    Uri photoURI = FileProvider.getUriForFile(context,
                            getResources().getString(R.string.file_provider_authority),
                            photoFile);
                    takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                    takePictureIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivityForResult(takePictureIntent, 2);
                }
                //           }
            } else {
                Toast.makeText(context, getResources().getString(R.string.msg_no_camra), Toast.LENGTH_SHORT).show();
                // no camera on this device
            }
        }
    }

    private File createImageFile() throws IOException {
        String imageFileName = "Temp_";
        File storageDir;
    /*    if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            // only for gingerbread and newer versions
            storageDir = new File(context.getExternalFilesDir(null), "/pngStatus/");
        } else {
//            storageDir = new File(Environment.getExternalStorageDirectory() + "/pngStatus/");
            storageDir =new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).toString()+ "/pngStatus/");
        }*/
        storageDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).toString() + "/pngStatus/");
        if (storageDir.exists()) {
            Log.e("tag", "exitst file path" + storageDir.getAbsolutePath());


        } else {
            storageDir.mkdirs();
//            Toast.makeText(context, file.getAbsolutePath(), Toast.LENGTH_SHORT).show();
            Log.e("tag", "new file path  " + storageDir.getAbsolutePath());
        }
        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );
        realpath = image.getAbsolutePath();
        return image;
    }

    public void checkPermission() {
        if (ActivityCompat.checkSelfPermission(context, permissionsRequired[0]) != PackageManager.PERMISSION_GRANTED
                || ActivityCompat.checkSelfPermission(context, permissionsRequired[1]) != PackageManager.PERMISSION_GRANTED
                || ActivityCompat.checkSelfPermission(context, permissionsRequired[2]) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale((Activity) context, permissionsRequired[0])
                    || ActivityCompat.shouldShowRequestPermissionRationale((Activity) context, permissionsRequired[1])
                    || ActivityCompat.shouldShowRequestPermissionRationale((Activity) context, permissionsRequired[2])) {
                //Show Information about why you need the permission
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setTitle(getResources().getString(R.string.need_multiple_prmisn));
                builder.setMessage(getResources().getString(R.string.app_need_multiple_prmisn));
                builder.setPositiveButton(getResources().getString(R.string.grant), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                        ActivityCompat.requestPermissions((Activity) context, permissionsRequired, PERMISSION_CALLBACK_CONSTANT);
                    }
                });
                builder.setNegativeButton(getResources().getString(R.string.cancel), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
//                        onBackPressed();
                    }
                });
                builder.show();
            } else {
                //just request the permission
                ActivityCompat.requestPermissions((Activity) context, permissionsRequired, PERMISSION_CALLBACK_CONSTANT);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case 200: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0 &&
                        grantResults[0] == PackageManager.PERMISSION_GRANTED &&
                        grantResults[1] == PackageManager.PERMISSION_GRANTED &&
                        grantResults[2] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.
                } else {
                    checkPermission();
//                    onBackPressed();
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }

    private void get_privacy() {
        String token = Prefs.getPrefString(context, Constance.api_token, "");

        RetrofitInterface retrofitInterface = RetrofitClient.getClient().create(RetrofitInterface.class);
        Call<Response_policy> call = retrofitInterface.get_privacy(token);
        call.enqueue(new Callback<Response_policy>() {
            @Override
            public void onResponse(Call<Response_policy> call, Response<Response_policy> response) {
                if (response != null && response.body() != null) {
                    if (response.body().getResult() != null && response.body().getResult().equals("1")) {
                        if (response.body().getRecords() != null && response.body().getRecords().size() > 0) {
                            if (response.body().getRecords().get(0).getPrivacy() != null) {
                                url = response.body().getRecords().get(0).getPrivacy();
                            }
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<Response_policy> call, Throwable t) {

            }
        });
    }

    public boolean IsValidUrl(String urlString) {
        try {
            URL url = new URL(urlString);
            return URLUtil.isValidUrl(urlString) && Patterns.WEB_URL.matcher(urlString).matches();
        } catch (MalformedURLException ignored) {
        }
        return false;
    }

    public void Popup_Logout() {
        popup = new PopupWindow();
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        int width = size.x;
        int height = size.y;
        if (!popup.isShowing()) {
            final LayoutInflater inflaterpopup = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
            final View view1 = inflaterpopup.inflate(R.layout.popup_logout, null);
            popup = new PopupWindow(view1, params.MATCH_PARENT, params.MATCH_PARENT);
            popup.setFocusable(true);
            TextView tv_no = view1.findViewById(R.id.tv_no);
            TextView tv_yes = view1.findViewById(R.id.tv_yes);

            tv_no.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    popup.dismiss();
                }
            });

            tv_yes.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    popup.dismiss();
                    Prefs.Logout(context);
                    instance.ivLogin.setVisibility(View.VISIBLE);
                    instance.tvLogin.setVisibility(View.VISIBLE);
                    instance.ivProfile.setVisibility(View.GONE);
                    instance.tvProfile.setVisibility(View.GONE);
                    setHomeFragment();
                }
            });
            popup.setOutsideTouchable(true);
//                          popup.showAtLocation(view1, Gravity.TOP, width, height);
            popup.showAtLocation(view1, Gravity.BOTTOM, 0, 0);
        } else {
            popup.dismiss();
        }
    }

    public void composeEmail() {
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setType("message/rfc822");
//        intent.setData(Uri.parse("mailto:")); // only email apps should handle this
//        intent.setType("text/plain");
        intent.setData(Uri.parse("mailto:demo@gmail.com"));
//        intent.putExtra(Intent.EXTRA_EMAIL, "demo@gmail.com");
        intent.putExtra(Intent.EXTRA_SUBJECT, "Status Image Maker");
        startActivity(intent);
        if (intent.resolveActivity(getContext().getPackageManager()) != null) {

        }
    }

    @Override
    public void onResume() {
        super.onResume();
        instance = MainActivity.getInstance();

        instance.ivPhotos.setSelected(false);
        instance.tvPhotos.setSelected(false);
        instance.ivCatgry.setSelected(false);
        instance.tvCatgry.setSelected(false);
        instance.ivFvrt.setSelected(false);
        instance.tvFvrt.setSelected(false);
        instance.ivProfile.setSelected(true);
        instance.tvProfile.setSelected(true);
        instance.ivProfile.setFocusable(true);
        instance.tvProfile.setFocusable(true);

        instance.ivProfile.setEnabled(false);
        instance.ivPhotos.setEnabled(true);
        instance.ivCatgry.setEnabled(true);
        instance.ivFvrt.setEnabled(true);

        instance.logo.setVisibility(View.GONE);
        instance.ivBack.setVisibility(View.VISIBLE);
        instance.ivSave.setVisibility(View.GONE);
        instance.ivShare.setVisibility(View.GONE);

        count_download();
    }

    private void count_download() {
        storageDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + "/pngStatus/");
        if (storageDir.exists()) {
            Log.e("tag", "exitst file path" + storageDir.getAbsolutePath());
            arrayList.clear();
            getfile(storageDir);
            tv_dwnld.setText(arrayList.size() + "");
        } else {
            Popup_success popup_success = new Popup_success();
            popup_success.Popup_success(context, context.getResources().getString(R.string.dirctry_not_found));
        }
    }

    public void getfile(File dir) {
//    public ArrayList<File> getfile(File dir) {
        File listFile[] = dir.listFiles();
//        Log.e("tag", "size of dir : " + listFile.length);

        if (listFile != null && listFile.length > 0) {
            for (int i = 0; i < listFile.length; i++) {

                if (listFile[i].isDirectory()) {
                    getfile(listFile[i]);
                } else {
                    if (listFile[i].getName().endsWith(".png")) {
                        arrayList.add(new mode_file_list(listFile[i], listFile[i].getName()));
                    }
                }
            }
        }
//        return fileList;
    }

}
