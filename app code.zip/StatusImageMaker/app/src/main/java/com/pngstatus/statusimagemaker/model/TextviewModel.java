package com.pngstatus.statusimagemaker.model;

import android.widget.TextView;

import com.google.gson.annotations.SerializedName;

import io.github.hyuwah.draggableviewlib.DraggableView;

public class TextviewModel {
    @SerializedName("dragview")
    private DraggableView dragview;
    @SerializedName("textview")
    private TextView textview;
    @SerializedName("name")
    private String name;
    @SerializedName("id")
    private int id;


    public TextviewModel(DraggableView dragview, TextView textview, String name, int id) {
        this.dragview = dragview;
        this.textview = textview;
        this.name = name;
        this.id = id;

    }

    public DraggableView getDragview() {
        return dragview;
    }

    public void setDragview(DraggableView dragview) {
        this.dragview = dragview;
    }

    public TextView getTextview() {
        return textview;
    }

    public void setTextview(TextView textview) {
        this.textview = textview;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
