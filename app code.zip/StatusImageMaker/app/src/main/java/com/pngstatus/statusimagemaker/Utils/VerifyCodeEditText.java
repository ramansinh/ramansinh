package com.pngstatus.statusimagemaker.Utils;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;

public class VerifyCodeEditText {

    public static class keyevents implements View.OnKeyListener {
        EditText curnt;
        EditText prvs;

        public keyevents(EditText currnt,EditText previous){
           this.curnt=currnt;
            this.prvs=previous;
        }

        @Override
        public boolean onKey(View view, int i, KeyEvent keyEvent) {
            if (keyEvent.getAction()== KeyEvent.ACTION_DOWN &&
                    i==KeyEvent.KEYCODE_DEL && curnt.getText().length()==0){
                if (prvs.getText().length()!=0)
                {
                    prvs.requestFocus();
                    return true;
                }
            }
            return false;
        }
    }

    public static class GenericTextWatcher implements TextWatcher {
        EditText curnt;
        EditText nxt;

        public GenericTextWatcher(EditText currnt,EditText next) {
            this.curnt = currnt;
            this.nxt = next;
        }

        @Override
        public void afterTextChanged(Editable editable) {
            String text = editable.toString();
            if (text.length() == 1) {

                nxt.requestFocus();
//                    Log.i("tag", "jkhkhj" + one);
            }
          /*  switch (curnt.getId()) {

                case R.id.et_first:
                    if (text.length() == 1) {

                        nxt.requestFocus();
//                    Log.i("tag", "jkhkhj" + one);
                    }

                    break;
                case R.id.et_scnd:
                    if (text.length() == 1) {

                        et_third.requestFocus();
                    }
                    break;
                case R.id.et_third:
                    if (text.length() == 1) {
                        et_forth.requestFocus();
                    }
                    break;
                case R.id.et_forth:
                    if (text.length() == 1) {
                        et_third.setImeOptions(EditorInfo.IME_ACTION_DONE);

                        InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
                        //Find the currently focused view, so we can grab the correct window token from it.
                        View view = activity.getCurrentFocus();
                        //If no view currently has focus, create a new one, just so we can grab a window token from it
                        if (view == null) {
                            view = new View(activity);
                        }

                        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
                    }
                    break;
            }*/
        }

        @Override
        public void beforeTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
        }

        @Override
        public void onTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
        }
    }
}
