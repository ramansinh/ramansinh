package com.pngstatus.statusimagemaker.model;

import com.google.gson.annotations.SerializedName;

public class Response_post {
    @SerializedName("result")
    private String result;
    @SerializedName("message")
    private String message;
    @SerializedName("records")
    private model_post records;

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public model_post getRecords() {
        return records;
    }

    public void setRecords(model_post records) {
        this.records = records;
    }
}
